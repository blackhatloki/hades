#!/usr/bin/perl
use strict;

my (%ip,%obj,$dg,$rl,$rvg,$remote,$local) = ();
my $pwatch = $ENV{'PWATCH'};
my $logdir = (
  ( -d "$ENV{'LOCATION'}/$ENV{'LOGDIR'}") ? "$ENV{'LOCATION'}/$ENV{'LOGDIR'}" : (
    ( -d "$ENV{'LOCATION'}/logs") ? "$ENV{'LOCATION'}/logs" : "/dev/null"
  )
);

while(<>){
  my @fields = split;
  if (/^Disk group:/) {
    $dg = $fields[2];
  } elsif (/^Rlink:/) {
    $rl = $fields[1];
    $obj{$dg}{rlink}{$rl} = 1;
  } elsif (/^assoc:.*rvg=/) {
    $rvg = $fields[1];
    $rvg =~ s/rvg=//;
    $obj{$dg}{rvg}{$rvg} = 1;
  } elsif (/remote_host=/){
    $remote = $fields[1];
    $remote =~ s/IP_addr=//;
  } elsif (/local_host=/){
    $local = $fields[1];
    $local =~ s/IP_addr=//;
    $ip{$local}{$remote} = 1;
  }
}

print "if [ -d \"$logdir\" ];then\n";
print "  SAVEDIR=\`pwd\`\n";
print "  cd $logdir\n";
print "  vxmemstat -i1 -t1 > vvr_vxmemstat.$pwatch &\n";
print "  KILLLIST=\"\$KILLLIST \$!\"\n";
foreach my $dg (sort keys %obj){
  foreach my $rl (sort keys %{$obj{$dg}{rlink}}){
    print "  vxrlink -g $dg -i1 -t1 stats $rl > vvr_vxrlink_stats_$rl.$dg.$pwatch &\n";
    print "  KILLLIST=\"\$KILLLIST \$!\"\n";
    print "  vxprint -PVl $rl > vvr_vxprint_PVl_$rl.$dg.$pwatch\n";
    print "  vxrlink -g $dg -T updates $rl > vvr_vxrlink_T_updates_$rl.$dg.$pwatch\n";
    print "  vxrlink -g $dg updates $rl > vvr_vxrlink_updates_$rl.$dg.$pwatch\n";
  }
  foreach my $rvg (sort keys %{$obj{$dg}{rvg}}){
    print "  vxprint -PVl $rvg > vvr_vxprint_PVl_$rvg.$dg.$pwatch\n";
    print "  vradmin -g $dg printrvg $rvg > vvr_vradmin_printrvg_$rvg.$dg.$pwatch\n";
    print "  vradmin -g $dg -l repstatus $rvg > vvr_vradmin_l_repstatus_$rvg.$dg.$pwatch\n";
  }
}

foreach my $local (sort keys %ip){
  foreach my $remote (sort keys %{$ip{$local}}){
    if ( "$ENV{'OS'}" == "Linux") {
      print "  ping -c 5 -s 1400 $remote > vvr_ping_c5_s1400_$remote.$pwatch&\n";
      print "  ping -c 5 -s 8400 $remote > vvr_ping_c5_s8400_$remote.$pwatch&\n";
    } elsif ( "$ENV{'OS'}" == "SunOS" ) {
      print "  ping -s -i $local $remote 1400 5 > vvr_ping_s_i_${local}_${remote}.1400.$pwatch&\n";
      print "  ping -s -i $local $remote 8400 5 > vvr_ping_s_i_${local}_${remote}.8400.$pwatch&\n";
    }
  }
}
print "  env > vvr_Flook_env.$pwatch\n";
print "  set > vvr_Flook_set.$pwatch\n";
print "  sleep 15\n";
print "  kill \$KILLLIST\n";
print "else\n";
print "  echo \"directory: $logdir does not exist, skipping all vvr detail collections\"\n";
print "fi\n";
