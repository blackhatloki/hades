#!/bin/sh

if [ -f ${LOCATION}/${LOGDIR}/tlist_hpux.lock ]
then
	# Already running
	exit
fi

touch ${LOCATION}/${LOGDIR}/tlist_hpux.lock
${CRASHINFO} -t -l -v

rm ${LOCATION}/${LOGDIR}/tlist_hpux.lock

