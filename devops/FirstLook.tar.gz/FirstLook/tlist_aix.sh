#!/bin/sh

if [ -f ${LOCATION}/${LOGDIR}/tlist_aix.lock ]
then
	# Already running
	exit
fi

touch ${LOCATION}/${LOGDIR}/tlist_aix.lock
THREADS=`echo 'th *' | kdb | grep ^pvthread | awk '{print $1}'`

for thread in ${THREADS}
do
        echo "th ${thread}" >> ${LOCATION}/${LOGDIR}/tlist.cmds
        echo "f ${thread}" >> $LOCATION/${LOGDIR}/tlist.cmds
        echo "#" >> $LOCATION/${LOGDIR}/tlist.cmds
        echo "#" >> $LOCATION/${LOGDIR}/tlist.cmds
        echo "#" >> $LOCATION/${LOGDIR}/tlist.cmds
done

kdb < $LOCATION/${LOGDIR}/tlist.cmds 
rm $LOCATION/${LOGDIR}/tlist.cmds
rm ${LOCATION}/${LOGDIR}/tlist_aix.lock

