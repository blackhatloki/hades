#!/bin/sh
# Generate threadlist
#

#Copyright (c) 2007 Symantec Corporation.
#All rights reserved.
#
#THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF
#SYMANTEC CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED
#WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
#
#The Licensed Software and Documentation are deemed to be "commercial
#computer software" and "commercial computer software documentation"
#as defined in FAR Sections 12.212 and DFARS Section 227.7202. 
#check for lock file
if [ -f $LOCATION/log/threadlock.flag ];
then
 	exit
fi

# create lock file

echo $$ > $LOCATION/$LOGDIR/threadlock.flag

# use mdb if we can
if [ $OSTYPE -eq 1 ]
then
adb -k <<tlist
$<threadlist
tlist
else
mdb -k <<tlist
$<threadlist
tlist
fi

# remove lock
rm $LOCATION/$LOGDIR/threadlock.flag

