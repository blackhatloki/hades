#!/bin/sh
# Generate threadlist
#

#Copyright (c) 2007 Symantec Corporation.
#All rights reserved.
#
#THIS SOFTWARE CONTAINS CONFIDENTIAL INFORMATION AND TRADE SECRETS OF
#SYMANTEC CORPORATION.  USE, DISCLOSURE OR REPRODUCTION IS PROHIBITED
#WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SYMANTEC CORPORATION.
#
#The Licensed Software and Documentation are deemed to be "commercial
#computer software" and "commercial computer software documentation"
#as defined in FAR Sections 12.212 and DFARS Section 227.7202. 
#check for lock file

if [ -f $LOCATION/log/threadlock.flag ]
then
 	exit
fi

# create lock file

echo $$ > $LOCATION/$LOGDIR/threadlock.flag

FILE=$1
#echo "LINUX threadlist called with ${FILE} as output."

if [ -f /usr/bin/crash ]
then
	echo "foreach task > ${FILE}" > crash.in
	echo "quit" >> crash.in
	/usr/bin/crash -i crash.in > /dev/null 2> /dev/null
	rm -f crash.in
fi

# remove lock
rm -f $LOCATION/$LOGDIR/threadlock.flag

