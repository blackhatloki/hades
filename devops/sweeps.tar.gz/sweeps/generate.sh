#!/bin/bash 
#ypcat hosts | grep wnl | egrep -v "ilo|vlan|new|old|vip|eth|eqfn|rmds" | awk -F" " ' { print $2 } ' | sort -u > list 
ypcat hosts | grep wnl | egrep -v "ilo|vlan|old|vip|eth|eqfn|rmds" | awk -F" " ' { print $2 } ' | grep -v "new" | sort -u 
