
#ifndef _MGEN_PATTERN
#define _MGEN_PATTERN

#include <stdlib.h>    // for rand(), RAND_MAX
#include <math.h>      // for log()
#include "protoDefs.h" // to get proper struct timeval def

// Helper class to build tables to map strings to values
class StringMapper
{
    public:
        const char* string;
        int         key;
};  // end class StringMapper

class MgenPattern
{
    public:
        MgenPattern();
        ~MgenPattern();
        enum Type {INVALID_TYPE, PERIODIC, POISSON, BURST, JITTER};    
        static Type GetTypeFromString(const char* string);
        
        bool InitFromString(MgenPattern::Type theType, const char* string);
                
        double GetPktInterval();
        unsigned short GetPktSize();
        
    private:
        static const StringMapper TYPE_LIST[]; 
        enum Burst {INVALID_BURST, REGULAR, RANDOM};  
        static const StringMapper BURST_LIST[];
        static Burst GetBurstTypeFromString(const char* string);
        enum Duration {INVALID_DURATION, FIXED, EXPONENTIAL};  
        static const StringMapper DURATION_LIST[];   
        static Duration GetDurationTypeFromString(const char* string);
        
        static double UniformRand(double min, double max)
        {
            double range = max - min;
            return (((((double)rand()) * range) / ((double)RAND_MAX)) + min); 
        }
         
        static double ExponentialRand(double mean)
        {
           return (-(log(1.0 - ( ((double)rand())/((double)RAND_MAX)) )) * mean);  
        }

        Type            type;
        double          interval_ave;
        double          interval_remainder;
        unsigned short  pkt_size;
        double          jitter_min;  // = jitterFraction * interval_ave
        double          jitter_max;  // = interval_ave + jitterFraction
        Burst           burst_type;
        MgenPattern*    burst_pattern;
        Duration        burst_duration_type;
        double          burst_duration_ave;
        double          burst_duration;
        struct timeval  last_time;
};  // end class MgenPattern


#endif //_MGEN_PATTERN
