#ifndef _MGEN_VERSION

#define MGEN_VERSION "4.2b6"

#endif // _MGEN_VERSION

