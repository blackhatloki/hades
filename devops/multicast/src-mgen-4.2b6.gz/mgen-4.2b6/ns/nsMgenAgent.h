#ifndef _NS_MGEN_AGENT
#define _NS_MGEN_AGENT


#include "nsProtoSimAgent.h"   // from Protolib
#include "mgen.h"

// This class lets us "sink" MGEN messages to a
// generic ns-2 transport "Agent"
class NsMgenSink : public MgenSink
{
    public:
        NsMgenSink(Agent* theAgent);
        ~NsMgenSink();
        
        virtual bool SendMgenMessage(const char*           txBuffer,
                                     unsigned int          len,
                                     const ProtoAddress&   dstAddr);
           
    private:
        Agent*  agent;
};  // end class NsMgenSink

class NsMgenAgent : public NsProtoSimAgent
{
    public:
        NsMgenAgent();
        ~NsMgenAgent();
                
        // NsProtoSimAgent base class overrides
        virtual bool OnStartup(int argc, const char*const* argv);
        virtual bool ProcessCommands(int argc, const char*const* argv);
        virtual void OnShutdown();
       
        void SetSink(MgenSink* theSink) {mgen.SetSink(theSink);}
        class Mgen* GetMgenInstance() {return &mgen;}
        void HandleMgenMessage(char*               buffer, 
                               unsigned int        len, 
                               const ProtoAddress& srcAddr)
        {
            mgen.HandleMgenMessage(buffer, len, srcAddr);   
        }
            
    private:  
        static bool GetPosition(const void* agentPtr, GPSPosition& gpsPosition);
        
        Mgen        mgen;     // our MGEN engine
        NsMgenSink* ns_sink;  // ptr to generic ns-2 sink (if applicable)
};  // end class NsMgenAgent

#endif // _NS_MGEN_AGENT
