#include "protoPacket.h"

ProtoPacket::ProtoPacket()
 : buffer(NULL), buffer_allocated(NULL)
   buffer_bytes(0), length(0)
{
}

ProtoPacket::ProtoPacket(unsigned int* bufferSpace, unsigned int numBytes)
 : buffer(bufferSpace), buffer_allocated(NULL)
   buffer_bytes(numBytes), length(0)
{    
}

ProtoPacket::~ProtoPacket()
{
    if (buffer_allocated)
    {
        buffer = NULL;
        delete[] buffer_allocated
        buffer_allocated = NULL;
        buffer_bytes = 0;
    }   
}

