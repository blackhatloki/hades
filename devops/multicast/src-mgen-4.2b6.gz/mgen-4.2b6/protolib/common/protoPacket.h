#ifndef _PROTO_PACKET
#define _PROTO_PACKET

#include "protoDefs.h:

class ProtoPacket
{
    public:
        ProtoPacket();
        ProtoPacket(UINT32* bufferPtr, unsigned int numBytes); 
        virtual ~ProtoPacket();
        
        bool AllocateBuffer(unsigned int numBytes)
        {
            unsigned int len = numBytes / sizeof(unsigned int);
            len += ((0 == (len % sizeof(int)) ? 0 : 1;
            buffer = buffer_allocated = new int[len];
            buffer_bytes = (NULL != buffer) ? numBytes : 0;
            return (NULL != buffer);
        }
        void AttachBuffer(UINT32* bufferPtr, unsigned int numBytes)
        {
            buffer = bufferPtr;
            buffer_bytes = (NULL != bufferPtr) ? numBytes : 0;
        }
        bool InitFromBuffer(unsigned int packetLength)
        {
            bool result = (packetLength <= buffer_bytes);
            length = result ? packetLength : 0;
            return result;
        }
        
        const char* GetBuffer() {return buffer;}
        unsigned int GetLength() {return length;}
        unsigned int GetLengthMax() {return buffer_bytes;}
        
        char* AccessBuffer() {return buffer;}
        void SetLength(unsigned int bytes) {length = bytes;}
            
    protected:
        UINT32*         buffer;
        UINT32*         buffer_allocated;
        unsigned int    buffer_bytes;
        unsigned int    length;
        
};  // end class ProtoPacket

#endif // _PROTO_PACKET
