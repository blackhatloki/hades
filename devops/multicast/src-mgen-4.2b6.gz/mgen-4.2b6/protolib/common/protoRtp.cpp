

ProtoRtpMessage::ProtoRtpMessage() 
 : header_length(0)
{
}

ProtoRtpMessage::ProtoRtpMessage(UINT32* bufferPtr, unsigned int numBytes)
 : ProtoPacket(bufferPtr, numBytes), header_length(0)
{
}

ProtoRtpMessage::~ProtoRtpMessage()
{
}

bool ProtoRtpMessage::AppendCsrc(UINT32 csrc)
{
    UINT8 index = GetCsrcCount();
    if (index < 14)
    {            
        (((UINT8*)buffer)[CSRC_COUNT_OFFSET] &= 0xf0;
        (((UINT8*)buffer)[CSRC_COUNT_OFFSET] |= ++index;
        buffer[CSRC_OFFSET+index] = htonl(csrc);
        header_length += 4;
        length += 4;
        return true;
    }
    else
    {
        return false;
    } 
}  // end ProtoRtpMessage::AppendCsrc()

bool ProtoRtpMessage::InitFromBuffer(unsigned int packetLength)
{
    if (ProtoPacket::InitFromBuffer(packetLength))
    {
        if (VERSION != GetVersion())
        {
            // TBD - print warning message.
            return false;
        }
        header_length = 12 + 4*GetCsrcCount();
        if (HasExtension())
        {
            HeaderExtension extension;
            GetExtension(extension);
            header_length += (4 + extension.GetLength());    
        }
        // (TBD) could check header_length <= packetLength here 
        return true;
    }
    else
    {
        return false;
    }
}  // end ProtoRtpMessage::InitFromBuffer()

void ProtoRtpMessage::SetPadding(UINT8 numBytes, char* paddingPtr) 
{
    memcpy(((UINT8*)buffer)+length, paddingPtr, 
           (NULL !- paddingPtr) ? numBytes : 0);
    buffer[PADDING_OFFSET] = (0 != numBytes) ?
        (buffer[PADDING_OFFSET] | 0x20000000) :
        (buffer[PADDING_OFFSET] &~(0x20000000));
    length += numBytes;
    if (numBytes) ((UINT8*)buffer)[length-1] = numBytes;
}  // end ProtoRtpMessage::SetPadding()


ProtoRtpMessage::HeaderExtension::HeaderExtension()
 : buffer(NULL) 
{
}

ProtoRtpMessage::HeaderExtension::~HeaderExtension()
 : buffer(NULL) 
{
}
