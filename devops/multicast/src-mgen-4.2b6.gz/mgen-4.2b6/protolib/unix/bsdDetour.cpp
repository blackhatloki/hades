
#include "protoDetour.h"
#include "protoSocket.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

class BsdDetour : public ProtoDetour
{
    public:
        BsdDetour();
        ~BsdDetour();
        
        bool Open(int hookFlags                     = 0, 
                  const ProtoAddress& srcFilterAddr = PROTO_ADDR_NONE, 
                  unsigned int        srcFilterMask = 0,
                  const ProtoAddress& dstFilterAddr = PROTO_ADDR_NONE,
                  unsigned int        dstFilterMask = 0);
        void Close();
        bool Recv(char* buffer, unsigned int& numBytes);
        bool Allow(const char* buffer, unsigned int numBytes);
        bool Drop();
        bool Inject(const char* buffer, unsigned int numBytes);
        
        enum {DIVERT_PORT = 2998};
                    
    private:
        enum Action
        {
            INSTALL,
            DELETE
        };
        bool SetIPFirewall(Action action,
                           int hookFlags ,
                           const ProtoAddress& srcFilterAddr, 
                           unsigned int        srcFilterMask,
                           const ProtoAddress& dstFilterAddr,
                           unsigned int        dstFilterMask);
        
        ProtoAddress            pkt_addr;  // iface IP addr for inbound, unspecified for outbound
        
        int                     hook_flags;
        ProtoAddress            src_filter_addr;
        unsigned int            src_filter_mask;
        ProtoAddress            dst_filter_addr;
        unsigned int            dst_filter_mask;
        
        unsigned short          rule_number[3];
        unsigned int            rule_count;
            
};  // end class BsdDetour
    
ProtoDetour* ProtoDetour::Create()
{
    return static_cast<ProtoDetour*>(new BsdDetour());   
}  // end ProtoDetour::Create(), (void*)nl_head  


BsdDetour::BsdDetour()
 : hook_flags(0), rule_count(0)
{
    memset(&pkt_addr, 0, sizeof(struct sockaddr_storage));
}

BsdDetour::~BsdDetour()
{
    Close();
}

bool BsdDetour::SetIPFirewall(Action              action,
                              int                 hookFlags ,
                              const ProtoAddress& srcFilterAddr, 
                              unsigned int        srcFilterMask,
                              const ProtoAddress& dstFilterAddr,
                              unsigned int        dstFilterMask)
{
    // 1) IPv4 or IPv6 address family?
    const char* cmd;
    if (srcFilterAddr.GetType() != dstFilterAddr.GetType())
    {
        DMSG(0, "BsdDetour::SetIPFirewall() error: inconsistent src/dst filter addr families\n");
        return false;
    }
    else if (ProtoAddress::IPv4 == srcFilterAddr.GetType())
    {
        cmd = "/sbin/ipfw";  // IPv4 ipfw
    }
    else if (ProtoAddress::IPv6 == srcFilterAddr.GetType())
    {
        cmd = "/sbin/ip6fw"; // IPv6 ipfw
    }
    else
    {
        DMSG(0, "BsdDetour::SetIPFirewall() error: unspecified filter addr family\n");
        return false;
    }
    // 2) For (DELETE == action) re-interpret hookFlags value as rule number
    if (DELETE == action) hookFlags++;
    // 3) For which firewall hooks?
    while (0 != hookFlags)
    {
        // Make and install "iptables" firewall rules
        const size_t RULE_MAX = 511;
        char rule[RULE_MAX+1];
            
        if (INSTALL == action)
        {
            if (rule_count > 2)
            {
                DMSG(0, "BsdDetour::SetIPFirewall() max ruleCount exceeded!\n");
                return false;    
            }
        
            const char* target;
            if (0 != (hookFlags & OUTPUT))
            {
                target = "out";
                hookFlags &= ~OUTPUT;
            }
            else if (0 != (hookFlags & INPUT))
            {
                target = "in";
                hookFlags &= ~INPUT;
            }
            else if (0 != (hookFlags & FORWARD))
            {
                target = "via any";
                hookFlags &= ~FORWARD;
            }
            else
            {
                break;  // all flags have been processed
            }

            // cmd  = "ipfw" or "ip6fw"
            sprintf(rule, "%s add divert %hu ip ", cmd, DIVERT_PORT);
            if (0 != srcFilterMask)
            {
                strcat(rule, "from ");
                size_t len = strlen(rule);
                if (!srcFilterAddr.GetHostString(rule+len, RULE_MAX - len))
                {
                    DMSG(0, "BsdDetour::SetIPFirewall() error: bad source addr filter\n");
                    return false;
                } 
                len = strlen(rule);
                sprintf(rule+len, "/%hu ", srcFilterMask);
            }
            else
            {
                size_t len = strlen(rule);
                sprintf(rule+len, "from any ");
            }
            if (0 != dstFilterMask)
            {
                strcat(rule, "to ");
                size_t len = strlen(rule);
                if (!dstFilterAddr.GetHostString(rule+len, RULE_MAX - len))
                {
                    DMSG(0, "BsdDetour::SetIPFirewall() error: bad destination addr filter\n");
                    return false;
                } 
                len = strlen(rule);
                sprintf(rule+len, "/%hu ", dstFilterMask);
            }
            else
            {
                size_t len = strlen(rule);
                sprintf(rule+len, "to any ");
            }

            // target = "in", "out", or "via any"
            strcat(rule, target);
        }
        else  // (DELETE == action)
        {
            sprintf(rule, "%s delete %hu\n", cmd, hookFlags - 1);
            hookFlags = 0;
        }
                   
        // Add redirection so we can get stderr result
        strcat(rule, " 2>&1");
        
        FILE* p = popen(rule, "r");
        if (NULL != p)
        {
            char feedback[256];
            fread(feedback, 1, 256, p);
            char* ptr = strchr(feedback, '\n');
            if (NULL != ptr) *ptr = '\0';
            feedback[255] = '\0';
            if (0 == pclose(p))
            {
                if (INSTALL == action)
                {
                    // Add firewall rule number to list for delete on close
                    if (1 != sscanf(feedback, "%05hu\n", rule_number+rule_count))
                    {
                        DMSG(0, "BsdDetour::SetIPFirewall() warning: couldn't record firewall rule number\n");
                        return true;
                    }
                    rule_count++;
                }
            }
            else
            {
                DMSG(0, "BsdDetour::SetIPFirewall() \"%s\" error: %s\n",
                         rule, feedback);
                return false;
            }
        }
        else
        {
            DMSG(0, "BsdDetour::SetIPFirewall() error: popen(%s): %s\n",
                    rule, GetErrorString());
            return false;
        }
    }  // end while (0 != hookFlags)
    return true;
}  // end BsdDetour::SetIPFirewall()

bool BsdDetour::Open(int                 hookFlags, 
                     const ProtoAddress& srcFilterAddr, 
                     unsigned int        srcFilterMask,
                     const ProtoAddress& dstFilterAddr,
                     unsigned int        dstFilterMask)
{
    if (IsOpen()) Close();
    
    int domain;
    if (srcFilterAddr.GetType() != dstFilterAddr.GetType())
    {
        DMSG(0, "BsdDetour::Open() error: inconsistent src/dst filter addr families\n");
        return false;
    }
    else if (ProtoAddress::IPv4 == srcFilterAddr.GetType())
        
    {
        domain = AF_INET;
    }
    else if (ProtoAddress::IPv6 == srcFilterAddr.GetType())
    {
        domain = AF_INET6;
    }
    else
    {
        DMSG(0, "BsdDetour::Open() error: unspecified filter addr family\n");
        return false;
    }
    
    // Setup ipfw rule(s) ...
    // Save parameters for firewall rule removal
    hook_flags = hookFlags;
    src_filter_addr = srcFilterAddr;
    src_filter_mask = srcFilterMask;
    dst_filter_addr = dstFilterAddr;
    dst_filter_mask = dstFilterMask;
    if (0 != hookFlags)
    {
         if (!SetIPFirewall(INSTALL, hookFlags, 
                            srcFilterAddr, srcFilterMask,
                            dstFilterAddr, dstFilterMask))
        {
            DMSG(0, "BsdDetour::Open() error: couldn't install firewall rules\n");   
            Close();
            return false;
        }     
    }
    
    // Open a divert socket ...
    if ((descriptor = socket(domain, SOCK_RAW, IPPROTO_DIVERT)) < 0)
    {
        DMSG(0, "BsdDetour::Open() socket() error: %s\n", GetErrorString());
        Close();
        return false;   
    }
    
    // Bind to our ipfw divert "port"
    UINT16 ipfwPort = DIVERT_PORT;  // (TBD) manage port numbers dynamically?
    struct sockaddr_storage socketAddr;
    socklen_t addrSize;
    if (AF_INET == domain)
    {
        addrSize = sizeof(struct sockaddr_in);
        memset((char*)&socketAddr, 0, sizeof(struct sockaddr_in));    
        ((struct sockaddr_in*)&socketAddr)->sin_family = AF_INET;
        ((struct sockaddr_in*)&socketAddr)->sin_port = htons(ipfwPort);
    }
    else // if (AF_INET6 == domain)
    {
        addrSize = sizeof(struct sockaddr_in6);
        memset((char*)&socketAddr, 0, sizeof(struct sockaddr_in6));    
        ((struct sockaddr_in6*)&socketAddr)->sin6_family = AF_INET6;
        ((struct sockaddr_in6*)&socketAddr)->sin6_port = htons(ipfwPort);
        ((struct sockaddr_in6*)&socketAddr)->sin6_flowinfo = 0;
    }
    if (bind(descriptor, (struct sockaddr*)&socketAddr, addrSize) < 0)
    {
        DMSG(0, "BsdDetour::Open() bind() error: %s\n", GetErrorString());
        Close();
        return false;  
    }
    
    if (!ProtoDetour::Open())
    {
        DMSG(0, "BsdDetour::Open() ProtoChannel::Open() error\n");
        Close();
        return false;   
    }
    
    return true;
}  // end BsdDetour::Open()  

void BsdDetour::Close()
{
    if (0 != hook_flags)
    {
        for (unsigned int i =0; i < rule_count; i++)
            SetIPFirewall(DELETE, (int)rule_number[i],
                          src_filter_addr, src_filter_mask,
                          dst_filter_addr, dst_filter_mask);
        rule_count = 0;
        hook_flags = 0;   
    }
    if (descriptor >= 0)
    {
        ProtoDetour::Close();
        close(descriptor);
        descriptor = INVALID_HANDLE;  
    }
}  // end BsdDetour::Close()

bool BsdDetour::Recv(char* buffer, unsigned int& numBytes)
{
    
    struct sockaddr_storage sockAddr;
    socklen_t addrLen = sizeof(sockAddr);
    size_t result = recvfrom(descriptor, buffer, numBytes, 0, 
                             (struct sockaddr*)&sockAddr, &addrLen);
    if (result < 0)
    {
        pkt_addr.Invalidate();
        switch (errno)
        {
            case EINTR:
            case EAGAIN:
                numBytes = 0;
                return true;
            default:
                numBytes = 0;
                DMSG(0, "BsdDetour::Recv() recvfrom() error: %s\n", GetErrorString());
                return false;
        }   
    }
    else
    {
        pkt_addr.SetSockAddr(*((struct sockaddr*)&sockAddr));      
    }
    numBytes = result;
    return true;
}  // end BsdDetour::Recv()

bool BsdDetour::Allow(const char* buffer, unsigned int numBytes)
{
    if (pkt_addr.IsValid())
    {
        socklen_t addrSize = (ProtoAddress::IPv6 == pkt_addr.GetType()) ?
                                sizeof(struct sockaddr_in6) : sizeof(struct sockaddr_in);
        size_t result = sendto(descriptor, buffer, (size_t)numBytes, 0, 
                               &pkt_addr.GetSockAddr(), addrSize);
        if (result < 0)
        {
            DMSG(0, "BsdDetour::Allow() sendto() error: %s\n", GetErrorString());
            return false;
        }
        pkt_addr.Invalidate();
        return true;
    }
    else
    {   
        DMSG(0, "BsdDetour::Allow() error: no packet pending\n");
        return false;
    }
}  // end BsdDetour::Allow()

bool BsdDetour::Drop()
{   
    if (pkt_addr.IsValid())
    {
        pkt_addr.Invalidate();
        return true;
    }
    else
    {   
        DMSG(0, "BsdDetour::Drop() error: no packet pending\n");
        return false;
    }
}  // end BsdDetour::Drop()

bool BsdDetour::Inject(const char* buffer, unsigned int numBytes)
{
    size_t result = write(descriptor, buffer, (size_t)numBytes);
    if (result != numBytes)
    {
        DMSG(0, "BsdDetour::Inject() write() error: %s\n", GetErrorString());
        return false;     
    }
    return true;
}  // end BsdDetour::Inject()

