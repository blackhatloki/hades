#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#if defined(_LINUX) || defined(_SOLARIS) || defined(_NETBSD) || defined(_SUNOS) || defined(_FREEBSD)
#include <strings.h>
#else
#include <bstring.h>
#endif //
#include <errno.h>
#include <signal.h>

#include "drec.h"
#include "version.h"
#include "drecEvent.h"
#include "startTime.h"
#include "mgenWait.h"
#include "pkt_count.h"
#include "util.h"
#include "sysdefs.h"  /* for DEFAULT_INTERFACE */

#ifdef _RSVP
#include "mgenRsvp.h"
#include "resvList.h"
#endif // _RSVP

#ifndef INADDR_NONE
#define INADDR_NONE 0xffffffff
#endif //

typedef struct DrecSocket
{
    int			fd;
    unsigned short      port;
#ifdef _LIMIT_GROUPS
    int			g_count;
    struct in_addr	group[IP_MAX_MEMBERSHIPS];
#endif // _LIMIT_GROUPS
    struct DrecSocket	*parent;
    struct DrecSocket	*child;
} DrecSocket;


#ifdef _GUI
extern void startGUI(int *argc, char *argv[], int animate);
#endif //

/* Public globals */
DrecMode Mode = SCRIPTED;
char ScriptFile[256];
char LogFile[256];
struct in_addr baseAddress;
int numGroups;
unsigned short defaultPort;
char interfaceName[32];
char StartTime[32];
int Duration;
int Offset;

int flush_output = 0;

/* Private function prototypes */
static void FinishUp();
static int OpenRxSocket(unsigned short *port, int BIND);
static int AppendSocketToList(DrecSocket *theSocket, DrecSocket **theList);
#ifdef _LIMIT_GROUPS
static void RemoveSocketFromList(DrecSocket *theSocket, DrecSocket **theList);
#endif // _LIMIT_GROUPS
static void DestroySocketList(DrecSocket *theList);
static int LoadDrecScript(char *scriptFile, DrecEventList *theList, 
			  RecvPort **scriptPortList, 
			  char *scriptInterfaceName, 
			  char *scriptStartTime);
static int JoinGroup(struct in_addr group_addr, 
		      struct in_addr iface_addr, 
		      DrecSocket     *fd);
static void LeaveGroup(struct in_addr group_addr, 
		      struct in_addr iface_addr, 
		      DrecSocket     *fd);

#ifdef _RSVP
static int HandleResvEvent(DrecEvent *theEvent, struct sockaddr_in *iface_addr, 
			   ResvList *resvList);
static void HandleUnResvEvent(DrecEvent *theEvent, ResvList *resvList);
static int GetResvParams(char *buffer, DrecEvent *theEvent);
#endif // _RSVP

/* Private constants */
static const unsigned short DEFAULT_PORT = 5000;
static const int TXTIME_OFFSET =     4;
static const int FLOW_ID_OFFSET =   12;
static const int DEST_ADDR_OFFSET = 16;
static const int GPS_OFFSET = 20;
static const int PAYLOAD_OFFSET = 36;

const int MSG_SIZE_MAX = 4096;
#ifndef TRUE
static const int TRUE  = 1;
static const int FALSE = 0;
#endif //
#define NOW 0

/* Private variables */
static int GUI_Controlled = 0;
static unsigned long pkt_count = 0;
static DrecEventList eventList, eventTrash;
static FILE *outFile;
static unsigned long Ipkts, Ierrs, Opkts, Oerrs, collide; 
static DrecSocket *socketList = NULL;
#ifdef _LIMIT_GROUPS
static DrecSocket *unboundSocketList;
#endif // _LIMIT_GROUPS
#ifdef _RSVP
static int rsvp_count = 0;
#endif // _RSVP

static void PrintUsage()
{
    printf("\nDREC Version %s Usage:\n", VERSION);
    printf("Scripted   - drec [-fgqv][-p port(s)][-i interface][-S startTime(h:m:s[GMT])][scriptFile] logFile\n");
    printf("           or\n");
    printf("Unscripted - drec -b baseAddress [-fgqv][-p port(s)] [-n numGroups][-i interface]\n");
    printf("                  [-S startTime(h:m:s[GMT])][-d duration (sec)][-o offset (msec)] logFile\n");
}  /* end PrintUsage() */

int main(int argc, char *argv[])
{
    RecvPort *recvPortList = NULL, *nextPort;
    DrecSocket *theSocket,  *nextSocket;
    MgenTicker theTicker;
    DrecEvent *nextEvent;
    unsigned long waitTime, msec, offsetTime;
    double thisTime;
    time_t absoluteStartTime = NOW;
    int max_fd = 0;
    int result;
    struct timeval timeout, beginTime;
    struct timezone tzone;
    fd_set fdset;
    int i;
    
    extern char *optarg;
    extern int optind, opterr;
    register int op;
    int nonopt_argc;
    
    struct sockaddr_in interfaceAddress;
    char *scriptFileName = NULL, *logFileName = NULL;
    RecvPort *scriptPortList = NULL;
    char scriptStartTime[64];
    char scriptInterfaceName[64];
    
    int UseGUI = FALSE;
    int UseAnimation = TRUE;
    int CmdLineInterfaceName = FALSE;
    int CmdLineStartTime = FALSE;
    
    long rxSize;
    struct sockaddr_in remoteAddr;
    int len = sizeof(struct sockaddr_in);
    unsigned long *flowPtr, *seqPtr;
    time_t *txTimePtr;
    unsigned long *txUsecPtr;
    struct tm *tx_time, rx_time;
    struct timeval rxTime;
    struct in_addr *destPtr;  
    char rxBuffer[MSG_SIZE_MAX];
    
    double longitude, latitude;
    long altitude, status;
    unsigned long *gpsLongPtr, *gpsLatPtr, *gpsAltPtr, *gpsStatPtr;
    char* gpsStatus;
    unsigned char* payloadPtr;
    unsigned int payloadLength = 0;
    
#ifdef _RSVP
    ResvList resvList;
    
    resvList.head = NULL;
    resvList.tail = NULL;
#endif // _RSVP
    
    /* Some initializations */
    strcpy(StartTime, "NOW");
    strcpy(interfaceName, DEFAULT_INTERFACE);
    baseAddress.s_addr = INADDR_NONE;
    defaultPort = DEFAULT_PORT;
    Duration = 0;   
    numGroups = 1;
    Offset = 0;
    /* Pointers to MGEN packet payload information */
    seqPtr = (unsigned long *)(rxBuffer);
    txTimePtr = (time_t *) (rxBuffer+TXTIME_OFFSET);
    txUsecPtr = (unsigned long *)(rxBuffer + TXTIME_OFFSET + 4);
    flowPtr = (unsigned long *)(rxBuffer + FLOW_ID_OFFSET);
    destPtr = (struct in_addr *)(rxBuffer + DEST_ADDR_OFFSET);
    
    gpsLongPtr = (unsigned long*)(rxBuffer + GPS_OFFSET);
    gpsLatPtr = (unsigned long*)(rxBuffer + GPS_OFFSET + 4);
    gpsAltPtr = (unsigned long*)(rxBuffer + GPS_OFFSET + 8);
    gpsStatPtr = (unsigned long*)(rxBuffer + GPS_OFFSET + 12);
    payloadPtr = (unsigned char*)(rxBuffer + PAYLOAD_OFFSET);
    
    /* Parse command line arguments */
    optind = 1; 
    opterr = 0;
    while ((op = getopt(argc, argv, "gqvGb:p:n:S:d:o:i:f")) != EOF)
    {
	switch(op)
	{
	    case 'v':
		printf("DREC Version %s\n", VERSION);
		exit(0);
		break;
        
        case 'f':
        flush_output = TRUE;
        break;
		
	    case 'g':
		UseGUI = TRUE;
#ifndef _GUI
		printf("DREC: Not compiled with GUI support!\n");
		exit(0);
#endif // _GUI
		break;
		
	    case 'G':
		GUI_Controlled = TRUE;
		break;
		
	    case 'q':
		UseAnimation = FALSE;
		break;
		
	    case 'b':
		baseAddress.s_addr = inet_addr(optarg);
		if (baseAddress.s_addr == INADDR_NONE)
		{
		    printf("DREC: Invalid baseAddress:destPort!\n");
		    exit(-1);
		}
		Mode = ITERATED;
		break;
	    
	    case 'n':
		numGroups = atoi(optarg);
		if (numGroups < 1)
		{
		    printf("DREC: Invalid numGroups!\n");
		    exit(-1);
		}
		break;
		
	    case 'o':
		Offset = atoi(optarg);
		if (Offset < 0)
		{
		    printf("DREC: Invalid Offset!\n");
		    exit(-1);
		}
		break;
	    
	    case 'd':
		Duration = atoi(optarg);
		if (Duration < 0)
		{
		    printf("DREC: Invalid duration!\n");
		    exit(-1);
		}
		break;
	    
	    case 'p':
		recvPortList = BuildPortList(optarg);
		if(!recvPortList)
		{
		    printf("DREC: Invalid port!\n");
		    exit(-1);
		}
		defaultPort = recvPortList->port;
		break;
	    
	    case 'i':
		strncpy(interfaceName, optarg, 32);
		interfaceName[31] = '\0';
		CmdLineInterfaceName = TRUE;
		break;
	    
	    case 'S':
		strncpy(StartTime, optarg, 32);
		StartTime[31] = '\0';
		CmdLineStartTime = TRUE;
		if ((absoluteStartTime = startTime(StartTime)) < 0)
		{
		    printf("DREC: Invalid start time format!\n");
		    printf("      (hh:mm, hh:mmGMT, or NOW)\n");
		    exit(-1);
		}
		break;
		
	    default:
		fprintf(stderr, "DREC: Invalid command line option: -'%c'\n", op);
		PrintUsage();
		exit(0);
	}
    }
    
    nonopt_argc = argc - optind;
    
    strcpy(ScriptFile, "NONE");
    strcpy(LogFile, "/tmp/drecLog");

    switch(Mode)
    {
	case SCRIPTED:
	    if (nonopt_argc < 1)
	    {
		if (!UseGUI)
		{
		    printf("DREC: Too few arguments!\n");
		    PrintUsage();
		    exit(-1);
		}
	    }
	    else if (nonopt_argc > 2)
	    {
		printf("DREC: Too many arguments!\n");
		PrintUsage();
		exit(-1);
	    }
	    else if (nonopt_argc == 2)
	    {
		strcpy(ScriptFile, argv[optind]);
		scriptFileName = argv[optind];
		strcpy(LogFile, argv[optind+1]);
		logFileName = argv[optind+1];
	    }
	    else
	    {
		strcpy(LogFile, argv[optind]);
		logFileName = argv[optind];
	    }
	    break;
	    
	case ITERATED:
	    if (nonopt_argc < 1)
	    {
		if (!UseGUI)
		{
		    printf("DREC: Too few arguments!\n");
		    PrintUsage();
		    exit(-1);
		}
	    }
	    else if (nonopt_argc > 1)
	    {
		printf("DREC: Too many arguments!\n");
		PrintUsage();
		exit(-1);
	    }
	    else
	    {
		scriptFileName = NULL;
		logFileName = argv[optind];
	    }
	    break;
    }

#ifdef _GUI  
    if (UseGUI) startGUI(&argc, argv, UseAnimation);
#endif // _GUI
    
    /* Print "version" banner */
    fprintf(stdout, "DREC: Version %s\n", VERSION);   
    
    /* Load event queue, if applicable */    
    if (SCRIPTED == Mode)
    {
	if (scriptFileName)
	{
	    scriptPortList = NULL;
	    scriptInterfaceName[0] = '\0';
	    strcpy(scriptStartTime, "NOW");
	    printf("DREC: Loading event queue from script ...\n");
	    if(!LoadDrecScript(scriptFileName, &eventList, 
			       &scriptPortList, scriptInterfaceName, 
			       scriptStartTime))
	    {
		fprintf(stderr, "DREC: Error loading script file!\n");
		DestroySocketList(socketList);
		exit(-1);
	    }
	    if(!recvPortList)  /* No command line port list */
		recvPortList = scriptPortList;
	    else
		DestroyPortList(&scriptPortList);
		
	    if(!CmdLineInterfaceName && strlen(scriptInterfaceName))
		strcpy(interfaceName, scriptInterfaceName);
		
	    if(!CmdLineStartTime)
	    {
		if ((absoluteStartTime = startTime(scriptStartTime)) < 0)
		{
		    printf("DREC: Invalid script start time format!\n");
		    printf("      (hh:mm, hh:mmGMT, or NOW)\n");
		    exit(-1);
		}
	    }
	}
    }
    else  if (IsMulticast(baseAddress)) /* ITERATED mode */
    {
	/* Fill event queue according to command line arguments */
	printf("DREC: Loading event queue ...\n");
	/* "JOIN" events */
	offsetTime = 0;
	for (i = 0; i < numGroups; i++)
	{
	    nextEvent = (DrecEvent *) calloc(1, sizeof(DrecEvent));
	    if (!nextEvent)
	    {
		perror("DREC: calloc(DrecEvent) error");
		DestroyDrecEventList(&eventList);
		DestroySocketList(socketList);
		exit(-1);
	    }
	    nextEvent->cmd = JOIN;
	    nextEvent->time = offsetTime;
	    offsetTime += Offset;
	    nextEvent->addr.sin_addr.s_addr = htonl(ntohl(baseAddress.s_addr) + i);
	    InsertDrecEvent(nextEvent, &eventList);
	}
	/* "LEAVE" events (if any) */
	if (Duration)
	{
	    offsetTime = 0;
	    for (i = 0; i < numGroups; i++)
	    {
		nextEvent = (DrecEvent *) calloc(1, sizeof(DrecEvent));
		if (!nextEvent)
		{
		    perror("DREC: calloc(DrecEvent) error");
		    DestroyDrecEventList(&eventList);
		    DestroySocketList(socketList);
		    exit(-1);
		}
		nextEvent->cmd = LEAVE;
		nextEvent->time = Duration*1000 + offsetTime;
		offsetTime += Offset;
		nextEvent->addr.sin_addr.s_addr = htonl(ntohl(baseAddress.s_addr) + i);
		InsertDrecEvent(nextEvent, &eventList);
	    }
	}
    }
    else  /* Just listen for unicast */
    {
	if (numGroups != 1)
	    printf("DREC: Warning: drec can listen only on _your_ unicast address(es)\n");
    }
    
    /* Open recv file descriptor(s) on appropriate port(s) */
    if (!recvPortList) /* listen on default port */
    {
	theSocket = (DrecSocket *) calloc(1, sizeof(DrecSocket));
	if (!theSocket)
	{
	    perror("DREC: calloc(DrecSocket) error");
	    exit(-1);
	}
	theSocket->port = defaultPort;
	theSocket->fd = OpenRxSocket(&theSocket->port, TRUE);
	if (theSocket->fd < 0)
	{
	    fprintf(stderr, "DREC: OpenRxSocket error\n");
	    free(theSocket);
	    exit(-1);
	}
	max_fd = AppendSocketToList(theSocket, &socketList);
    }
    else  /* listen on user or script supplied port list */
    {   
	nextPort = recvPortList;
	while(nextPort)
	{
	    theSocket = (DrecSocket *) calloc(1, sizeof(DrecSocket));
	    if (!theSocket)
	    {
		perror("DREC: calloc(DrecSocket) error");
		DestroySocketList(socketList);
		exit(-1);
	    }
	    theSocket->port = nextPort->port;
	    theSocket->fd = OpenRxSocket(&theSocket->port, TRUE);
	    if (theSocket->fd < 0)
	    {
		fprintf(stderr, "DREC: OpenRxSocket error\n");
		free(theSocket);
		DestroySocketList(socketList);
		exit(-1);
	    }
	    max_fd = AppendSocketToList(theSocket, &socketList);
	    nextPort = nextPort->next;
	}
    }
    max_fd++; /* "select()" needs a count instead of the actual value */
    DestroyPortList(&recvPortList);
    
    
      
    /* Open log file */
    if (!(outFile = fopen(logFileName, "w+")))
    {
	perror("DREC: Error opening log file");
	DestroySocketList(socketList);
	DestroyDrecEventList(&eventList);
	exit(-1);
    }
    
    /* Get interface IP address and initial stats */
    if(!GetPktCount(interfaceName, 
		    &Ipkts, &Ierrs, 
		    &Opkts, &Oerrs, 
		    &collide, 
		    (unsigned long *)&interfaceAddress.sin_addr.s_addr))
    {
	printf("DREC: Error getting interface statistics for interface: %s!\n", 
		interfaceName);
	interfaceAddress.sin_addr.s_addr = INADDR_ANY;
    }
    interfaceAddress.sin_family = AF_INET;
    interfaceAddress.sin_port = htons(0);
    
    if (scriptFileName)
	printf("DREC: Processing events and listening for packets ...\n");
    else
	printf("DREC: Listening for packets ...\n");
    if (!GUI_Controlled) 
	printf("      (Hit <CTRL-C> to stop)");
    fflush(stdout);
    
    /* Init timing */
    InitMgenTicker(&theTicker);    
    gettimeofday(&beginTime, &tzone);
    
    /* If an absolute start time is given */
    if (absoluteStartTime)
    {
	if (beginTime.tv_sec > absoluteStartTime)
	{
	    if (!GUI_Controlled) 
		printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
	    printf("DREC: Specified startTime has already passed!\n");
	    DestroySocketList(socketList);
	    DestroyDrecEventList(&eventList);
	    exit(-1);
	}
	thisTime = (beginTime.tv_sec - absoluteStartTime) * 1000.0;
	thisTime += (beginTime.tv_usec + 500)/1000;
    }
    else
    {
	thisTime = 0;
    }
    
    /* Install <CTRL-C> signal handler */
    signal(SIGINT, FinishUp);
    
    /* Process events in queue while listening for traffic */
    nextEvent = eventList.head;
    while(nextEvent)
    {
	/* Process any events whose time has come */
	while(nextEvent && (nextEvent->time <= thisTime))
	{
	    gettimeofday(&rxTime, &tzone);
		printf("got event of type %d at time %lu\n", nextEvent->cmd, nextEvent->time);
	    switch(nextEvent->cmd)
	    {
		case JOIN:
		    if (!JoinGroup(nextEvent->addr.sin_addr, 
			      interfaceAddress.sin_addr, 
			      socketList))
		    {
			printf("DREC: Error joining group!\n");
		    }
		    else
		    {
			fprintf(outFile, "JOIN  %16s ", 
			    inet_ntoa(nextEvent->addr.sin_addr));
			tx_time = gmtime((time_t *)&rxTime.tv_sec);
			fprintf(outFile, "Time>%02d:%02d:%02d.%06lu\n",
			    tx_time->tm_hour, 
			    tx_time->tm_min,
			    tx_time->tm_sec,
			    rxTime.tv_usec); 
		    }
		    break;
		    
		case LEAVE:
		    LeaveGroup(nextEvent->addr.sin_addr,
			       interfaceAddress.sin_addr, 
			       socketList);
		    fprintf(outFile, "LEAVE %16s ", 
			inet_ntoa(nextEvent->addr.sin_addr));
		    tx_time = gmtime((time_t *)&rxTime.tv_sec);
		    fprintf(outFile, "Time>%02d:%02d:%02d.%06lu\n",
			tx_time->tm_hour, 
			tx_time->tm_min,
			tx_time->tm_sec,
			rxTime.tv_usec); 
		    break;
#ifdef _RSVP		    
		case RESV:
		    if (!HandleResvEvent(nextEvent, &interfaceAddress, &resvList))
		    {
			printf("DREC: RESV failed! (Is 'rsvpd'running?)\n");
		    }
		    /* (TBD) Log RESV event info */
		    break;
		    
		case UNRESV:
		    HandleUnResvEvent(nextEvent, &resvList);
		    /* (TBD) Log UNRESV event info */
		    break;
            
#endif // _RSVP

        case EXIT:
            FinishUp();
            break;
		    
		default:
		    break;
	    }
	    nextEvent = DiscardDrecEvent(nextEvent, &eventList, &eventTrash);
	}  /* end while(nextEvent && (nextEvent->time <= thisTime)) */
	
	if (nextEvent) 
	{
	    waitTime = nextEvent->time - thisTime;
	    
	    /* select() on recv file descriptor(s), with a "waitTime" timeout */
	    while (waitTime > theTicker.count)
	    {
		/* Set "select()" timeout */
		msec = waitTime - theTicker.count;
		timeout.tv_sec = msec/1000;
		timeout.tv_usec = (msec - (timeout.tv_sec*1000))*1000;
		
		/* Fill fd_set with file descriptors from our socketList */
		FD_ZERO(&fdset);
		nextSocket = socketList;
		while(nextSocket)
		{
		    FD_SET(nextSocket->fd, &fdset);
		    nextSocket = nextSocket->child;
		}
		/* Block on select until packet or timeout */
		result = select(max_fd, (fd_set *) &fdset, (fd_set *) NULL, 
			    (fd_set *) NULL, &timeout);
		switch(result)
		{
		    case -1:
			perror("DREC: select() error:");
			break;
			
		    case 0:
			/* select() timed out */
			break;
			
		    default:
			/* What time were these packets received? */
			gettimeofday(&rxTime, &tzone);
			memcpy(&rx_time, gmtime((time_t *)&rxTime.tv_sec), sizeof(struct tm));
							
			/* Check socket list, handling any fd's that are ready */
			nextSocket = socketList;
			while(nextSocket)
			{
			    if (FD_ISSET(nextSocket->fd, &fdset))
			    {
				if ((rxSize = recvfrom (nextSocket->fd, rxBuffer, 
							MSG_SIZE_MAX, 0, (struct sockaddr *)&remoteAddr, 
							&len)) < 0)
				{
				    if (errno != EINTR) perror("DREC: recvfrom()error");
				}
				else
				{
				    pkt_count++;
				    /* Log packet info */
				    
				    /* FlowID */
				    fprintf(outFile, "Flow>%04lu ", ntohl(*flowPtr));
				    
				    /* Sequence number */
				    fprintf(outFile, "Seq>%06ld ", ntohl(*seqPtr)); /* seq Number */	
				    
				     /* Source address */
				    fprintf(outFile, "Src>%16s/%-5hd ",  
						inet_ntoa(remoteAddr.sin_addr), 
						ntohs(remoteAddr.sin_port));
						
				    /* Destination address */
				    fprintf(outFile, "Dest>%16s/%-5hd ",  
						inet_ntoa(*destPtr), 
						nextSocket->port);
				    
				    /* TxTime */
				    *txTimePtr = ntohl(*txTimePtr);
				    *txUsecPtr = ntohl(*txUsecPtr);
				    tx_time = gmtime((time_t *)txTimePtr);
				    fprintf(outFile, "TxTime>%02d:%02d:%02d.%06lu ",     /* print TxTime */
					tx_time->tm_hour, 
					tx_time->tm_min,
					tx_time->tm_sec,
					*txUsecPtr);
					
				    /* RxTime */
				    fprintf(outFile, "RxTime>%02d:%02d:%02d.%06lu ",     /* print RxTime */
					rx_time.tm_hour, 
					rx_time.tm_min,
					rx_time.tm_sec,
					rxTime.tv_usec);
					
				    /* Packet size */
				    fprintf(outFile, "Size>%04ld ", rxSize); 
                    
                    /* GPS Location Info 1 */
                    longitude = (((double)ntohl(*gpsLongPtr)) / 60000.0) - 180.0;
                    latitude = (((double)ntohl(*gpsLatPtr)) / 60000.0) - 180.0;
                    altitude = ntohl(*gpsAltPtr);
                    status = ntohl(*gpsStatPtr);
                    switch (status)
                    {
                        case 1:
                            gpsStatus = "STALE ";
                            break;    
                        case 2:   
                            gpsStatus = "CURRENT";
                            break;
                        default:
                            gpsStatus = "INVALID";
                            break;
                    }
                    fprintf(outFile, "GPS>%s Long>%09.6f Lat>%09.6f Alt:%ld ", 
                            gpsStatus, longitude, latitude, altitude);
                    
                    payloadLength = (unsigned int) payloadPtr[0];
                    if (payloadLength) fprintf(outFile, "payload>");
                    for (i = 1; i <= payloadLength; i++)
                        fprintf(outFile, "%02x", payloadPtr[i]);
                    fprintf(outFile, "\n");
                    if (flush_output) fflush(outFile);
				}  /* end if/else(rxSize < 0) */  	
			    }  /* end if(FD_ISSET) */
			    nextSocket = nextSocket->child;
			}  /* end while(nextSocket) */
			break;
		}  /* end switch(result) */
		UpdateMgenTicker(&theTicker);
	    }  /* end while(waitTime > theTicker.count) */
	    theTicker.count -= waitTime;
	    thisTime += waitTime;
#ifdef _RSVP
	    if (rsvp_count) rapi_dispatch();
#endif // _RSVP
	}  /* end if(nextEvent) */
    }  /* end while(nextEvent) */
    
    /* Sit and monitor descriptors, dispatching RSVP events periodically */
    if (scriptFileName || Duration)
    {
	if (!GUI_Controlled)
	    printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");   
	printf("DREC: Event queue empty, still listening for packets ...\n");
	if (!GUI_Controlled)
	    printf("      (Hit <CTRL-C> to stop)");
	fflush(stdout);
    }
    
    for(;;)
    {
	/* Block on select until packet or timeout */
	    timeout.tv_sec = 0;
	    timeout.tv_usec = 500000;  /* 500 msec timeout */
	    /* Fill fd_set with file descriptors from our socketList */
	    FD_ZERO(&fdset);
	    nextSocket = socketList;
	    while(nextSocket)
	    {
		FD_SET(nextSocket->fd, &fdset);
		nextSocket = nextSocket->child;
	    }
	    result = select(max_fd, (fd_set *) &fdset, (fd_set *) NULL, 
			(fd_set *) NULL, &timeout);
	    switch(result)
	    {
		case -1:
		    perror("DREC: select() error:");
		    break;
		    
		case 0:
		    /* select() timed out */
		    break;
		    
		default:
		    /* What time were these packets received? */
		    gettimeofday(&rxTime, &tzone);
		    memcpy(&rx_time, gmtime((time_t *)&rxTime.tv_sec), sizeof(struct tm));
			
		    /* Check socket list, handling any fd's that are ready */
		    nextSocket = socketList;
		    while(nextSocket)
		    {
			if (FD_ISSET(nextSocket->fd, &fdset))
			{
			    if ((rxSize = recvfrom (nextSocket->fd, rxBuffer, 
						      MSG_SIZE_MAX, 0, (struct sockaddr *)&remoteAddr,
						       &len)) < 0)
			    {
				if (errno != EINTR) perror("DREC: recvfrom()error");
			    }
			    else
			    {
				pkt_count++;
				/* Log packet info */
				
				/* FlowID */
				fprintf(outFile, "Flow>%04lu ", ntohl(*flowPtr));
				
				/* Sequence number */
				fprintf(outFile, "Seq>%06ld ", ntohl(*seqPtr)); /* seq Number */	
				
				 /* Source address */
				fprintf(outFile, "Src>%16s/%-5hd ",  
					    inet_ntoa(remoteAddr.sin_addr), 
					    ntohs(remoteAddr.sin_port));
					    
				/* Destination address */
				fprintf(outFile, "Dest>%16s/%-5hd ",  
					    inet_ntoa(*destPtr), 
					    nextSocket->port);
				
				/* TxTime */
				*txTimePtr = ntohl(*txTimePtr);
				*txUsecPtr = ntohl(*txUsecPtr);
				tx_time = gmtime((time_t *)txTimePtr);
				fprintf(outFile, "TxTime>%02d:%02d:%02d.%06lu ",     /* print TxTime */
				    tx_time->tm_hour, 
				    tx_time->tm_min,
				    tx_time->tm_sec,
				    *txUsecPtr);
				    
				/* RxTime */
				fprintf(outFile, "RxTime>%02d:%02d:%02d.%06lu ",     /* print RxTime */
				    rx_time.tm_hour, 
				    rx_time.tm_min,
				    rx_time.tm_sec,
				    rxTime.tv_usec);
				    
				/* Packet size */
				fprintf(outFile, "Size>%04ld ", rxSize);   
                
                /* GPS Location Info 2 */
                longitude = (((double)ntohl(*gpsLongPtr)) / 60000.0) - 180.0;
                latitude = (((double)ntohl(*gpsLatPtr)) / 60000.0) - 180.0;
                altitude = ntohl(*gpsAltPtr);
                status = ntohl(*gpsStatPtr);
                switch (status)
                {
                    case 1:
                        gpsStatus = "STALE ";
                        break;    
                    case 2:   
                        gpsStatus = "CURRENT";
                        break;
                    default:
                        gpsStatus = "INVALID";
                        break;
                }
                fprintf(outFile, "GPS>%s Long>%09.6f Lat>%09.6f Alt:%ld ", 
                        gpsStatus, longitude, latitude, altitude);
				
                payloadLength = (unsigned int) payloadPtr[0];
                if (payloadLength) fprintf(outFile, "payload>");
                for (i = 1; i <= payloadLength; i++)
                    fprintf(outFile, "%02x", payloadPtr[i]);
                fprintf(outFile, "\n");
                    
                if (flush_output) fflush(outFile); 
			    }  /* end if/else(rxSize < 0) */  	
			}  /* end if(FD_ISSET) */
			nextSocket = nextSocket->child;
		    }  /* end while(nextSocket) */
		    break;
	    }  /* end switch(result) */
#ifdef _RSVP
	    if (rsvp_count) rapi_dispatch();
#endif // _RSVP
    }  /* end for(;;) */
}  /* end main() */

/* <CTRL-C> signal handler */
static void FinishUp()
{
    unsigned long new_Ipkts, new_Ierrs, new_Opkts, new_Oerrs, new_collide;
    unsigned long pkts, errs;
    struct in_addr interfaceAddress;
    
    if(!GetPktCount(interfaceName, 
		    &new_Ipkts, &new_Ierrs, 
		    &new_Opkts, &new_Oerrs, 
		    &new_collide, 
		    (unsigned long *) &interfaceAddress.s_addr))
    {
	fprintf(stderr, "MGEN: Error getting interface statistics for %s\n", interfaceName);
	new_Ipkts = 0;
	new_Ierrs = 0;
	new_Opkts = 0;
	new_Oerrs = 0;
	new_collide = 0;
	interfaceAddress.s_addr = INADDR_ANY;
    }
    
    pkts = new_Ipkts - Ipkts;
    errs = new_Ierrs - Ierrs;
    
    if (!GUI_Controlled)
	printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b"); 
    /* Close log file */
    printf("DREC: Closing log file ...   \n");
    fclose(outFile);
    
    /* Close sockets */
    DestroySocketList(socketList);
#ifdef _LIMIT_GROUPS
    DestroySocketList(unboundSocketList);
#endif // 
    /* Empty event lists */
    DestroyDrecEventList(&eventList);
    DestroyDrecEventList(&eventTrash);
    
    printf("DREC: Packets logged: %lu\n", pkt_count);
    printf("DREC: Interface Stats    : %8s\n", interfaceName);
    printf("           Frames Recv'd : %8lu\n", pkts);
    printf("               Rx Errors : %8lu\n", errs);
    printf("DREC: Done.\n");
    exit(0);
}  /* end FinishUp() */

#ifdef _RSVP

static int HandleResvEvent(DrecEvent *theEvent, struct sockaddr_in *iface_addr, 
			   ResvList *resvList)
{
    ResvItem *resvItem;
    
    /* First check to see if we already have an RSVP session for this dest */
    resvItem = FindResvItemByAddress(&theEvent->addr, resvList);
    if (!resvItem)
    {
	if(!(resvItem = (ResvItem *) calloc(1, sizeof(ResvItem))))
	{
	    perror("DREC: calloc(ResvItem) error");
	    return FALSE;
	}
	if((resvItem->sessID = RsvpSession(&theEvent->addr, 0)) < 0)
	{
	    fprintf(stderr, "DREC: RsvpSession() error!\n");
	    free(resvItem);
	    return FALSE;
	}
	rsvp_count++;  /* rsvp session count */
	memcpy(&resvItem->addr, &theEvent->addr, sizeof(struct sockaddr_in));
	AppendResvItem(resvItem, resvList);
    }
    
    /* Now attempt reservation using event parameters */
    if (!RsvpReserve(resvItem->sessID, (DrecEvent *) theEvent, iface_addr))
    {
	printf("DREC: RsvpReserve error!\n");
	RsvpRelease(resvItem->sessID); 
	rsvp_count--;
	DeleteResvItem(resvItem, resvList);
	return FALSE;
    }   
    return TRUE;
}  /* end HandleResvEvent() */


static void HandleUnResvEvent(DrecEvent *theEvent, ResvList *resvList)
{
    ResvItem *resvItem;
    
    /* First check to see if we already have an RSVP session for this dest */
    resvItem = FindResvItemByAddress(&theEvent->addr, resvList);
    if (resvItem)
    {
	RsvpRelease(resvItem->sessID);
	rsvp_count--;
	DeleteResvItem(resvItem, resvList);
    }
    else
    {
	fprintf(stderr, "DREC: UNRESV Error! No reservation for %s:%hd\n", 
		inet_ntoa(theEvent->addr.sin_addr), 
		ntohs(theEvent->addr.sin_port));
    }
}  /* end HandleUnResvEvent() */

#endif // _RSVP

static int LoadDrecScript(char *scriptFile, DrecEventList *theList, 
			  RecvPort **scriptPortList, 
			  char *scriptInterfaceName, 
			  char *scriptStartTime)
{
    FILE *inFile;
    int line = 0;
    DrecCmd cmd;
    unsigned long msec;
    char cmd_text[16], IPAddr[32];
#ifdef _RSVP
    char resv_style[64];
    unsigned short temp_short;
    char *strPtr;
#endif // _RSVP
    char scriptBuffer[MAXLINES];
    DrecEvent *newEvent = NULL;
    
    /* Open the script file */
    if ( (inFile = fopen(scriptFile, "r") ) == NULL)
    {
	perror("DREC: Error opening scriptfile");
	return FALSE;
    }
    
    /* Parse script one line at a time, creating flowList */
    strcpy(scriptBuffer, " ");
    while(readline(inFile, scriptBuffer))
    {
	line++;
	
	/* Determine line's script command type */
	if (!strncmp(scriptBuffer, "START", 5))
	{
	    cmd = START;
	}
	else if (!strncmp(scriptBuffer, "PORT", 4))
	{
	    cmd = PORT;
	}
	else if (!strncmp(scriptBuffer, "INTERFACE", 9))
	{
	    cmd = INTERFACE;
    }
	else if (scriptBuffer[0] == '#')
	{
	    cmd = (DrecCmd) NULL;  /* Comment line */
	}
	else if (2 == sscanf(scriptBuffer, "%lu %8s", &msec, cmd_text))
	{
	    if (!strcmp(cmd_text, "JOIN"))
		cmd = JOIN;
	    else if (!strcmp(cmd_text, "LEAVE"))
		cmd = LEAVE;
        else if (!strcmp(cmd_text, "EXIT"))
        cmd = EXIT;
#ifdef _RSVP
	    else if (!strcmp(cmd_text, "RESV"))
		cmd = RESV;
	    else if (!strcmp(cmd_text, "UNRESV"))
		cmd = UNRESV;
#endif // _RSVP
	    else
	    {
		fprintf(stderr, "DREC: Bad script command at line %d\n", line);
		cmd = NULL_CMD;
	    }
	    if (cmd)
	    {
		newEvent = (DrecEvent *) calloc(1, sizeof(DrecEvent));
		if(!newEvent)
		{
		    perror("DREC: calloc(DrecEvent) error");
		    DestroyDrecEventList(theList);
		    fclose(inFile);
		    return FALSE;
		}
	    }
	}
	else
	{
	    /* Assume it's a comment or blank line */
	    cmd = NULL_CMD;
	}	
	
	switch(cmd)
	{
	    case START:
		if (2 != sscanf(scriptBuffer, "%s %32s", cmd_text, scriptStartTime))
		{
		    fprintf(stderr, "DREC: Script startTime error at line %d\n", line);		    
		    DestroyDrecEventList(theList);
		    fclose(inFile);
		    return FALSE;
		}
		break;
		
	    case PORT:
		if(!(*scriptPortList = 
			BuildPortList(scriptBuffer + strlen("PORT"))))
		{
		    fprintf(stderr, "DREC: Script startTime error at line %d\n", line);		    
		    DestroyDrecEventList(theList);
		    fclose(inFile);
		    return FALSE;
		}
		break;
		
	    case INTERFACE:
		if (2 != sscanf(scriptBuffer, "%s %32s", cmd_text, scriptInterfaceName))
		{
		    fprintf(stderr, "DREC: Script interfaceName error at line %d\n", line);		    
		    DestroyDrecEventList(theList);
		    fclose(inFile);
		    return FALSE;
		}
		break;
		
	    case JOIN:
		if(3 == sscanf(scriptBuffer, "%lu %8s %16s", &msec, cmd_text, 
				IPAddr))
		{
		    newEvent->cmd = JOIN;
		    newEvent->time = msec;
		    if ( (newEvent->addr.sin_addr.s_addr = inet_addr(IPAddr)) 
			 != INADDR_NONE)
		    {
		      InsertDrecEvent(newEvent, theList);
		    }
		    else 
		    {						
		      fprintf(stderr, "DREC: IP address error at line %d\n", line);
		      free(newEvent);
		      fclose(inFile);
		      return FALSE;
		    }
		}
		else
		{
		    fprintf(stderr, "DREC: Bad JOIN command at line %d\n", line);
		    free(newEvent);
		    fclose(inFile);
		    return FALSE;
		}
		break;
		
	    case LEAVE:
		if(3 == sscanf(scriptBuffer, "%lu %8s %16s", &msec, cmd_text, 
				IPAddr))
		{
		    newEvent->cmd = LEAVE;
		    newEvent->time = msec;
		    if ( (newEvent->addr.sin_addr.s_addr = inet_addr(IPAddr)) 
			 != INADDR_NONE)
		    {
		      InsertDrecEvent(newEvent, theList);
		    }
		    else 
		    {						
		      fprintf(stderr, "DREC: IP address error at line %d\n", line);
		      free(newEvent);
			  fclose(inFile);
		      return FALSE;
		    }
		}
		else
		{
		    fprintf(stderr, "DREC: Bad LEAVE command at line %d\n", line);
		    free(newEvent);
		    fclose(inFile);
		    return FALSE;
		}
		break;
    
        case EXIT:
		if(2 == sscanf(scriptBuffer, "%lu %8s", &msec, cmd_text))
		{
		    newEvent->cmd = EXIT;
		    newEvent->time = msec;
            InsertDrecEvent(newEvent, theList);
		}
        else
        {
            fprintf(stderr, "DREC: Bad EXIT command at line %d\n", line);
		    free(newEvent);
		    fclose(inFile);
		    return FALSE;
        }
		break;

#ifdef _RSVP		
	    case RESV:
		if(3 == sscanf(scriptBuffer, "%lu %s %s",
				&msec, cmd_text, resv_style))
		{
		    newEvent->cmd = RESV;
		    newEvent->time = msec;
		    strPtr = strstr(scriptBuffer, resv_style);
		    if(GetResvParams(strPtr, newEvent))
		    {
			InsertDrecEvent(newEvent, theList);
		    }
		    else
		    {
			fprintf(stderr, "DREC: Error parsing RESV params at line %d\n", line);
			free(newEvent);
			fclose(inFile);
			return FALSE;
		    }
		}
		else
		{
		    fprintf(stderr, "DREC: Bad RESV command at line %d\n", line);
		    free(newEvent);
		    fclose(inFile);
		    return FALSE;
		}
		break;
		
	    case UNRESV:
		if(3 == sscanf(scriptBuffer, "%lu %s %s",
				&msec, cmd_text, IPAddr))
		{
		    newEvent->cmd = UNRESV;
		    newEvent->time = msec;
		    strPtr = strchr(IPAddr, ':');
		    if (strPtr)
		    {
			*strPtr = '\0';
			if ( (newEvent->addr.sin_addr.s_addr = inet_addr(IPAddr)) 
			     == INADDR_NONE)
			{
			    fprintf(stderr, "DREC: Bad UNRESV command at line %d\n", line);
			    free(newEvent);
			    fclose(inFile);
			    return FALSE;
			}
			if (1 != sscanf(strPtr+1, "%hu", &temp_short))
			{
			    fprintf(stderr, "DREC: Bad UNRESV command at line %d\n", line);
			    free(newEvent);
			    fclose(inFile);
			    return FALSE;
			}
			newEvent->addr.sin_port = htons(temp_short);
			newEvent->addr.sin_family = AF_INET;
			InsertDrecEvent(newEvent, theList);
		    }
		    else
		    {
			fprintf(stderr, "DREC: Bad UNRESV command at line %d\n", line);
			free(newEvent);
			fclose(inFile);
			return FALSE;
		    }
		}
		else
		{
		    fprintf(stderr, "DREC: Bad UNRESV command at line %d\n", line);
		    free(newEvent);
		    fclose(inFile);
		    return FALSE;
		}
		break;
#endif // _RSVP
		
	    case NULL_CMD:
		/* Do nothing */
		break;
		
	    default:
		/* This shouldn't happen, but you never know */
		fprintf(stderr, "DREC:  Attempted to process invalid command!\n");
		free(newEvent);
		break;
	}
	strcpy(scriptBuffer, " ");
    }  /* end while(readline) */
    
    fclose(inFile);
    return TRUE;
    
}  /* end LoadDrecScript() */

/* Scan Drec script for PORT, INTERFACE, or START commands */
int PreLoadDrecScript(char *scriptFile, 
		      char *portString, 
		      char *interfaceString, 
		      char *startString)
{
    FILE *inFile;
    int line = 0, count = 0;
    DrecCmd cmd;
    char cmd_text[16];
    char scriptBuffer[MAXLINES];
    
    /* Open the script file */
    if ( (inFile = fopen(scriptFile, "r") ) == NULL)
    {
	perror("DREC: Error opening scriptfile");
	return FALSE;
    }
    
    /* Parse script one line at a time, creating flowList */
    strcpy(scriptBuffer, " ");
    while(readline(inFile, scriptBuffer) && count < 3)
    {
	line++;
	
	/* Determine line's script command type */
	if (!strncmp(scriptBuffer, "START", 5))
	{
	    cmd = START;
	    count++;
	}
	else if (!strncmp(scriptBuffer, "PORT", 4))
	{
	    cmd = PORT;
	    count++;
	}
	else if (!strncmp(scriptBuffer, "INTERFACE", 9))
	{
	    cmd = INTERFACE;
	    count++;
	}
	else 
	{
	    cmd = (DrecCmd) NULL;  /* Comment line */
	}
	
	switch(cmd)
	{
	    case START:
		if (2 != sscanf(scriptBuffer, "%s %32s", cmd_text, startString))
		{
		    fprintf(stderr, "DREC: Script START command error at line %d\n", line);		    
		    fclose(inFile);
		    return FALSE;
		}
		break;
		
	    case PORT:
		if (2 != sscanf(scriptBuffer, "%s %s", cmd_text, portString))
		{
		    fprintf(stderr, "DREC: Script PORT command error at line %d\n", line);		    
		    fclose(inFile);
		    return FALSE;
		}
		break;
		
	    case INTERFACE:
		if (2 != sscanf(scriptBuffer, "%s %32s", cmd_text, interfaceString))
		{
		    fprintf(stderr, "DREC: Script INTERFACE command error at line %d\n", line);		    
		    fclose(inFile);
		    return FALSE;
		}
		break;
		
	    case NULL_CMD:
		/* Do nothing */
		break;
		
	    default:
		/* This shouldn't happen, but you never know */
		fprintf(stderr, "DREC:  Attempted to process invalid command!\n");
		break;
	}
	strcpy(scriptBuffer, " ");
    }  /* end while(readline) */
    
    fclose(inFile);
    return TRUE;
}  /* end PreLoadDrecScript() */

#ifdef _RSVP

static int GetResvParams(char *buffer, DrecEvent *theEvent)
{
    unsigned short thePort;
    char resv_style[32], IPAddr[32], filtSpec[64], temp_string[64];
    char *start, *filt_mid, *flow_start, *strPtr;
    char *filtPtr, *flowPtr;
    struct in_addr filtAddr;
    int filtPort;
    float32_t resv_R, resv_S, resv_r, resv_b, resv_p;
    u_int32_t resv_m, resv_M;
    int resv_type = -1;
    int num_filts, num_flows;
    
    int filtSize = sizeof(rapi_filter_base_t) + sizeof (rapi_hdr_t);
    
    if (2 != sscanf(buffer, "%s %s", IPAddr, resv_style))
    {
	return FALSE;
    }
    
    /* Check RESV style */
    if (!strcmp(resv_style, "FF"))
	theEvent->rsvp.style = RAPI_RSTYLE_FIXED;
    else if (!strcmp(resv_style, "WF"))
	theEvent->rsvp.style = RAPI_RSTYLE_WILDCARD;
    else if (!strcmp(resv_style, "SE"))
	theEvent->rsvp.style = RAPI_RSTYLE_SE;
    else
	return FALSE;
    
    /* Check RESV session IP address */
    theEvent->addr.sin_family = AF_INET;
    strPtr = strchr(IPAddr, ':');
    *strPtr++ = '\0';  /* strPtr now points at port string */
    
    if((theEvent->addr.sin_addr.s_addr = inet_addr(IPAddr)) == INADDR_NONE)
	return FALSE;
		
    if(1 != sscanf(strPtr, "%hu", &thePort))
	return FALSE;
    theEvent->addr.sin_port = htons(thePort);
    
    
	
    /* Pointer to start of filterspecs & flowspecs */
    start = strstr(buffer, resv_style) + strlen(resv_style);
    filt_mid = strchr(start, ':');
    flow_start = strchr(start, '[');
    
    /* Count the number of filterspecs */    
    strPtr = filt_mid;
    while(strPtr)
    {
	theEvent->rsvp.nfilts++;
	strPtr = strchr(strPtr+1, ':');
    }
    
    /* Count the number of flowspecs */    
    strPtr = strchr(flow_start, '[');
    while(strPtr)
    {
	theEvent->rsvp.nflows++;
	strPtr = strchr(strPtr+1, ':');
    }
    
    switch(theEvent->rsvp.style)
    {
	case RAPI_RSTYLE_FIXED:
	    /* nfilts == nflows for FIXED */
	    if(!theEvent->rsvp.nfilts || (theEvent->rsvp.nfilts != theEvent->rsvp.nflows))
	    {
		printf("DREC: Invalid FF filterSpec/flowSpec pair(s)!\n");
		return FALSE;
	    }
	    break;
	    
	case RAPI_RSTYLE_WILDCARD:
	    if (theEvent->rsvp.nfilts)
	    {
		printf("DREC: FilterSpecs not used for WILDCARD style!\n");
		return FALSE;
	    }
	    break;
	    
	case RAPI_RSTYLE_SE:
	    if (theEvent->rsvp.nflows != 1)
	    {
		printf("DREC: SHARED_EXPLICIT style expects one flowSpec!\n");
		return FALSE;
	    }
	    if (!theEvent->rsvp.nfilts)
	    {
		printf("DREC: SHARED_EXPLICIT style expects at least one filterSpec!\n");
		return FALSE;
	    }
	    break;
	    
	default:
	    /* This shouldn't occur */
	    return FALSE;
    }  /* end switch(theEvent->rsvp.style) */
    
    /* ALlocate memory for RSpecs */
    if (theEvent->rsvp.nflows)
    {
	if(!(theEvent->rsvp.flows = 
		(rapi_flowspec_t *)calloc(theEvent->rsvp.nflows, 
					  sizeof(rapi_flowspec_t))))
	{
	    perror("DREC: calloc(flowSpec) error");
	    return FALSE;
	}
    }
    else
    {
	printf("DREC: Missing flowSpec!\n");
	return FALSE;
    }
    
    /* Allocate memory for filterSpecs */
    if (theEvent->rsvp.nfilts)
    {
	/* Allocate space for filterSpec(s) */
	if(!(theEvent->rsvp.filts = 
		    (rapi_filter_t *) calloc(theEvent->rsvp.nfilts, 
					     filtSize)))
	{
	    perror("DREC: calloc(filterSpec) error");
	    free(theEvent->rsvp.flows);
	    return FALSE;
	}
    }
    else
    {
	filtPtr = NULL;
    }
    
    
    filtPtr = (char *) theEvent->rsvp.filts;
    flowPtr = (char *) theEvent->rsvp.flows;
    num_filts = 0;
    num_flows = 0;
    
    while(filt_mid || flow_start)
    {
	if (filt_mid && ((flow_start > filt_mid) || !flow_start))
	{
	    /* Read filter spec */
	    if (1 != sscanf(start, "%s", filtSpec))
	    {
		printf("DREC: Error parsing filter spec!\n");
		free(theEvent->rsvp.filts);
		free(theEvent->rsvp.flows);
		return FALSE;
	    }
	    start = strstr(start, filtSpec) + strlen(filtSpec);
	    
	    if ((strPtr = strchr(filtSpec, ':')))
	    {
		*strPtr = '\0';
	    }
	    else
	    {
		printf("DREC: Error parsing filter spec!\n");
		free(theEvent->rsvp.filts);
		free(theEvent->rsvp.flows);
		return FALSE;
	    }
	    IPAddr[0] = '\0';
	    sscanf(filtSpec, "%s", IPAddr);
	    
	    if((filtAddr.s_addr = inet_addr(IPAddr)) == INADDR_NONE)
	    {
		printf("DREC: Error parsing filter spec address!\n");
		free(theEvent->rsvp.filts);
		free(theEvent->rsvp.flows);
		return FALSE;
	    }
	    
	    if (1 != sscanf(filt_mid+1, "%d", &filtPort))
	    {
		printf("DREC: Error parsing filter spec port!\n");
		free(theEvent->rsvp.filts);
		free(theEvent->rsvp.flows);
		return FALSE;
	    }
	    
	    GetFilterSpec(filtAddr, filtPort, (rapi_filter_t *) filtPtr);
	    filtPtr += filtSize;
	     
	    if (++num_filts < theEvent->rsvp.nfilts)
		filt_mid = strchr(filt_mid+1, ':');
	    else
		filt_mid = NULL;
	}
	else if (flow_start)
	{
	    /* Read flow spec */
	    sscanf(flow_start+1, "%s", temp_string);
	    if (!strcmp(temp_string, "gx"))
		resv_type = QOS_GUARANTEED;
	    else if (!strcmp(temp_string, "cl"))
		resv_type = QOS_CNTR_LOAD;
	    else
	    {
		fprintf(stderr, "DREC: Invalid flowspec type! (use 'gx' or 'cl')\n");
		free(theEvent->rsvp.filts);
		free(theEvent->rsvp.flows);
		return FALSE;
	    }
	    
	    switch(resv_type)
	    {
		case QOS_GUARANTEED:
		    if (8 != sscanf(flow_start+1, "%s %f %f %f %f %f %u %u",
					    temp_string,
					    &resv_R, &resv_S, &resv_r, 
					    &resv_b, &resv_p, &resv_m, 
					    &resv_M))
		    {
			fprintf(stderr, "DREC: Error parsing GX flowspec!\n");
			free(theEvent->rsvp.filts);
			free(theEvent->rsvp.flows);
			return FALSE;
		    }
		    break;
		    
		case QOS_CNTR_LOAD:
		    resv_R = 0.0;
		    resv_S = 0.0;
		    resv_p = 0.0;
		    if (5 != sscanf(flow_start+1, "%s %f %f %u %u", 
					    temp_string, &resv_r, &resv_b, 
					    &resv_m, &resv_M))
		    {
			fprintf(stderr, "DREC: Error parsing CL flowspec!\n");
			free(theEvent->rsvp.filts);
			free(theEvent->rsvp.flows);
			return FALSE;
		    }
		    break;
		    
		default:
		    fprintf(stderr, "DREC: Invalid flowspec type! (shouldn't get here)\n");
		    return FALSE;
	    }
	    
	    GetFlowspec((rapi_flowspec_t *)flowPtr, resv_type, resv_R,  
			 resv_S, resv_r, resv_b, resv_p, resv_m, resv_M);	    
	    flowPtr = flowPtr + sizeof (rapi_flowspec_t);			
	    start = strchr(flow_start, ']') + 1;
	    if (++num_flows < theEvent->rsvp.nflows)
		flow_start = strchr(flow_start+1, '[');
	    else
		flow_start = NULL;
	}
	else
	{
	    /* flow_start == filt_mid == NULL */
	}
    }   
    return TRUE;
}  /* end GetResvParams() */
#endif // _RSVP


static int AppendSocketToList(DrecSocket *theSocket, DrecSocket **theList)
{
    int maxfd = 0;
    DrecSocket *nextSocket;
    
    if (*theList)
    {
	nextSocket = *theList;
	while(nextSocket->child) 
	{
	    if (nextSocket->fd > maxfd) maxfd = nextSocket->fd;
	    nextSocket = nextSocket->child;
	}
	nextSocket->child = theSocket;
	theSocket->parent = nextSocket;
	theSocket->child = NULL;
	if (theSocket->fd > maxfd)
	    return theSocket->fd;
	else
	    return maxfd;
    }
    else
    {
	*theList = theSocket;
	theSocket->child = NULL;
	theSocket->parent = NULL;
	return theSocket->fd;
    }
}  /* end AppendSocketToList() */

#ifdef _LIMIT_GROUPS
static void RemoveSocketFromList(DrecSocket *theSocket, DrecSocket **theList)
{
    if (theSocket->parent)
	theSocket->parent->child = theSocket->child;
    else
	*theList = theSocket->child;
    if (theSocket->child)
	theSocket->child->parent = theSocket->parent;
    close(theSocket->fd);
    free(theSocket);
}  /* end RemoveSocketFromList() */
#endif // _LIMIT_GROUPS

static void DestroySocketList(DrecSocket *theList)
{
    DrecSocket *theSocket;
     while((theSocket = theList))
    {
	theList = theList->child;
	close(theSocket->fd);
	free(theSocket);
    }
}  /* end DestroySocketList() */


static int OpenRxSocket(unsigned short *port, int BIND)
{
    int fd;
    struct sockaddr serv_addr;
    
    char rbuf[16];
    int optlen = 16;
    const unsigned long rbufSize = 122912;
    
    /* Open a socket */      
    if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
       perror("DREC: OpenTxSocket: socket() error");
       return -1;
    }    
    
    if (BIND)
    {
	memset((char *)&serv_addr, 0, sizeof(struct sockaddr));	
	((struct sockaddr_in *)&serv_addr)->sin_family = AF_INET;
	((struct sockaddr_in *)&serv_addr)->sin_addr.s_addr = htonl(INADDR_ANY);
	((struct sockaddr_in *)&serv_addr)->sin_port = htons(*port); 
	if (bind(fd, &serv_addr, sizeof(struct sockaddr)) < 0)
	{
	   perror("DREC: OpenTxSocket: bind() error");
	   close(fd);
	   return -2;
	}
	
	/* Try set recv socket buffer to a good size */
	memcpy(rbuf, &rbufSize, optlen);
        if (setsockopt(fd, SOL_SOCKET, SO_RCVBUF, rbuf, optlen) < 0)
	{
	   /* Ignore errors for now (TBD - user control of buffer size) */
	}
    }
    
   return fd;
   
}  /* end OpenRxSocket() */


#ifdef _LIMIT_GROUPS

/* Used to join multicast groups on hosts with a limit
 * of IP_MAX_MEMBERSHIPS per socket 
 */
static int JoinGroup(struct in_addr group_addr, 
		      struct in_addr iface_addr, 
		      DrecSocket     *recvSocketList)
{
    int UsedUnboundSocket = FALSE;
    DrecSocket *nextSocket, *lastSocket;
    int i;
    struct ip_mreq mreq;
    
    /* Check recvSocketList first for space */
    nextSocket = recvSocketList;
    while (nextSocket)
    {
	if (nextSocket->g_count < IP_MAX_MEMBERSHIPS)
	    break;
	else
	    nextSocket = nextSocket->child;
    }
    if (!nextSocket)
    {
	UsedUnboundSocket = TRUE;	    
	/* Check unboundSocketList for a socket with space */
	lastSocket = nextSocket = unboundSocketList;
	while(nextSocket)
	{
	    if (nextSocket->g_count < IP_MAX_MEMBERSHIPS)
	    {
		break;
	    }
	    else
	    {
		lastSocket = nextSocket;  
		nextSocket = nextSocket->child;
	    }
	}
	if (!nextSocket)  /* Try to open a new socket for group joins */
	{
	    nextSocket = (DrecSocket *) calloc(1, sizeof(DrecSocket));
	    if (!nextSocket)
	    {
		perror("DREC: calloc(DrecSocket) error");
		return FALSE;
	    }
	    if ((nextSocket->fd = OpenRxSocket(NULL, FALSE)) < 0)
	    {
		free(nextSocket);
		nextSocket = NULL;
	    }
	    else
	    {
		if (lastSocket)
		    lastSocket->child = nextSocket;
		else
		    unboundSocketList = nextSocket;
		nextSocket->parent = lastSocket;
		nextSocket->child = NULL;
		nextSocket->g_count = 0;
	    }
	}
    }
    if (nextSocket)
    {
	mreq.imr_multiaddr = group_addr;
	mreq.imr_interface = iface_addr;   
	if (setsockopt(nextSocket->fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, 
		    (char *)&mreq, sizeof(mreq))< 0) 
	{
	    perror("DREC: Error joining multicast group");
	    fprintf(stderr, "DREC: Group:%s\n", (char *) inet_ntoa(group_addr));
	    if (UsedUnboundSocket && !nextSocket->g_count)
		RemoveSocketFromList(nextSocket, &unboundSocketList);
	    return FALSE;
	}
	else
	{
	    nextSocket->g_count++;
	    for(i=0; i < IP_MAX_MEMBERSHIPS; i++)
	    {
		if (!nextSocket->group[i].s_addr)
		{
		    nextSocket->group[i] = group_addr;
		    break;
		}
	    }
	    return TRUE;
	}
    }
    else
    {
	return FALSE;
    }
}  /* end JoinGroup() */

static void LeaveGroup(struct in_addr group_addr, 
		       struct in_addr iface_addr, 
		       DrecSocket     *recvSocketList)
{
    DrecSocket *nextSocket, *theSocket = NULL;
    int i = 0;
    struct ip_mreq mreq;
    int UsedUnboundSocket = FALSE;
    
    
    /* First check recvSocketList */
    theSocket = NULL;
    nextSocket = recvSocketList;
    while(nextSocket && !theSocket)
    {
	for(i=0; i < IP_MAX_MEMBERSHIPS; i++)
	{
	    if (nextSocket->group[i].s_addr == group_addr.s_addr)
	    {
		theSocket = nextSocket;
		break;
	    }
	}
	nextSocket = nextSocket->child;
    }
   
    /* Then check unboundSocketList */
    if (!theSocket)
    {
	UsedUnboundSocket = TRUE;
	nextSocket = unboundSocketList;
	while(nextSocket && !theSocket)
	{
	    for(i=0; i < IP_MAX_MEMBERSHIPS; i++)
	    {
		if (nextSocket->group[i].s_addr == group_addr.s_addr)
		{
		    theSocket = nextSocket;
		    break;
		}
	    }
	    nextSocket = nextSocket->child;
	}
    }    
    
    if (theSocket)
    {
	mreq.imr_multiaddr 	= group_addr;
	mreq.imr_interface 	= iface_addr; 
	if (setsockopt(theSocket->fd, IPPROTO_IP, IP_DROP_MEMBERSHIP, 
			(char *)&mreq, sizeof(mreq))< 0) 
	{
	    perror("DREC: Error leaving multicast group");
	    printf("DREC: Group:%s\n", (char *)inet_ntoa(group_addr));
	}
	else
	{
	    theSocket->group[i].s_addr = 0;
	    theSocket->g_count--;
	    if (!theSocket->g_count && UsedUnboundSocket)
		RemoveSocketFromList(theSocket, &unboundSocketList);
	}
    }
    else
    {
	fprintf(stderr, "DREC: Error leaving multicast group! (Couldn't find socket)\n");
    }
}  /* end LeaveGroup() */

#else

static int JoinGroup(struct in_addr group_addr, 
		      struct in_addr iface_addr, 
		      DrecSocket     *recvSocketList)
{
    struct ip_mreq mreq;
    mreq.imr_multiaddr 	= group_addr;
    mreq.imr_interface 	= iface_addr;   
    if (setsockopt(recvSocketList->fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, 
		    (char *)&mreq, sizeof(mreq))< 0) 
    {
	perror("DREC: Error joining multicast group");
	fprintf(stderr, "DREC: Group:%s\n", (char *) inet_ntoa(group_addr));
	return FALSE;
    }
    else
    {
	return TRUE;
    }
}  /* end JoinGroup() */

static void LeaveGroup(struct in_addr group_addr, 
		       struct in_addr iface_addr, 
		       DrecSocket     *recvSocketList)
{
    struct ip_mreq mreq;
    mreq.imr_multiaddr 	= group_addr;
    mreq.imr_interface 	= iface_addr; 
    if (setsockopt(recvSocketList->fd, IPPROTO_IP, IP_DROP_MEMBERSHIP, 
		    (char *)&mreq, sizeof(mreq))< 0) 
    {
	perror("DREC: Error leaving multicast group");
	printf("DREC: Group:%s\n", (char *)inet_ntoa(group_addr));
    }
}
#endif // _LIMIT_GROUPS

static inline int IsValidPort(int port)
{
    return ((port > 0) && (port < 0x10000));
}

/* This routine parses user supplied text list of recv ports */
/* example text format: 5000-5005,6001 */
RecvPort *BuildPortList(char *portText)
{
    RecvPort *theList = NULL, *listTail = NULL, *newPort;
    char seps[] = ", \t\n";
    char *token, *ptr;
    int tempint, tempint2, i;
    
    /* First, break into tokens using comma delimiter */
    token = strtok(portText, seps);
    while(token)
    {
	if ((ptr = strchr(token, '-')))  /* port range */
	{
	    *ptr++ = '\0';
	    tempint = atoi(token);
	    tempint2 = atoi(ptr);
	    if (IsValidPort(tempint) && 
		IsValidPort(tempint2) &&
		tempint2 >= tempint)
	    {
		for(i=tempint; i <= tempint2; i++)
		{
		    if(!(newPort = (RecvPort *) calloc(1, sizeof(RecvPort))))
		    {
			DestroyPortList(&theList);
			return NULL;
		    }
		    newPort->port = i;
		    newPort->next = NULL;
		    if (theList)
			listTail->next = newPort;
		    else
			theList = newPort;
		    listTail = newPort;
		}
	    }
	    else
	    {
		DestroyPortList(&theList);
		return NULL;
	    }
	}
	else  /* discrete port */
	{
	    tempint = atoi(token);
	    newPort = (RecvPort *) calloc(1, sizeof(RecvPort));
	    if (!(newPort && IsValidPort(tempint)))
	    {
		if (newPort) free(newPort);
		DestroyPortList(&theList);
		return NULL;
	    }
	    newPort->port = tempint;
	    newPort->next = NULL;
	    if (theList) 
		listTail->next = newPort;
	    else
		theList = newPort;
	    listTail = newPort;
	}
	token = strtok(NULL, seps);
    }  /* end while(token) */
    return theList;
}  /* end BuildPortList() */

void DestroyPortList(RecvPort **theList)
{
    RecvPort *nextPort;
    while((nextPort = *theList))
    {
	*theList = (*theList)->next;
	free(nextPort);
    }
}
