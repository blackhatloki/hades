/* "startTime.c" - This is used to convert the start time of a program to 
 *                 the appropriate time_t equivalent.
 */


#include <stdio.h>
#include <string.h>

#include "startTime.h"

#ifndef TRUE
static const int TRUE = 1;
static const int FALSE = 0;
#endif

time_t startTime(char *start_string)
{
    struct tm start_time;
    time_t curtime;
    struct tm curtime_tm;
    char *gmt_ptr;
    int isgmt;
    
    /* Get the current time in seconds */
    time(&curtime);
    
    if (!strcmp(start_string, "NOW")) return 0;
    
    /* Processes GMT time start*/
    gmt_ptr = (char *) strstr(start_string, "GMT");
    if (gmt_ptr)
    {
	if (3 != sscanf(start_string, "%d:%d:%dGMT", &start_time.tm_hour, 
		&start_time.tm_min, &start_time.tm_sec))
	{
	    return -1;
	}
	isgmt = TRUE;
    }
    else
    {
	if (3 != sscanf(start_string, "%d:%d:%d", &start_time.tm_hour, 
		&start_time.tm_min, &start_time.tm_sec))
	{
	    return -1;
	}
	isgmt = FALSE;
    }

  /* Put the current time into a tm structure */
    if (isgmt)
	memcpy(&curtime_tm, gmtime(&curtime), sizeof(struct tm));
    else
	memcpy(&curtime_tm, localtime(&curtime), sizeof(struct tm));

  /* Compare with our start_time tm structure */
    if (start_time.tm_hour < curtime_tm.tm_hour) start_time.tm_hour += 24;

    while (start_time.tm_hour > curtime_tm.tm_hour)
    {
	curtime += 3600;        /* seconds in an hour */
	curtime_tm.tm_hour++;
    }

    if (start_time.tm_min > curtime_tm.tm_min)
    {
	while (start_time.tm_min > curtime_tm.tm_min)
	{
	  curtime += 60;       /* seconds in a minute */
	  curtime_tm.tm_min++;
	}
    }
    else
    {      
	while (start_time.tm_min < curtime_tm.tm_min)
	{
	    curtime -= 60;       /* seconds in a minute */
	    curtime_tm.tm_min--;
	}
    }

    if (start_time.tm_sec > curtime_tm.tm_sec)
    {
	while (start_time.tm_sec > curtime_tm.tm_sec)
	{
	    curtime++;    
	    curtime_tm.tm_sec++;
	}
    }
    else
    {      
	while (start_time.tm_sec < curtime_tm.tm_sec)
	{
	    curtime--;   
	    curtime_tm.tm_sec--;
	}
    }
  return (curtime);
}  /* end startTime() */

