/* mgenTicker.h - header for our flow control bucket based on 1 msec ticks */

#include <sys/time.h>

typedef struct MgenTicker
{
    double count;      /* Current bucket content (msec tick count) */
    struct timeval lastTime;   /* time state (system time) */ 
} MgenTicker;

/* Public function prototypes */
void MgenWait(double msec,  MgenTicker *theTicker);
void InitMgenTicker(MgenTicker *theTicker);
void UpdateMgenTicker(MgenTicker *theTicker);
