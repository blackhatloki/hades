/* 
 *  Quick and dirty hack of rcalc to convert mgen/drec 
 *  log file format into the fllowing fields:
 *
 *  Sequence--Trans Time--Receive Time--Delay--Packets Lost--Percent Dropped--Start Window--Stop Window-- Packets/Window 
 *
 */

#define TRUE  1
#define FALSE 0

#define MAXLINES 20000

#include <stdio.h>

int main(argc,  argv)
  int argc;
  char *argv[];
{
  FILE *inFile, *outFile;
  float hours, minutes, seconds;
  double rx_seconds, tx_seconds, windowTime, windowEnd, windowPast, delay;
  double CumDelay = 0;
  int i, status,  result;
  char buffer[MAXLINES];
  char *str_ptr;
  int line = 0;
  
  extern char *optarg;
  extern int optind, opterr;
  register int op;
  int nonopt_argc;
  
  int flow_id, flow_num;
  char flow_string[32];
  
  unsigned long seqnum = 0;
  unsigned long size = 0;
  unsigned long rate = 0;

  unsigned long packetCount = 0;
  unsigned long totalCount = 0;

  
  /* Set default values */ 
  windowTime = 1.0;
  flow_id = 1;
  flow_num = flow_id;
  
  
   /* Parse options */  
   optind = 1;
   opterr = 0;
 
 /* Get the flow id or window size from the command line */
   while ((op = getopt(argc,  argv,  "f:w:a")) != EOF)
   {
	switch(op)
	{
	    case 'f':
		flow_id = atoi(optarg);
		flow_num = flow_id;
		if (flow_id < 0)
		{
		    printf("allcalc: Bad flow id!\n");
		    exit(0);
		}
		break;
	    case 'w':
		status = sscanf(optarg, "%lf", &windowTime);
		if ((status!=1) || (windowTime<0))
		{
		    printf("allcalc: Bad windowTime!\n");
		    exit(0);
		}
		break;
	   case 'a':
		flow_num = flow_id;
		flow_id = 1;
		break;	    
	   default:
		printf("allcalc: Invalid option!\n");
		printf("Usage: allcalc [-f flow_id][-a used with -f to calculate\n"); 
		printf("flows[-w windowTime] logFile outFile\n");
		exit(0);
		break;
	}
   }
    
    /* Non optional arguments */
    nonopt_argc = argc - optind;
  
    if (nonopt_argc != 2)
    {
	printf("Usage: allcalc [-f flow_id][-a used with -f to calculate\n");
		printf("flows[-w windowTime] logFile outFile\n");

	exit(0);
    }
    
    /* Scanning flow variable and opening the log file and out file */
    sprintf(flow_string,  "Flow>%04d ", flow_id);
    
    printf("Opening logFile ...\n");
    if ( (inFile = fopen(argv[optind], "r") ) == NULL)
    {
	perror("allcalc: Error opening log file\n");
	exit(0);
    }
    
    printf("Opening output file ...\n");
    if ( (outFile = fopen(argv[optind+1], "w+") ) == NULL)
    {
	perror("allcalc: Error opening output file\n");
	exit(0);
    }
    while (flow_id <= flow_num)
	{
	    /* Scanning flow variable and opening the log file and out file */
	    sprintf(flow_string, "Flow>%04d ",flow_id);
	    do
	    {
	        i = 0;
	
		/* Read one line from the input file */
		do            
		{
		    result = fread(buffer+i, 1, 1, inFile);
		    i++; 
		    if (i == MAXLINES)
		    {
			printf("too long line!\n");
			i = MAXLINES-1;
			buffer[MAXLINES-1] = '\n';
		    }
		} while( (result>0) && (buffer[i-1] != '\n'));	
		line++;
	
	       /* Assigns and Searches for flow_string in the line read in above */ 
	       if(result>0)
	       {
	         str_ptr = (char *) strstr(buffer, flow_string);
		 if (str_ptr)
	         {
		    /* Reassigns pointer and searches for seq number in lines containing the flow_sting variable */
		    str_ptr = (char *) strstr(buffer, "Seq");
 	           if (str_ptr)
	            {
	                status = sscanf(str_ptr, "Seq>%ld", &seqnum);
	                if (status != 1)
	                {
	                    printf("allcalc: Error parsing event at file line %ld.\n", line);
	                    exit(0);
	                }
	            }
		    else
		    {
		    	printf("allcalc: Couldn't find Seq>'\n");
		    }
		     						
	            /* Reassigns pointer and searches for TxTime in the same line */
	            str_ptr = (char *) strstr(buffer, "TxTime>");
	            if (str_ptr)
	            {
	                status = sscanf(str_ptr, "TxTime>%f:%f:%f", &hours, &minutes, &seconds);
	
	                if (status != 3)
	                {
	                    printf("allcalc: Error parsing event at file line %d.\n", line);
	                    exit(0);
	                }
	            }
	            else
	            {
	                printf("allcalc: Couldn't find 'TxTime>'\n");
	                exit(0);
	            }
	
		      
		    /* Calculate transmit time to seconds from midnight */  
	               tx_seconds = (double) (3600.0*hours) + (double) (60.0*minutes) + (double) seconds;
	
		    /* Reassigns pointer and searches for Recieve Time */
		    str_ptr = (char *) strstr(buffer, "RxTime");
		    if (str_ptr)
		    {
	                status = sscanf(str_ptr, "RxTime>%f:%f:%f", &hours, &minutes, &seconds);
	                if (status != 3)
	                {
	                    printf("allcalc: Error parsing event at file line %d.\n", line);
	                    exit(0);
	                }
	
		    }
		    else
		    {
		        printf("allcalc: Couldn't find 'RxTime'\n");
		        exit(0);
		    }  
		      
		    /* Calculate transmit time to seconds from midnight  */
	               rx_seconds = (double) (3600.0*hours) + (double) (60.0*minutes) + (double) seconds;
	
		    /* Reassigns pointer and searches for Size of Packets */
	            str_ptr = (char *) strstr(buffer, "Size");
	            if (str_ptr)
	            {
	                status = sscanf(str_ptr, "Size>%ld", &size);
	                if (status != 1)
	                {
	                    printf("allcalc: Error parsing event at file line %ld.\n", line);
	                    exit(0);
	                }
	            }
		    else
		    {
		    	printf("allcalc:  Couldn't find 'size>'\n");
		    }
	
		  
		  /*  Writes the header and sets the first window end time when the */
		  /*  appropriate flow_string is found.				    */
		  	 
		  if (!packetCount)
		  {
		     fprintf(outFile, "seq	transmit_time	receive_time	delay_time	start_win	stop_win	avg_delay	avg_pk_rate	avg_bit_rate");
		     windowEnd = rx_seconds + windowTime;
		  }
	
		  /* Delay calculation */
	             delay = rx_seconds - tx_seconds; 
	
		  /*  Print standard first four fields 					*/
		  /*  The first 4 fields of every line printed to the output file 	*/
	          /*  Sequence #   Trans Time      Receive Time    Delay 		*/
	              fprintf(outFile, "\n%ld	%lf	%lf	%lf", seqnum, tx_seconds,
                      rx_seconds, delay);
 
	          /* Condition used to generate data based on window size when window is exceeded */
		  if (rx_seconds > windowEnd)
		  {
	             /* Calculates and outputs more transmission data in the following format		*/  
	             /* start_win       stop_win        avg_delay       avg_pk_rate     avg_bit_rate	*/
	                
			fprintf(outFile, "	%lf	%lf	%lf	%lf	%lf", windowEnd - windowTime,
                         windowEnd, CumDelay/((double)packetCount),(double)(packetCount/(windowTime)),
				 ((packetCount/(double)((windowTime))*(size+28)*8)));
 
           	 
	            	 /* Increment the window end and total packet count when the window ends */
 	           	    windowEnd += windowTime;

           	 
  	          	 /*  Print 0s except for window start and stop */
   	         	     while (windowEnd < rx_seconds)
			 	{     
       	                         fprintf(outFile, "\n----	----------	------------	--------	%lf	%lf	0.000000	0.000000	00000.000000",
				 windowEnd - windowTime, windowEnd);
				 windowEnd += windowTime;
				 }
 
           		 
	            /* Reset the total delay and packet count when the window ends */
 	              CumDelay = 0;
  	     	       packetCount = 0;
 	 	      size = 0;
        
		}
	   
       
 	       /* Increment the counts */
		  packetCount++; 
		  totalCount++;
    	    CumDelay += rx_seconds - tx_seconds;
	    } }     

 	    /* Append a return to the last line in the output file */ 
  	    	if(result==0)
	  	fprintf(outFile, "\n");

    	} while (result>0);
	
	fprintf(outFile, "\n");
	fprintf(outFile, "\n");
    	printf("Windowed %d packets total for flow %d.\n", totalCount, flow_id);
    	printf("Done.\n");
	flow_id++;
	totalCount = 0;
	packetCount = 0;
	fclose(inFile);
	inFile = fopen(argv[optind], "r");
    }
    fclose(inFile);
    fclose(outFile);

}
