#ifdef _GUI 

// Test comment
#include <Xm/XmAll.h>
#include <X11/xpm.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netdb.h>


#include "drec.h"
#include "sysdefs.h"
#include "version.h"

#ifndef INADDR_NONE
#define INADDR_NONE 0xffffffff
#endif // 

#include "icons/nrl.xpm"
#include "icons/drecIcon1.xpm"
#include "icons/drecIcon2.xpm"
#include "icons/go.xpm"
#include "icons/stop.xpm"
#include "icons/d_bang1.xpm"
#include "icons/d_bang2.xpm"
#include "icons/d_bang3.xpm"
#include "icons/d_bang4.xpm"

/* Private constants */
#define NUM_BANGS   4
#define BANG_INTERVAL 125    /* 125 msec = 8 frames/sec */
static const int BUFFER_SIZE = 1440;

/* Private globals */
#ifndef TRUE
static const int TRUE = 1;
static const int FALSE = 0;
#endif //
static int UseAnimation = TRUE;

static char *outputBuffer;
static int outIndex = 0;

static char cmdPath[256];
static int drecID = 0;
static int liveChild = FALSE;
static int readPipeFd;
static int killPipe = FALSE;

/* GUI globals */
static XtAppContext appContext;
static Widget topLevel;
static XtInputId drecInputID = 0;
static XmFontList fontlist;
static XFontStruct *font;
static GC gc;
static char *Fallbacks[] = 
{
    "*.background:			gray",
    "*.XmToggleButton.selectColor:	green",
    "*.XmRadioButton.selectColor:	green", 
    NULL
};
static Pixmap nrlMap, goMap, stopMap, drecMap1, drecMap2;
static Widget startButton, stopButton, quitButton;
static Widget paramFrame[2], paramPanel[2];
static Widget LastAddressText;
static Widget outText;

/* DREC SCRIPTED parameters */
#define SCRIPT_FILE     0  /* Script file name */
#define SCRIPT_LOG_FILE	1  /* Log file name */
#define SCRIPT_PORT	2  /* Recv port(s) */
#define SCRIPT_IFACE	3  /* Multicast/ stats interface */
#define SCRIPT_START	4  /* When does it start */
#define NUM_SCRIPT_PARAMS	5

/* DREC ITERATED parameters */
#define LOG_FILE	 0  /* Log file name */
#define BASE_ADDRESS	 1  
#define PORT		 2  /* What am I listening for */
#define NUM_GROUPS	 3
#define INTERFACE	 4
#define START_TIME	 5  /* When does it start (and end) */
#define DURATION	 6
#define OFFSET		 7  /* Join/Leave offset (controls group join rate) */
#define NUM_ITERATED_PARAMS     8

static Widget script_paramWidget[NUM_SCRIPT_PARAMS];
static char *script_paramLabel[NUM_SCRIPT_PARAMS] = 
{
    "scriptFile:", 
    "logFile:", 
    "recvPort(s):", 
    "interface:", 
    "startTime:"
};
static char script_paramValue[NUM_SCRIPT_PARAMS][256];
static char *script_arg[NUM_SCRIPT_PARAMS] = 
{ 
    "XX", 
    "XX", 
    "-p", 
    "-i", 
    "-S", 
};

static Widget fixed_paramWidget[NUM_ITERATED_PARAMS];
static char *fixed_paramLabel[NUM_ITERATED_PARAMS] = 
{
    "logFile:", 
    "baseAddress:", 
    "recvPort(s):", 
    "numGroups:", 
    "interface:", 
    "startTime:", 
    "duration (sec):", 
    "offset (msec):"
};
static char *fixed_arg[NUM_ITERATED_PARAMS] = 
{
    "XX", 
    "-b", 
    "-p", 
    "-n", 
    "-i", 
    "-S", 
    "-d", 
    "-o"
};
static char fixed_paramValue[NUM_ITERATED_PARAMS][256];

/* "bang" animation variables */
static Widget bangLabel;
static Pixmap bangMaps[NUM_BANGS];
static int bangWidth, bangHeight;
static Pixmap theBangMap;
static XtIntervalId bangTimerID = 0;
static int bangCount = 0;
static int bangInc = 1;

/* Private prototypes */
static int setup_gui(int *argc,  char *argv[]);
static int LoadMgenIcon(char **theIcon, Pixmap *theMap, Widget widget, 
			int *width, int *height);
static void Do_Start();
static void Do_Stop();
static void child_died();
static void Do_Mode_Change(Widget widget, int which, XmToggleButtonCallbackStruct *state);
static void Do_Param(Widget w, XtPointer client_data, XmAnyCallbackStruct *cbs);
static int CheckParam(int param, char *theText);
static int UpdateParams();
static void Do_Specify_File(Widget widget, XtPointer client_data, XtPointer call_data);
static void File_Callback(Widget dialog, XtPointer client_data, 
			    XmFileSelectionBoxCallbackStruct *cbs);
static int ScanScript(char *file);
static void Do_Quit();
static void readPipe(XtPointer client, int *fd, XtInputId *Id);
static void Bang_Timer(XtPointer client_data,  XtIntervalId *Id);
static void redrawBangLabel();
static void Alert(char *text);
static void UpdateLastAddress();

void startGUI(int *argc,  char *argv[], int animate)
{
    UseAnimation = animate;
   
    /* Allocate and init text output buffer */
    outputBuffer = (char *) calloc(BUFFER_SIZE, sizeof(char));
    if (!outputBuffer)
    {
	perror("DREC: Error allocating memory for GUI output text");
	exit(0);
    }
   
    /* Set launch command path */
    strcpy(cmdPath, argv[0]);
   
    /* Build graphical interface window and display */
    if(!setup_gui(argc, argv))
    {
	fprintf(stderr, "DREC: Error setting up graphical user interface!\n");
	free(outputBuffer);
	exit(0);
    }
      
   /* Loop, checking for X-Windows events */
   XtAppMainLoop(appContext);
   exit(0);
}  /* end startGUI() */



static int setup_gui(int *argc,  char *argv[])
{
    int i, width, height;
    char temp_text[64], hostName[64];
    struct hostent *hostentry;
    Widget mainWindow, mainPanel, topFrame;
    Widget tempForm, tempLabel, tempWidget;
    Widget nrlLabel, inputPanel, modeFrame, outFrame;
    Widget paramLabel, otherParams;
    XmString str, str2;
    char **IconList[NUM_BANGS] = 
    {
	 d_bang1,  d_bang2,  d_bang3,  d_bang4
    };
    
    /* Init paramValues */
    
    /* Script mode parameters */
    strcpy(script_paramValue[SCRIPT_FILE], ScriptFile);
    strcpy(script_paramValue[SCRIPT_LOG_FILE], LogFile);
    sprintf(script_paramValue[SCRIPT_PORT], "%hu", defaultPort);
    strcpy(script_paramValue[SCRIPT_IFACE], DEFAULT_INTERFACE);
    strcpy(script_paramValue[SCRIPT_START], "NOW");
    
    /* Fixed mode parameters */
    strcpy(script_paramValue[LOG_FILE], LogFile);
    sprintf(fixed_paramValue[PORT], "%d", defaultPort);
    sprintf(fixed_paramValue[NUM_GROUPS], "%d", numGroups);
    strcpy(fixed_paramValue[INTERFACE], DEFAULT_INTERFACE);
    strcpy(fixed_paramValue[START_TIME], "NOW");
    sprintf(fixed_paramValue[DURATION], "%d", Duration);
    sprintf(fixed_paramValue[OFFSET], "%d", Offset);
    
    /* Use default unicast as baseAddress as default */
    gethostname(hostName, 32);
    if(!IsMulticast(baseAddress))
    {
	if ((hostentry = gethostbyname(hostName)) != NULL) 
	    memcpy(&baseAddress.s_addr, 
		   hostentry->h_addr_list[0], 
		   sizeof(baseAddress.s_addr));
    } 
    sprintf(fixed_paramValue[BASE_ADDRESS], "%s", inet_ntoa(baseAddress));
    
    /* Create Xt application instance */
    topLevel = XtVaAppInitialize(&appContext,  "drec", NULL, 0, 
				   argc, argv, Fallbacks, NULL);
    
    /* Set app name for window manager */			   
    strcpy(temp_text, "drec-");
    strcat(temp_text, hostName);
    XtVaSetValues(topLevel, 
		    XmNtitle, temp_text, 
		    XmNiconName, temp_text, 
		    XmNallowShellResize, TRUE,
		    NULL);
    
    /* Load fonts */
    font = XLoadQueryFont(XtDisplay(topLevel), "-*-courier-bold-r-*--10-*");
    if (font == NULL) fprintf(stderr, "DREC: font 1 does not exist");
    fontlist = XmFontListCreate(font, "charset1");
    
    /* Create a MainWindow for application */    
    mainWindow = XtVaCreateManagedWidget("mainWindow", 
		    xmMainWindowWidgetClass, topLevel,
		    NULL);
		    
    /* Create main form widget for user interface layout */	
    mainPanel = XtVaCreateManagedWidget("mainPanel", xmFormWidgetClass, 
		    mainWindow,
		    NULL);
		    
    /* Load our icons */
    if(!LoadMgenIcon(nrl, &nrlMap, topLevel, &width, &height))
    {
	fprintf(stderr, "DREC: Error loading GO icon\n");
	XtDestroyWidget(topLevel);
	return FALSE;
    }
    if(!LoadMgenIcon(drecIcon1, &drecMap1, topLevel, &width, &height))
    {
	fprintf(stderr, "DREC: Error loading GO icon\n");
	XtDestroyWidget(topLevel);
	return FALSE;
    }
    if(!LoadMgenIcon(drecIcon2, &drecMap2, topLevel, &width, &height))
    {
	fprintf(stderr, "DREC: Error loading GO icon\n");
	XtDestroyWidget(topLevel);
	return FALSE;
    }
    if(!LoadMgenIcon(go, &goMap, topLevel, &width, &height))
    {
	fprintf(stderr, "DREC: Error loading GO icon\n");
	XtDestroyWidget(topLevel);
	return FALSE;
    }
    if(!LoadMgenIcon(stop, &stopMap, topLevel, &width, &height))
    {
	fprintf(stderr, "DREC: Error loading GO icon\n");
	XtDestroyWidget(topLevel);
	return FALSE;
    }
    /* Load "bang" animation pixmaps */
    for(i=0; i < NUM_BANGS; i++)
    {
	if(!LoadMgenIcon(IconList[i], &bangMaps[i], topLevel, &bangWidth, &bangHeight))
	{
	    fprintf(stderr, "DREC: Error loading GO icon\n");
	    XtDestroyWidget(topLevel);
	    return FALSE;
	}
    }
    
    /* Use drecIcon1 pixmap for defaut application icon */		   
    XtVaSetValues(topLevel, XmNiconPixmap, drecMap1, NULL);
    
    /* Now build the user interface */
    
    /* Create frame -  the top portion of the screen including the NRL logo,
     *                  NRL Multicast Traffic Generator label, bangLabel drawing
     *		        area, startButton, and stopButton
     */
    topFrame = XtVaCreateManagedWidget("controlFrame", 
		    xmFrameWidgetClass, mainPanel,
		    XmNleftAttachment, XmATTACH_FORM,
		    XmNleftOffset,       5,  
		    XmNtopAttachment,  XmATTACH_FORM, 
		    XmNtopOffset,	10, 
		    XmNrightAttachment, XmATTACH_FORM, 
		    XmNrightOffset,      5, 
		    NULL);
    
    /* Create tempForm - the form widget which manages the objects inside 
     *                   frame widget (managed objects include: NRL logo,
     *	         	 NRL Multicast Traffic Generator label, bangLabel 
     *			 drawing area, startButton, and stopButton)
     */
    tempForm = XtVaCreateManagedWidget("form", 
		    xmFormWidgetClass, topFrame, 
		    NULL);
	
    nrlLabel = XtVaCreateManagedWidget("logo", 
			  xmLabelWidgetClass, tempForm, 
			  XmNlabelType,	      XmPIXMAP, 
			  XmNlabelPixmap,     nrlMap,
			  XmNleftAttachment,  XmATTACH_FORM, 
			  XmNtopAttachment,   XmATTACH_FORM,
			  NULL);	

    strcpy(temp_text, "NRL Dynamic Receiver\n Version ");
    strcat(temp_text, VERSION);
    str = XmStringCreateLtoR(temp_text, XmSTRING_DEFAULT_CHARSET);
    tempLabel = XtVaCreateManagedWidget("label", 
			  xmLabelWidgetClass,	tempForm, 
			  XmNlabelString,	str,
			  XmNleftAttachment,	XmATTACH_WIDGET,
			  XmNleftWidget,	nrlLabel, 
			  XmNleftOffset,	5, 
			  XmNtopAttachment,	XmATTACH_FORM,
			  NULL);
    XmStringFree(str);
    
    bangLabel = (Widget) XtVaCreateManagedWidget("bang",
			xmDrawingAreaWidgetClass,   tempForm,
			/* XmNbackground,		    bg, */
			XmNleftAttachment,	    XmATTACH_WIDGET,
			XmNleftWidget,		    tempLabel, 
			XmNleftOffset,		    -5, 
			XmNtopAttachment,	    XmATTACH_FORM,
			XmNtopOffset,		    10, 
			XmNwidth,		    bangWidth, 
			XmNheight,		    bangHeight, 
			NULL);
    
    theBangMap = drecMap1;    
    gc = XCreateGC(XtDisplay(topLevel), 
		    RootWindowOfScreen(XtScreen(topLevel)), 
		    (unsigned long) NULL,  
		    NULL);
    XtAddCallback(bangLabel, XmNexposeCallback, 
	    (XtCallbackProc) redrawBangLabel, (XtPointer) gc);
	    
    str = XmStringCreateSimple("Start");    			  
    startButton = (Widget) XtVaCreateManagedWidget("Start",
			xmDrawnButtonWidgetClass,   tempForm,
			XmNlabelType,		    XmPIXMAP,
			XmNlabelPixmap,		    goMap,
			XmNlabelInsensitivePixmap,  goMap,
			XmNrightAttachment,	    XmATTACH_FORM,
			XmNtopAttachment,	    XmATTACH_FORM,
			XmNtopOffset,		    10, 
			XmNrightOffset,		    10,
			XmNpushButtonEnabled,	    TRUE, 
			NULL);	
    XmStringFree(str);
    XtAddCallback(startButton, XmNactivateCallback, (XtCallbackProc)Do_Start, NULL);		
    
    
    str = XmStringCreateSimple("Stop ");    			  
    stopButton = (Widget) XtVaCreateManagedWidget("Stop",
			xmDrawnButtonWidgetClass,   tempForm,
			XmNlabelType,		    XmPIXMAP,
			XmNlabelPixmap,		    stopMap,
			XmNlabelInsensitivePixmap,  stopMap,
			XmNrightAttachment,	    XmATTACH_FORM,
			XmNtopAttachment,	    XmATTACH_WIDGET,
			XmNtopWidget,		    startButton, 
			XmNtopOffset,		    10, 
			XmNrightOffset,		    10, 
			XmNsensitive,		    FALSE, 
			NULL);	
    XmStringFree(str);
    XtAddCallback(stopButton, XmNactivateCallback, (XtCallbackProc)Do_Stop, NULL);		
    
    /* Input Panel */
    inputPanel = XtVaCreateWidget("inputPanel", 
		    xmFormWidgetClass,	mainPanel, 
		    XmNtopAttachment,   XmATTACH_WIDGET,
		    XmNtopOffset,	10,
		    XmNtopAttachment,   XmATTACH_WIDGET,
		    XmNtopWidget,       topFrame, 
		    NULL);    

    tempLabel = XtVaCreateManagedWidget("Input Mode", 
		    xmLabelGadgetClass,  inputPanel, 
		    XmNleftAttachment,   XmATTACH_FORM,
		    XmNtopAttachment,    XmATTACH_FORM,
		    NULL);
    
    modeFrame = XtVaCreateManagedWidget("modeFrame", 
		    xmFrameWidgetClass,	inputPanel,
		    XmNleftAttachment,	XmATTACH_FORM,
		    XmNleftOffset,	5,  
		    XmNrightAttachment, XmATTACH_FORM,
		    XmNrightOffset,	5,  
		    XmNtopAttachment,	XmATTACH_WIDGET, 
		    XmNtopWidget,	tempLabel, 
		    XmNtopOffset,	5, 
		    XmNshadowType,	XmSHADOW_IN,  
		    NULL);

    str = XmStringCreateSimple("Script File");
    str2 = XmStringCreateSimple("Fixed Parameters");
    
    tempWidget = XmVaCreateSimpleRadioBox(modeFrame, "modeRadioBox", 
		      SCRIPTED,		(XtCallbackProc) Do_Mode_Change, 
		      XmVaRADIOBUTTON,  str, NULL, NULL, NULL,
		      XmVaRADIOBUTTON,  str2, NULL, NULL, NULL,
		      NULL);
    
    XtManageChild(tempWidget);

    XmStringFree(str);
    XmStringFree(str2);
    
    
    paramLabel = XtVaCreateManagedWidget("Test Parameters", 
		    xmLabelGadgetClass,	    inputPanel, 
		    XmNleftAttachment,	    XmATTACH_FORM,
		    XmNtopAttachment,	    XmATTACH_WIDGET, 
		    XmNtopWidget,	    modeFrame, 
		    XmNtopOffset,	    20,
		    NULL);
    
    /*****************************************************************
     *  Creates paramFrame[SCRIPTED] - the frame which holds the paramPanel 
     *	for the Script Mode row-column widget 
     */    
     
    paramFrame[SCRIPTED] = XtVaCreateWidget("sessionFrame[SCRIPTED]", 
		    xmFrameWidgetClass,	    inputPanel,
		    XmNleftAttachment,	    XmATTACH_FORM,
		    XmNleftOffset,	    5,  
		    XmNtopAttachment,	    XmATTACH_WIDGET, 
		    XmNtopWidget,	    paramLabel, 
		    XmNtopOffset,	    5, 
		    XmNbottomAttachment,    XmATTACH_FORM, 
		    XmNshadowType,	    XmSHADOW_IN,  
		    XmNmappedWhenManaged,   TRUE,
		    NULL);
    
    paramPanel[SCRIPTED] = XtVaCreateWidget("paramPanel[SCRIPTED]",
                    xmFormWidgetClass, paramFrame[SCRIPTED], 
		    NULL);    
    
    /* Script file selection */
    tempLabel = XtVaCreateManagedWidget("Script File:", 
		    xmLabelGadgetClass,	    paramPanel[SCRIPTED], 
		    XmNleftAttachment,	    XmATTACH_FORM,
		    XmNtopAttachment,	    XmATTACH_FORM, 
		    NULL);
    
    str = XmStringCreateSimple("Select");
    tempWidget = (Widget) XtVaCreateManagedWidget("Select",
			xmPushButtonWidgetClass,    paramPanel[SCRIPTED],
			XmNlabelString,		    str,
			XmNrightAttachment,	    XmATTACH_FORM, 
			XmNtopAttachment,	    XmATTACH_WIDGET, 
			XmNtopWidget,		    tempLabel,
			XmNrightOffset,		    2,
			NULL);	
    XmStringFree(str);    
    XtAddCallback(tempWidget, XmNactivateCallback, 
		  (XtCallbackProc) Do_Specify_File, SCRIPT_FILE);
		  
    script_paramWidget[SCRIPT_FILE] = XtVaCreateManagedWidget("scriptText", 
		    xmTextFieldWidgetClass, paramPanel[SCRIPTED], 
		    XmNtraversalOn,	    TRUE, 
		    XmNleftAttachment,	    XmATTACH_FORM, 
		    XmNrightAttachment,     XmATTACH_WIDGET, 
		    XmNrightWidget,	    tempWidget, 
		    XmNbottomAttachment,    XmATTACH_OPPOSITE_WIDGET,
		    XmNbottomWidget,	    tempWidget, 
		    XmNfontList,	    fontlist, 
		    XmNvalue,		    ScriptFile, 
		    NULL);
    
    XtAddCallback(script_paramWidget[SCRIPT_FILE], XmNactivateCallback, 
		  (XtCallbackProc) Do_Param,  
		  (XtPointer) NULL);
		    	    	    
    XtAddCallback(script_paramWidget[SCRIPT_FILE], XmNactivateCallback, 
		  (XtCallbackProc) XmProcessTraversal,  
		  (XtPointer) XmTRAVERSE_NEXT_TAB_GROUP);

    
    /* Log file selection */
    tempLabel = XtVaCreateManagedWidget("Log File:", 
		    xmLabelGadgetClass,	    paramPanel[SCRIPTED], 
		    XmNleftAttachment,	    XmATTACH_FORM,
		    XmNtopAttachment,	    XmATTACH_WIDGET,
		    XmNtopWidget,	    script_paramWidget[SCRIPT_FILE], 
		    NULL);
    
    str = XmStringCreateSimple("Select");
    tempWidget = (Widget) XtVaCreateManagedWidget("Select",
			xmPushButtonWidgetClass,    paramPanel[SCRIPTED],
			XmNlabelString,		    str,
			XmNrightAttachment,	    XmATTACH_FORM, 
			XmNtopAttachment,	    XmATTACH_WIDGET, 
			XmNtopWidget,		    tempLabel,
			XmNrightOffset,		    2,
			NULL);	
    XmStringFree(str);    
    XtAddCallback(tempWidget, XmNactivateCallback, 
		  (XtCallbackProc) Do_Specify_File, (XtPointer) SCRIPT_LOG_FILE);
		  
    script_paramWidget[SCRIPT_LOG_FILE] = XtVaCreateManagedWidget("scriptText", 
		    xmTextFieldWidgetClass, paramPanel[SCRIPTED], 
		    XmNtraversalOn,	    TRUE, 
		    XmNleftAttachment,	    XmATTACH_FORM, 
		    XmNrightAttachment,     XmATTACH_WIDGET, 
		    XmNrightWidget,	    tempWidget, 
		    XmNbottomAttachment,    XmATTACH_OPPOSITE_WIDGET,
		    XmNbottomWidget,	    tempWidget, 
		    XmNfontList,	    fontlist, 
		    XmNvalue,		    LogFile, 
		    NULL);
    
    XtAddCallback(script_paramWidget[SCRIPT_LOG_FILE], XmNactivateCallback, 
		  (XtCallbackProc) Do_Param,  
		  (XtPointer) NULL);
		    	    	    
    XtAddCallback(script_paramWidget[SCRIPT_LOG_FILE], XmNactivateCallback, 
		  (XtCallbackProc) XmProcessTraversal,  
		  (XtPointer) XmTRAVERSE_NEXT_TAB_GROUP);

    
    /* Other parameters */
    tempLabel = XtVaCreateManagedWidget("Other Parameters:", 
		    xmLabelGadgetClass,	    paramPanel[SCRIPTED], 
		    XmNleftAttachment,	    XmATTACH_FORM,
		    XmNtopAttachment,	    XmATTACH_WIDGET,
		    XmNtopWidget,	    script_paramWidget[SCRIPT_LOG_FILE],
		    XmNtopOffset,	    10,
		    NULL);

    otherParams = XtVaCreateWidget("otherParamsRowCol", 
		    xmRowColumnWidgetClass, paramPanel[SCRIPTED], 
		    XmNtopAttachment,	    XmATTACH_WIDGET,
		    XmNtopWidget,	    tempLabel,
		    XmNtopOffset,	    5,
		    XmNrightAttachment,	    XmATTACH_FORM,
		    XmNleftAttachment,	    XmATTACH_FORM,
		    NULL);
    
    for (i=2; i<NUM_SCRIPT_PARAMS; i++)
    {
	tempWidget = XtVaCreateWidget("form", 
		    xmFormWidgetClass,	otherParams, 
		    NULL);
				  
	script_paramWidget[i] = XtVaCreateManagedWidget("paramText", 
		    xmTextFieldWidgetClass, tempWidget, 
		    XmNtraversalOn,	    TRUE, 
		    XmNmaxLength,	    16, 
		    XmNrightAttachment,	    XmATTACH_FORM, 
		    XmNfontList,	    fontlist, 
		    XmNvalue,		    script_paramValue[i], 
		    NULL);
	
	tempLabel = XtVaCreateManagedWidget(script_paramLabel[i], 
		    xmLabelGadgetClass,	    tempWidget, 
		    XmNrightAttachment,	    XmATTACH_WIDGET,
		    XmNrightWidget,	    script_paramWidget[i], 
		    NULL);
		    
	XtAddCallback(script_paramWidget[i], XmNactivateCallback, 
		    (XtCallbackProc) Do_Param,  
		    (XtPointer) i);
		    	    	    
	XtAddCallback(script_paramWidget[i], XmNactivateCallback, 
		    (XtCallbackProc) XmProcessTraversal,  
		    (XtPointer) XmTRAVERSE_NEXT_TAB_GROUP);
		    
	XtManageChild(tempWidget);	    
    }			   
    XtManageChild(otherParams);
    XtManageChild(paramPanel[SCRIPTED]); 
    
    
    /*****************************************************************
     *  Creates paramFrame[ITERATED] - the frame which holds the paramPanel 
     *	for the Fixed Mode row-column widget 
     */    					 
    paramFrame[ITERATED] = XtVaCreateWidget("sessionFrame[ITERATED]", 
		    xmFrameWidgetClass,	    inputPanel,
		    XmNleftAttachment,	    XmATTACH_FORM,
		    XmNleftOffset,	    5,  
		    XmNtopAttachment,	    XmATTACH_WIDGET, 
		    XmNtopWidget,	    paramLabel, 
		    XmNtopOffset,	    5, 
		   
		    XmNshadowType,	    XmSHADOW_IN,  
		    XmNmappedWhenManaged,   TRUE,
		    NULL);
    
    paramPanel[ITERATED] = XtVaCreateWidget("paramPanel[ITERATED]",
                    xmFormWidgetClass, paramFrame[ITERATED], 
		    NULL);
		    
    /* Log file selection */
    tempLabel = XtVaCreateManagedWidget("Log File:", 
		    xmLabelGadgetClass,	    paramPanel[ITERATED], 
		    XmNleftAttachment,	    XmATTACH_FORM,
		    XmNtopAttachment,	    XmATTACH_FORM, 
		    NULL);
    
    str = XmStringCreateSimple("Select");
    tempWidget = (Widget) XtVaCreateManagedWidget("Select Log",
			xmPushButtonWidgetClass,    paramPanel[ITERATED],
			XmNlabelString,		    str,
			XmNtopAttachment,	    XmATTACH_WIDGET, 
			XmNtopWidget,		    tempLabel,
			XmNrightAttachment,	    XmATTACH_FORM, 
			XmNrightOffset,		    2,
			NULL);	
    XmStringFree(str);    
    XtAddCallback(tempWidget, XmNactivateCallback, 
		  (XtCallbackProc) Do_Specify_File, LOG_FILE);
		  
    fixed_paramWidget[LOG_FILE] = XtVaCreateManagedWidget("logText", 
		    xmTextFieldWidgetClass, paramPanel[ITERATED], 
		    XmNtraversalOn,	    TRUE, 
		    XmNleftAttachment,	    XmATTACH_FORM,
		    XmNrightAttachment,     XmATTACH_WIDGET, 
		    XmNrightWidget,	    tempWidget, 
		    XmNbottomAttachment,    XmATTACH_OPPOSITE_WIDGET,
		    XmNbottomWidget,	    tempWidget, 
		    XmNfontList,	    fontlist, 
		    XmNvalue,		    LogFile, 
		    NULL);
    
    XtAddCallback(fixed_paramWidget[LOG_FILE], XmNactivateCallback, 
		  (XtCallbackProc) Do_Param,  
		  (XtPointer) NULL);
		    	    	    
    XtAddCallback(fixed_paramWidget[LOG_FILE], XmNactivateCallback, 
		  (XtCallbackProc) XmProcessTraversal,  
		  (XtPointer) XmTRAVERSE_NEXT_TAB_GROUP);
		  
    
    /* Other parameters */
    tempLabel = XtVaCreateManagedWidget("Other Parameters:", 
		    xmLabelGadgetClass,	    paramPanel[ITERATED], 
		    XmNleftAttachment,	    XmATTACH_FORM,
		    XmNtopAttachment,	    XmATTACH_WIDGET,
		    XmNtopWidget,	    fixed_paramWidget[LOG_FILE],
		    XmNtopOffset,	    10,
		    NULL);

    otherParams = XtVaCreateWidget("otherParamsRowCol", 
		    xmRowColumnWidgetClass, paramPanel[ITERATED], 
		    XmNtopAttachment,	    XmATTACH_WIDGET,
		    XmNtopWidget,	    tempLabel,
		    XmNtopOffset,	    5,
		    XmNrightAttachment,	    XmATTACH_FORM,
		    XmNleftAttachment,	    XmATTACH_FORM,
		    NULL);
		    
    for (i=1; i<NUM_ITERATED_PARAMS; i++)
    {
	tempWidget = XtVaCreateManagedWidget("form", 
			    xmFormWidgetClass,	otherParams, 
			    NULL);
	fixed_paramWidget[i] = XtVaCreateManagedWidget("paramText", 
		    xmTextFieldWidgetClass, tempWidget, 
		    XmNtraversalOn,	    TRUE, 
		    XmNmaxLength,	    16, 
		    XmNrightAttachment,	    XmATTACH_FORM, 
		    XmNfontList,	    fontlist, 
		    XmNvalue,		    fixed_paramValue[i], 
		    NULL);
	
	tempLabel = XtVaCreateManagedWidget(fixed_paramLabel[i], 
		    xmLabelGadgetClass,	    tempWidget, 
		    XmNrightAttachment,	    XmATTACH_WIDGET,
		    XmNrightWidget,	    fixed_paramWidget[i], 
		    NULL);
		    
	XtAddCallback(fixed_paramWidget[i], XmNactivateCallback, 
		    (XtCallbackProc) Do_Param,  
		    (XtPointer) i);
				    
	XtAddCallback(fixed_paramWidget[i], XmNactivateCallback, 
		    (XtCallbackProc) XmProcessTraversal,  
		    (XtPointer) XmTRAVERSE_NEXT_TAB_GROUP);
		
	if (NUM_GROUPS == i)  /* Add LastAddressText widget */
	{
	    tempWidget = XtVaCreateManagedWidget("form", 
			    xmFormWidgetClass,	otherParams, 
			    NULL);
			    
	    str = XmStringCreateLtoR("(lastAddress: )", "charset1");
	    LastAddressText = XtVaCreateManagedWidget("fixedLastAddress", 
			  xmLabelWidgetClass,	tempWidget, 
			  XmNlabelString,	str,
			  XmNfontList,		fontlist, 
			  XmNrightAttachment,	XmATTACH_FORM, 
			  NULL);
	    XmStringFree(str);
	}
    }		    
    XtManageChild(otherParams);
    XtManageChild(paramPanel[ITERATED]);
    
    
    /* Turn on appropriate input mode display & display input panel */   
    XtManageChild(paramFrame[Mode]);
    XtManageChild(inputPanel);
    
    /*************************************************************************
     * Create outFrame - The frame which contains the outText text widget 
     *                    which is responsible for communicating with the
     *			  child process.
     */
    
    tempLabel = XtVaCreateManagedWidget("DREC Output", 
		    xmLabelGadgetClass,	mainPanel, 
		    XmNleftAttachment,	XmATTACH_WIDGET,
		    XmNleftWidget,	inputPanel, 
		    XmNleftOffset,	5, 
		    XmNtopAttachment,	XmATTACH_WIDGET, 
		    XmNtopWidget,	topFrame, 
		    XmNtopOffset,	10, 
		    NULL);
    
    
    outFrame = XtVaCreateManagedWidget("outFrame", 
		    xmFrameWidgetClass,	mainPanel,
		    XmNrightAttachment, XmATTACH_FORM,
		    XmNrightOffset,	5, 
		    XmNleftAttachment,	XmATTACH_WIDGET, 
		    XmNleftWidget,	paramFrame[ITERATED], 
		    XmNleftOffset,	5, 
		    XmNtopAttachment,	XmATTACH_WIDGET, 
		    XmNtopWidget,	tempLabel, 
		    XmNbottomAttachment,  XmATTACH_OPPOSITE_WIDGET, 
		    XmNbottomWidget,	paramFrame[ITERATED],
		    XmNshadowType,	XmSHADOW_IN, 
		    NULL);
		    
    outText = XtVaCreateManagedWidget("outText",  
		    xmTextWidgetClass, outFrame, 
		    XmNfontList, fontlist,
		    XmNeditable, FALSE, 
		    XmNcolumns, 48, 
		    NULL);
    XmTextSetString(outText, " ");
    
    /* Create QUIT button */
    str = XmStringCreateSimple("Quit");
    quitButton = (Widget) XtVaCreateManagedWidget("Quit",
			xmPushButtonWidgetClass, mainPanel,
			XmNlabelString,		str,
			XmNrightAttachment,	XmATTACH_FORM, 
			/* XmNbottomAttachment,	XmATTACH_FORM, */
			XmNrightOffset,		10,
			XmNbottomOffset,	10,   
			XmNtopAttachment,	XmATTACH_WIDGET, 
			XmNtopWidget,		paramFrame[ITERATED], 
			XmNtopOffset,		10, 
			NULL);	
    XmStringFree(str);    
    XtAddCallback(quitButton, XmNactivateCallback, (XtCallbackProc)Do_Quit, NULL);		

    UpdateLastAddress();
    XtRealizeWidget(topLevel);    
    return TRUE;
    
}  /* end setup_gui() */

static void Do_Start()
{
    char cmd[8];
    char *drecArgs[2*NUM_ITERATED_PARAMS + 2];
    char **argPtr = drecArgs;
    int i, writePipeFd;
    
    int pipe_fd[2];
    
    /* Get latest param values and check */
    if (!UpdateParams()) return;
  
    /* Build exec command string using argument values */
    strcpy(cmd, "drec");
    *argPtr++ = cmd;
    *argPtr++ = "-G";
    switch(Mode)
    {
	case SCRIPTED:
	/* drec [-gqv][-p port][-i interface][-S startTime(h:m:s[GMT])]
	 *	[scriptFile] logFile
	 */
	    for(i = 2; i < NUM_SCRIPT_PARAMS; i++)
	    {
		*argPtr++ = script_arg[i];
		*argPtr++ = script_paramValue[i];
	    }
	    if (strcmp(script_paramValue[SCRIPT_FILE], "NONE"))
		*argPtr++ = script_paramValue[SCRIPT_FILE];  /* param zero */
	    *argPtr++ = script_paramValue[SCRIPT_LOG_FILE];  /* param one */
	    *argPtr = NULL;	    
	    break;
	    
	case ITERATED:
	/* drec -b baseAddress [-gqv][-p port] [-n numGroups][-i interface]
         *        [-S startTime(h:m:s[GMT])][-d duration (sec)] logFile
	 */
	    for(i=1; i< NUM_ITERATED_PARAMS; i++)
	    {
		*argPtr++ = fixed_arg[i];
		*argPtr++ = fixed_paramValue[i];
	    }
	    *argPtr++ = fixed_paramValue[LOG_FILE];
	    *argPtr = NULL;
	    break;
    }
    
    /* Uncomment to print resulting cmd syntax 
    argPtr = drecArgs;
    printf("Cmd: ");
    while(*argPtr) printf("%s ", *argPtr++);
    printf("\n"); */
    
     /* Create pipe to get output from DREC child */
    if(pipe(pipe_fd) < 0)
    {
	perror("DREC: pipe() error");
	Alert("DREC: pipe() error!");
	return;
    }
    readPipeFd = pipe_fd[0];
    writePipeFd = pipe_fd[1];
    
    switch(drecID = fork())
    {
	case -1:
	    perror("DREC: fork() error");
	    Alert("DREC: fork() error!");
	    return;
	    break;
	    
	case 0:		/* child */
	    XtDestroyWidget(topLevel);
	    for (i = 0; i < NSIG; i++) 
		signal(i, SIG_DFL);  /* defeat any existing signal handling */
	    close(readPipeFd);
	    if (writePipeFd != STDOUT_FILENO)
	    {
		if (dup2(writePipeFd, STDOUT_FILENO) != STDOUT_FILENO)
		    perror("DREC dup2(stdout) error");
		if (dup2(writePipeFd, STDERR_FILENO) != STDERR_FILENO)
		    perror("DREC dup2(stderr) error");
		close(writePipeFd);   
	    }
	    fflush(stdout);
	    if (execvp(cmdPath, drecArgs) < 0)
	    {
		perror("DREC: execv() error"); 
		fflush(stdout);
		exit(-1);
	    }
	    fflush(stdout);
	    exit(0);
	    break;
	    
	default:
	    close(writePipeFd);
	    break;	      
    }
    
    liveChild = TRUE;
    killPipe = FALSE;
    drecInputID = XtAppAddInput(appContext, readPipeFd, 
		       (XtPointer) XtInputReadMask, 
		       (XtInputCallbackProc) readPipe , 
		       NULL);
    signal(SIGCHLD, child_died);      /* Called when drec dies */
    
    /* Everything OK, update display */    
    outIndex = 0;
    strcpy(outputBuffer, "DREC: Starting ...\n");
    XmTextSetString(outText, outputBuffer);
      
    XtVaSetValues(startButton, XmNsensitive, FALSE, 
		    XmNpushButtonEnabled, FALSE, 
		    NULL);
    XtVaSetValues(stopButton, XmNsensitive,  TRUE, 
		    XmNpushButtonEnabled, TRUE, 
		    NULL);   	       
    if (UseAnimation)
    {
	bangCount = 0;
	bangInc = 1;
	theBangMap = bangMaps[bangCount];
	bangTimerID = XtAppAddTimeOut(appContext, BANG_INTERVAL, 
			(XtTimerCallbackProc) Bang_Timer, 
			NULL);
    }
    else
    {
	theBangMap = drecMap2;
	redrawBangLabel();
    }
    XtVaSetValues(topLevel, XmNiconPixmap, drecMap2, NULL);
    
}  /* end Do_Start() */

static void Do_Stop()
{
    int status;  
    
    if (liveChild) 
    {
	signal(SIGCHLD, SIG_DFL); 	
	while(kill(drecID, SIGINT) !=0) 
	    perror("DREC: kill() error");
	liveChild = FALSE;
    } 
    
    if (drecID)
    {
	while(waitpid(drecID, &status, 0) != drecID) 
	    perror("DREC: wait() error");
	drecID = 0;
    }
    
    if (drecInputID)
    {
	killPipe = TRUE;
	readPipe(NULL, &readPipeFd, NULL);
	close(readPipeFd);
	drecInputID = 0;
    }  
    
    /* Reset Display */
    if (bangTimerID)
    {
	XtRemoveTimeOut(bangTimerID);
	bangTimerID = 0;	
    }    
    theBangMap = drecMap1;
    redrawBangLabel();      
    XtVaSetValues(topLevel, XmNiconPixmap, drecMap1, NULL);
    XtVaSetValues(startButton, XmNsensitive, TRUE, 
		    XmNpushButtonEnabled, TRUE, 
		    NULL);  
    XtVaSetValues(stopButton, XmNsensitive,  FALSE, 
		    XmNpushButtonEnabled, FALSE, 
		    NULL); 
}  /* end Do_Stop() */

static void child_died()
 {
    liveChild = FALSE;
    XtAppAddTimeOut(appContext, 0, (XtTimerCallbackProc) Do_Stop, NULL);
 }  /* end child_died */

#define MAXLINES 128
static void readPipe(XtPointer client, int *fd, XtInputId *Id)
{
    static char buffer[MAXLINES]; 
    struct stat stat_buffer;
    int navail, nread, got;
  
    fstat(*fd, &stat_buffer);    
    navail = stat_buffer.st_size;  
    while(navail)
    {
	if (navail>MAXLINES)
	    nread = MAXLINES;
	else
	    nread = navail;
	got = read(*fd, buffer, nread);
	navail -= got;
	if ( (outIndex+got) > BUFFER_SIZE-1)
	{
	    fprintf(stderr, "DREC: Output text buffer overflow!\n");
	    got = BUFFER_SIZE - outIndex - 1;
	}
	memcpy(&outputBuffer[outIndex], buffer, got);
	outIndex += got;
	outputBuffer[outIndex] = '\0';
	XmTextSetString(outText, outputBuffer);	
    }  
    if (killPipe)
    {
	XtRemoveInput(drecInputID);
	close(readPipeFd);
	drecInputID = 0;
    }  
}  /* end readPipe() */



static void Bang_Timer(XtPointer client_data,  XtIntervalId *Id)
{ 
    bangTimerID = XtAppAddTimeOut(appContext, BANG_INTERVAL, 
		    (XtTimerCallbackProc) Bang_Timer, 
		    NULL);
    bangCount += bangInc;
    if ((bangCount == 0) || (bangCount == NUM_BANGS-1)) bangInc *= -1; 
    theBangMap = bangMaps[bangCount]; 
    redrawBangLabel(); 
}  /* end Bang_Timer() */



static void Do_Mode_Change(Widget widget, int which, 
			   XmToggleButtonCallbackStruct *state)
{
    switch (which) 
    {
	case SCRIPTED:        /* Script file selected */
	    if (state->set) {
		Mode = SCRIPTED;
		XtManageChild(paramFrame[SCRIPTED]);
	    }
	    else 
	    {
		XtUnmanageChild(paramFrame[SCRIPTED]);
	    }
	    break;
	case ITERATED:        /* Fixed Input selected */
	    if (state->set) 
	    {
		Mode = ITERATED;
		XtManageChild(paramFrame[ITERATED]);
	    }
	    else 
	    {
		XtUnmanageChild(paramFrame[ITERATED]);
	    }
	    break;
    }
}  /* end Do_Mode_Change() */


/* Handle Text based parameters */
static void Do_Param(Widget w, XtPointer client_data, 
		     XmAnyCallbackStruct *cbs)
{
    int param = (int) client_data;
    char *textPtr;
    
    XtVaGetValues(w,  XmNvalue, &textPtr,  NULL);
    CheckParam(param, textPtr);
    if (param == SCRIPT_FILE) ScanScript(textPtr);
    
}  /* end Do_Param() */

static void UpdateLastAddress()
{
    char text[32];
    XmString str;
    struct in_addr theAddr;
    
    theAddr.s_addr = htonl(ntohl(baseAddress.s_addr) + numGroups -1);   
    sprintf(text, "(lastAddress: %s)", inet_ntoa(theAddr));
    str = XmStringCreateLtoR(text, "charset1");
    XtVaSetValues(LastAddressText, XmNlabelString, str, NULL);
    XmStringFree(str);
}


static void Do_Specify_File(Widget widget, XtPointer client_data, XtPointer call_data)
{
    static Widget dialog = NULL;
    int which = (int) client_data;
  
    if (!dialog)
    {
	if (Mode == SCRIPTED)
	    dialog = XmCreateFileSelectionDialog(paramPanel[SCRIPTED], 
			"Script_Selection", NULL, 0);
	else
	    dialog = XmCreateFileSelectionDialog(paramPanel[ITERATED], 
			"Script_Selection", NULL, 0);	
	XtAddCallback(dialog, XmNcancelCallback, (XtCallbackProc) XtUnmanageChild, NULL);		
    }
    
    if (which == SCRIPT_FILE)
	XtVaSetValues(XtParent(dialog), XmNtitle, "Script file selection", NULL);
    else
	XtVaSetValues(XtParent(dialog), XmNtitle, "Log file selection", NULL);
    XtRemoveAllCallbacks(dialog, XmNokCallback);
    XtRemoveAllCallbacks(dialog, XmNhelpCallback);   		    
    XtAddCallback(dialog, XmNokCallback, (XtCallbackProc) File_Callback, 
	    (XtPointer) which);
    XtAddCallback(dialog, XmNhelpCallback, (XtCallbackProc) File_Callback, 
	    (XtPointer) which);
    
    XtManageChild(dialog);
    XtPopup(XtParent(dialog), XtGrabNone);
}  /* end Do_Specify_File() */



static void File_Callback(Widget dialog, XtPointer client_data, 
			    XmFileSelectionBoxCallbackStruct *cbs)
{
    char *file = NULL;
    int which = (int) client_data;
    
    if (cbs) 
    {
	switch(cbs->reason) 
	{
	    case XmCR_OK:
		if (!XmStringGetLtoR(cbs->value, XmSTRING_DEFAULT_CHARSET, &file))
		    return; /* internal error */
		if (Mode == SCRIPTED)
		{
		    if (CheckParam(which, file))
		    {
			if (SCRIPT_FILE == which)
			    if (ScanScript(file))
				XmTextSetString(script_paramWidget[which], file);
		    }
		}
		else  /* Mode == ITERATED */
		{
		    if (which != LOG_FILE)
		    {
			Alert("Invalid callback error - Contact developer");
			return;
		    }
		    if (CheckParam(which, file))
			XmTextSetString(fixed_paramWidget[which], file);
		}
		XtUnmanageChild(dialog);
		XtFree(file);
		break;
      
	    case XmCR_HELP:
		if (which == SCRIPT_FILE)
		    Alert("Choose an existing DREC script file.\n(See the documentation for details.)");
		else
		    Alert("Choose a file (new or existing) for DREC \nto use for logging packet information.");
	}
    }
    
}  /* end File_Callback() */

static int ScanScript(char *file)
{
    if(PreLoadDrecScript(file,  
		  script_paramValue[SCRIPT_PORT], 
		  script_paramValue[SCRIPT_IFACE], 
		  script_paramValue[SCRIPT_START]))
    {
	XmTextSetString(script_paramWidget[SCRIPT_PORT], 
		script_paramValue[SCRIPT_PORT]);
	XmTextSetString(script_paramWidget[SCRIPT_IFACE], 
		script_paramValue[SCRIPT_IFACE]);
	XmTextSetString(script_paramWidget[SCRIPT_START], 
		script_paramValue[SCRIPT_START]);
	return TRUE;
    }
    else
    {
	Alert("Error parsing script!");
	return FALSE;
    }
}  /* end ScanScript() */

static void Do_Quit()
{
    Do_Stop();  /* Stop any packet generation */    
    XtDestroyWidget(topLevel);  /* shut down display */
    exit(0);          
}  /* end Do_Quit() */


static int UpdateParams()
{
    int i;
    char *textPtr;
    
    switch (Mode)
    {
	case SCRIPTED:
	    for(i=0; i< NUM_SCRIPT_PARAMS; i++)
	    {
		XtVaGetValues(script_paramWidget[i],  
		    XmNvalue, &textPtr,  
		    NULL);
		if (!CheckParam(i, textPtr)) return FALSE;
	    }
	    break;
	    
	case ITERATED:
	     for(i=0; i< NUM_ITERATED_PARAMS; i++)
	    {
		XtVaGetValues(fixed_paramWidget[i],  
			    XmNvalue, &textPtr,  
			    NULL);
		if (!CheckParam(i, textPtr)) return FALSE;
	    }
	    break;
    }
    return TRUE;
}  /* end UpdateParams() */

static int CheckParam(int param, char *theText)
{
    extern int errno;
    int tempint;
    struct stat script_file;
    char hostname[256];
    struct hostent *hostentry;
    RecvPort *portList;
    
    switch (Mode)
    {
	case (SCRIPTED):
	    switch(param) 
	    {
		case SCRIPT_FILE:
		    if(strcmp(theText, "NONE"))
		    {
			if (stat(theText, &script_file) < 0)
			{
			    Alert("Invalid Scriptfile!");
			    return FALSE;
			}
			if (!(S_ISREG(script_file.st_mode)))
			{
			    Alert("Invalid Scriptfile!");
			    return FALSE;
			}
		    }
		    strcpy(ScriptFile, theText);
		    strcpy(script_paramValue[SCRIPT_FILE], theText);
		    break;
		
		case SCRIPT_LOG_FILE:
		    strcpy(LogFile, theText);
		    strcpy(script_paramValue[SCRIPT_LOG_FILE], theText);
		    XmTextSetString(fixed_paramWidget[LOG_FILE], 
				    theText);
		    break;
		    
		case SCRIPT_PORT:
		    strcpy(script_paramValue[SCRIPT_PORT], theText);
		    portList = BuildPortList(theText);
		    XmTextSetString(script_paramWidget[SCRIPT_PORT], 
				    script_paramValue[SCRIPT_PORT]);
		    if(!portList)
		    {
			Alert("Invalid port(s)!");
			return FALSE;
		    }
		    defaultPort = (unsigned short) portList->port;
		    DestroyPortList(&portList);
		    break;
		    
		case SCRIPT_IFACE:
		    strcpy(interfaceName, theText);
		    strcpy(script_paramValue[SCRIPT_IFACE], theText);
		    break;
		       
		case SCRIPT_START:
		    strcpy(StartTime, theText);
		    strcpy(script_paramValue[SCRIPT_START], theText);
		    break;
	    
		default:
		    Alert("Unimplemented field!");
		    return FALSE;
		    break;
	    }
	    break;
	
	case (ITERATED):
	    switch(param)
	    {
		case LOG_FILE:
		    strcpy(LogFile, theText);
		    strcpy(fixed_paramValue[LOG_FILE], theText);
		    strcpy(fixed_paramValue[SCRIPT_LOG_FILE], theText);
		    XmTextSetString(script_paramWidget[SCRIPT_LOG_FILE], 
				    theText);
		    break;
		    
		case BASE_ADDRESS:
		    baseAddress.s_addr = inet_addr(theText);
		    if (baseAddress.s_addr == INADDR_NONE) 
		    {						
			Alert("Invalid baseAddress!");
			return FALSE;
		    }
		    else if (!IsMulticast(baseAddress))
		    {
			/* if not multicast we just listen to our unicast address(es) */
			if (gethostname(hostname, 256) < 0) 
			{
			    Alert("baseAddress error: Can't get local hostname!");
			    return FALSE;
			}
			else
			{
			    if ((hostentry = gethostbyname(hostname)) == NULL) 
			    {
				Alert("baseAddress error: Can't get local IP address!\n");
				return FALSE;
			    }
			    else
			    {
				memcpy(&baseAddress.s_addr, 
				       hostentry->h_addr_list[0], 
				       sizeof(baseAddress.s_addr));
				if (numGroups != 1)
				{
				  Alert("Can only listen on _your_ unicast addresses!");
				  numGroups = 1;
				  XtVaSetValues(fixed_paramWidget[NUM_GROUPS], 
						XmNvalue, "1", 
						NULL); 
				}
			    }
			}
		    }
		    sprintf(fixed_paramValue[BASE_ADDRESS], "%s", 
			    inet_ntoa(baseAddress));
		    XmTextSetString(fixed_paramWidget[BASE_ADDRESS], 
				    fixed_paramValue[BASE_ADDRESS]);
		    UpdateLastAddress();
		    break;
		
		case NUM_GROUPS:
		    tempint = strtol(theText,(char **)NULL, 10);
		    if (tempint <= 0)
		    {
			Alert("Invalid numGroups!");
			return FALSE;
		    }
		    numGroups = tempint;
		    sprintf(fixed_paramValue[NUM_GROUPS], "%d", numGroups);
		    XmTextSetString(fixed_paramWidget[NUM_GROUPS], 
				    fixed_paramValue[NUM_GROUPS]);
		    UpdateLastAddress();
		    break;
		
		case PORT:
		    strcpy(fixed_paramValue[PORT], theText);
		    portList = BuildPortList(theText);
		    XmTextSetString(fixed_paramWidget[PORT], 
				    fixed_paramValue[PORT]);
		    if(!portList)
		    {
			Alert("Invalid port(s)!");
			return FALSE;
		    }
		    defaultPort = (unsigned short) portList->port;
		    DestroyPortList(&portList);
		    break;
		    
		case DURATION:
		    tempint = strtol(theText,(char **)NULL, 10);
		    if ((tempint < 0) || errno)
		    {
			Alert("Invalid Duration!");
			return FALSE;
		    }
		    Duration = tempint;
		    sprintf(fixed_paramValue[DURATION], "%d", Duration);
		    XmTextSetString(fixed_paramWidget[DURATION], 
				    fixed_paramValue[DURATION]);
		    break;
		
		case OFFSET:
		    tempint = strtol(theText,(char **)NULL, 10);
		    if ((tempint < 0) || errno)
		    {
			Alert("Invalid Offset!");
			return FALSE;
		    }
		    Offset = tempint;
		    sprintf(fixed_paramValue[OFFSET], "%d", Offset);
		    XmTextSetString(fixed_paramWidget[OFFSET], 
				    fixed_paramValue[OFFSET]);
		    break;
		
		case INTERFACE:
		    strcpy(interfaceName, theText);
		    strcpy(fixed_paramValue[INTERFACE], theText);
		    break;
		
		case START_TIME:
		    strcpy(StartTime, theText);
		    strcpy(fixed_paramValue[START_TIME], theText);
		    break;
	    
		default:
		    Alert("Unimplemented field!");
		    return FALSE;
		    break;
	    }
	    break;
    }
    return TRUE;
}  /* end CheckParam() */



static void redrawBangLabel()
{
    Display *dpy = XtDisplay(topLevel);   
    XSetFunction(dpy, gc, GXcopy);   
    XCopyArea(dpy, theBangMap, XtWindow(bangLabel), 
		  gc, 0, 0, 
		  bangWidth, bangHeight, 
		  0, 0);    
}  /* end redrawBangLabel() */


static void Alert(char *text)
{
    Widget dialog;
    Arg arg[1];
    XmString str;
    
    str = XmStringCreateSimple(text);
    XtSetArg(arg[0], XmNmessageString, str);
    dialog = (Widget) XmCreateMessageDialog(topLevel, "DREC", arg, 1);
    XmStringFree(str);
    XtManageChild(dialog);
    XtVaSetValues(dialog, 
		    XmNdeleteResponse, XmDESTROY,
		    XmNdialogStyle, XmDIALOG_PRIMARY_APPLICATION_MODAL,
		    NULL);
    XtUnmanageChild(XmMessageBoxGetChild(dialog, XmDIALOG_CANCEL_BUTTON));
    XtUnmanageChild(XmMessageBoxGetChild(dialog, XmDIALOG_HELP_BUTTON));
    
}  /* end Alert() */


static int LoadMgenIcon(char **theIcon, Pixmap *theMap, Widget widget, 
			int *width, int *height)
{
    XpmAttributes *xpm_attr;
    XpmColorSymbol *csymbol;
    Colormap cmap;
    Pixel bg;
    int status;
    
    XtVaGetValues(widget, XmNbackground, &bg, NULL);
    XtVaGetValues(widget, XmNcolormap, &cmap, NULL);
    
    if(!(xpm_attr = (XpmAttributes *)calloc(1, sizeof(XpmAttributes))))
    {
	perror("DREC: calloc(XpmAttributes error)");
	return FALSE;
    }
    if(!(csymbol = (XpmColorSymbol *)calloc(1, sizeof(XpmColorSymbol))))
    {
	perror("DREC: calloc(XpmAttributes error)");
	return FALSE;
    }
    
    /* Create pixmap */    
    csymbol->name = "Background";
    csymbol->pixel = bg;
    xpm_attr->colorsymbols = csymbol;
    xpm_attr->numsymbols = 1;
    xpm_attr->valuemask = (XpmCloseness | XpmColormap | XpmColorSymbols);
    xpm_attr->closeness = 40000;
    xpm_attr->colormap = cmap;
    status = XpmCreatePixmapFromData(XtDisplay(widget),
				 XRootWindowOfScreen(XtScreen(widget)),
				 theIcon, theMap, NULL, xpm_attr);
    if (status != XpmSuccess) 
    {
	fprintf(stderr, "DREC: XpmError: %s\n", XpmGetErrorString(status));
	return FALSE;
    }
    
    *width = xpm_attr->width;
    *height = xpm_attr->height;   
    free(xpm_attr);
    free(csymbol);
    return TRUE;
}  /* end LoadMgenIcon() */

/* This is required for IRIX 5.3 */
#ifdef _SGI
char *XpmGetErrorString(int errcode)
{
    switch (errcode) 
    {
	case XpmColorError:
	    return ("XpmColorError");
	case XpmSuccess:
	    return ("XpmSuccess");
	case XpmOpenFailed:
	    return ("XpmOpenFailed");
	case XpmFileInvalid:
	    return ("XpmFileInvalid");
	case XpmNoMemory:
	    return ("XpmNoMemory");
	case XpmColorFailed:
	    return ("XpmColorFailed");
	default:
	    return ("Invalid XpmError");
    }
}
#endif // _SGI

#endif // _GUI
