#ifdef _RSVP  

/* These routines should work with ISI's rsvpd rel 4.2a1 */

#include <unistd.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>

#ifdef _LINUX
#include <math.h>  /* for RSVP defs for Linux */
#endif

#include "rapi_err.h"

#include "mgenRsvp.h"
#include "drecEvent.h"

/* Private constants */
static rapi_filter_t *snd_template = NULL;
static rapi_adspec_t *snd_adspec = NULL;
static rapi_policy_t *snd_policy = NULL;
static rapi_policy_t *resv_policy = NULL;
#ifndef TRUE
static const int TRUE =  1;
static const int FALSE = 0;
#endif TRUE

/* Private function prototypes */
static int RsvpHandler(
     int                 Sid,            /* Session ID  */
     int                 EventType,      /* Event type */
     int                 Style,          /* WF, SE, or FF */
     int                 ErrorCode,      /* (error event): error code */
     int                 ErrorValue,     /* (error event): error value */
     struct sockaddr     *ErrorNode,     /* Node where error occurred */
     unsigned char       ErrorFlags,  
     int                 Index,          /* Index to bad flow descriptor */
     int                 FilterSpecNo,   /* # of filter specs supplied */
     rapi_filter_t       *FilterSpec_list, 
     int                 FlowspecNo,     /* # of flowspecs supplied */
     rapi_flowspec_t     *Flowspec_list, 
     int                 AdspecNo,       /* # of ADSPECs supplied */
     rapi_adspec_t       *Adspec_list, 
     void                *Event_Arg);     /* Supplied by app (flow_id) */

int RsvpSession(struct sockaddr_in *destAddr, int flow_id)
{   
    int sessID = 0;
    int error_code = NO_ERROR;

    sessID = rapi_session((struct sockaddr *) destAddr, 
			   17,   /* 17 = UDP protocol */
			   0,    /* use simple TSpec/Flowspec formats */
			   ( rapi_event_rtn_t ) RsvpHandler, 
			  (void *) flow_id, 
			  &error_code );
   
    if (sessID == NULL_SID)
    {
	fprintf(stderr, "\nMGEN: RsvpRegister: rapi_session() error: ");
	if (error_code < 100)
	  fprintf(stderr, "%s\n", rapi_errlist[error_code]);
	else
	  fprintf(stderr, "SWG number: %d\n", error_code);
	return -1;
    }	

    return sessID;			
}  /* end RsvpSession() */

/* Register as sender with new or modified Tspec. */
int RsvpSender(int *sessID, 
	       rapi_tspec_t *sendTspec, 
	       int ttl, 
	       struct sockaddr_in *senderAddress)
{
  int err = rapi_sender(*sessID,	/* Session ID */
		    0,			/* flags */
		    (struct sockaddr *) senderAddress, /* sender host address */
		    snd_template,       /* sender template (unused?) */
		    sendTspec,          /* sender Tspec */
		    snd_adspec,         /* MGEN doesn't use this yet */
		    snd_policy,         /* or this */
		    ttl);  
    if (err != 0) 
    {
	fprintf(stderr, "\nMGEN: RsvpSender: rapi_sender() error: ");
	if (err < 100)
	    fprintf(stderr, "%s\n", rapi_errlist[err]);
	else
	    fprintf(stderr, "SWG number: %d\n", err);
	fflush(stderr);    
	RsvpRelease(*sessID);
	*sessID = 0;
	return FALSE;
    }
    else
    {
	return TRUE;
    }
}  /* end RsvpSender() */


int RsvpReserve(int sessID, void *event, struct sockaddr_in *localAddress)
{
    DrecEvent *theEvent = (DrecEvent *)event;
    int err = 0;
    
    err = rapi_reserve(sessID, 
		       RAPI_REQ_CONFIRM, /* to get confirmation upcalls */
		       (struct sockaddr * ) localAddress, 
		       theEvent->rsvp.style, 
		       (rapi_stylex_t *) NULL, 
		       resv_policy, 
		       theEvent->rsvp.nfilts,
		       theEvent->rsvp.filts,
		       theEvent->rsvp.nflows,
		       theEvent->rsvp.flows);			       
    if (err != 0) 
    {
	fprintf(stderr, "\nDREC: RsvpReserve: rapi_reserve() error: ");
	if (err < 100)
	  fprintf(stderr, "%s\n", rapi_errlist[err]);
	else
	  fprintf(stderr, "SWG number: %d\n", err);
	return FALSE;
    }
    else
    {
	return TRUE;
    }
}  /* end RsvpReserve() */
    


/* This is the RSVP Event Callback routine (useful for debug) */
static int RsvpHandler(
     int                 Sid,            /* Session ID  */
     int                 EventType,      /* Event type */
     int                 Style,          /* WF, SE, or FF */
     int                 ErrorCode,      /* (error event): error code */
     int                 ErrorValue,     /* (error event): error value */
     struct sockaddr     *ErrorNode,     /* Node where error occurred */
     unsigned char       ErrorFlags,  
     int                 Index,          /* Index to bad flow descriptor */
     int                 FilterSpecNo,   /* # of filter specs supplied */
     rapi_filter_t       *FilterSpec_list, 
     int                 FlowspecNo,     /* # of flowspecs supplied */
     rapi_flowspec_t     *Flowspec_list, 
     int                 AdspecNo,       /* # of ADSPECs supplied */
     rapi_adspec_t       *Adspec_list, 
     void                *Event_Arg)     /* Supplied by app (flow_id) */
{

  /* (TBD) Log some of this RSVP event notification to DREC log file */
    switch(EventType)
    {
	case(RAPI_PATH_EVENT):
	  printf("DREC: RSVP has generated a PATH EVENT for flow #%d.\n", (int) Event_Arg);
	  printf("        Session ID: %d\n\n", Sid);
	  break;
	  
	case(RAPI_RESV_EVENT):
	  printf("MGEN: RSVP has generated a RESV EVENT for flow #%d.\n", (int) Event_Arg);
	  printf("        Session ID: %d\n\n", Sid);
	  break;
	  
	case(RAPI_PATH_ERROR):
	  printf("MGEN: RSVP has generated a PATH ERROR for flow #%d.\n", (int) Event_Arg);
	  printf("        %s\n", rsvp_errlist[ErrorCode]);
	  printf("        Session ID: %d\n", Sid);
	  break;
	  
	case(RAPI_RESV_ERROR):
	  printf("DREC: RSVP has generated a RESV ERROR for flow #%d.\n", (int) Event_Arg);
	  printf("        %s\n", rsvp_errlist[ErrorCode]);
	  printf("        Session ID: %d\n", Sid);
	  break;
    
	case(RAPI_RESV_CONFIRM):
	  printf("DREC: RSVP has generated a RESV CONFIRM for flow #%d.\n", (int) Event_Arg);
	  printf("        Session ID: %d\n\n", Sid);
	  break;
    
	default:
	  printf("MGEN/DREC: RSVP has generated an unknown error for flow #%d.\n\n", 
		 (int) Event_Arg);
	  printf("        Session ID: %d\n", Sid);
	  printf("        Error Value: %x\n", ErrorValue);
	  printf("        Error Node: %s.\n\n", inet_ntoa(((struct sockaddr_in *)ErrorNode)->sin_addr));
	  break;
    }
    fflush(stdout);   
    return(0);
}  /* end RsvpHandler() */
 

void RsvpRelease(int sessID)
{
  int err;
  
  if (sessID) 
    err = rapi_release(sessID);
  else
    return;
    
  if(err<0)
    {
      fprintf(stderr, "MGEN/DREC: RsvpRelease: rapi_release() error!\n");
      if (err < 100)
	fprintf(stderr, "            %s\n", rapi_errlist[err]);
      else
	fprintf(stderr, "            SWG number: %d\n", err);
    }
}

int GetFlowspec(rapi_flowspec_t *flowspec, int type, 
		 float32_t resv_R, float32_t resv_S, 
		 float32_t resv_r, float32_t resv_b, float32_t resv_p, 
		 u_int32_t resv_m, u_int32_t resv_M)
{
  flowspec->len =  sizeof(rapi_hdr_t) + sizeof(qos_flowspecx_t);
  flowspec->form = RAPI_FLOWSTYPE_Simplified;
  
  switch (type)
  {
      case QOS_CNTR_LOAD:
	flowspec->specbody_qosx.spec_type = type;
	flowspec->specbody_qosx.xspec_r = resv_r;
	flowspec->specbody_qosx.xspec_b = resv_b;
	flowspec->specbody_qosx.xspec_p = resv_p;
	flowspec->specbody_qosx.xspec_m = resv_m;
	flowspec->specbody_qosx.xspec_M = resv_M;
	break;
	
      case QOS_GUARANTEED:
	flowspec->specbody_qosx.spec_type = type;
	flowspec->specbody_qosx.xspec_R = resv_R;
	flowspec->specbody_qosx.xspec_S = resv_S;
	flowspec->specbody_qosx.xspec_r = resv_r;
	flowspec->specbody_qosx.xspec_b = resv_b;
	flowspec->specbody_qosx.xspec_p = resv_p;
	flowspec->specbody_qosx.xspec_m = resv_m;
	flowspec->specbody_qosx.xspec_M = resv_M;
	break;
	
      default:
	fprintf(stderr, "DREC: GetFlowSpec() Bad flowspec type!\n");
	return FALSE;
  }
  return TRUE;
}  /* end GetFlowSpec() */


/* Fill in a Tspec based on params (Currently "Simplified" format only) */
void GetTspec(rapi_tspec_t *tspec, 
	      float32_t resv_r, float32_t resv_b, float32_t resv_p, 
              u_int32_t resv_m, u_int32_t resv_M)
{
    tspec->len = sizeof(rapi_hdr_t) + sizeof(qos_tspecx_t);
    tspec->form = RAPI_TSPECTYPE_Simplified;
    tspec->tspecbody_qosx.spec_type = QOS_TSPEC;
    tspec->tspecbody_qosx.xtspec_r = resv_r;
    tspec->tspecbody_qosx.xtspec_b = resv_b;
    tspec->tspecbody_qosx.xtspec_p = resv_p;
    tspec->tspecbody_qosx.xtspec_m = resv_m;
    tspec->tspecbody_qosx.xtspec_M = resv_M;
}  /* end GetTSpec() */


/* Create filter for source given address and port */
void GetFilterSpec(struct in_addr host, unsigned short port, 
		   rapi_filter_t *filt)
{
    filt->len =  sizeof(rapi_hdr_t) + sizeof(rapi_filter_base_t);
    filt->form = RAPI_FILTERFORM_BASE;
    filt->filt_u.base.sender.sin_family = AF_INET;
    filt->filt_u.base.sender.sin_addr = host;
    filt->filt_u.base.sender.sin_port = htons(port);
}  /* end GetFilterSpec */

#endif // _RSVP

