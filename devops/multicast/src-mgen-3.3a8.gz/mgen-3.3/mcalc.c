/*
 * "mcalc.c" - an example DREC log file analysis utility
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>

#include "flowStat.h"
#include "version.h"

#ifndef TRUE
static const int TRUE = 1;
static const int FALSE = 0;
#endif 

#ifndef NULL
#define NULL 0
#endif

#ifndef INADDR_NONE
#define INADDR_NONE 0xffffffff
#endif

/* Drec log file line types */
typedef enum DrecLogEntry 
{ 
    NULL_ENTRY,	/* Invalid (or unknown) entry */
    PACKET,     /* Recv packet entry */
    JOIN,       /* Host JOIN entry */
    LEAVE       /* Host LEAVE entry */
} DrecLogEntry;


const int MAXLINES = 256;   /* Maximum log file line length */
const float MAX_TIME = (float) (24*3600);  /* seconds in 24 hours */

/* Private function prototypes */
static int readline(FILE *theFile, char *theBuffer);
static void mark();
static double DeltaTime(double time1, double time2);
inline double Time2Sec(int hour, int min, double sec)
{
    return (3600.0*(double)hour + 60.0*(double)min + sec);
}
static inline int IsMulticast(struct in_addr theAddress)
{
    return ((htonl(0xf0000000) & theAddress.s_addr) == 
            htonl(0xe0000000));
}  /* end IsMulticast() */
static int ParsePacketEntry( const char	    *buffer, 
			     unsigned long  *flow, 
			     unsigned long  *seq, 
			     struct in_addr *srcAddr, 
			     unsigned short *srcPort, 
			     struct in_addr *destAddr, 
			     unsigned short *destPort,
			     double	    *txTime, 
			     double	    *rxTime, 
			     int	    *size);
static int ParseJoinEntry(char *buffer, struct in_addr *gaddr, double *joinTime);
static int ParseLeaveEntry(char *buffer, struct in_addr *gaddr, double *leaveTime);

int main(int argc, char *argv[])
{
    FILE *logFile;
    char buffer[MAXLINES];
    int line = 0, markCount = 0;
    DrecLogEntry entry;
    
    unsigned long flow, seq;
    FlowAddress faddr;
    double txTime, rxTime, joinTime, delay, flow_period;
    struct in_addr gaddr;
    int size;
    FlowStat *theFlow;
    GroupInfo *groupInfo;
    FlowStat *flowStatList = NULL;
    GroupInfo *groupInfoList = NULL;
    double jitter, jitter_total = 0, jitter_min = 0, jitter_max = 0;
    double pkt_rate = 0.0, data_rate = 0.0, prate, drate;
    double delay_total = 0.0, delay_min = 0.0, delay_max = 0.0;
    double join_delay = 0.0, join_total = 0.0, join_min = 0.0, join_max = 0.0;
    unsigned long join_count = 0;
    unsigned long flowCount = 0, groupCount = 0, pkt_count = 0;
    unsigned long drop_count = 0, drops;
    int firstFlow = TRUE, Verbose = TRUE;
    
    extern char *optarg;
    extern int optind, opterr;
    register int op;
    int nonopt_argc;
    
    /* Parse command line arguments */
    optind = 1; 
    opterr = 0;
    while ((op = getopt(argc, argv, "vq")) != EOF)
    {
	switch(op)
	{
	    case 'v':
		printf("MCALC Version %s\n", VERSION);
		exit(0);
		break;
		
	    case 'q':
		Verbose = FALSE;
		break;
		
	    default:
		fprintf(stderr, "MCALC: Invalid command line option!\n");
		fprintf(stderr, "Usage: mcalc [-q] logFile\n");
		exit(-1);
	}
    }
    nonopt_argc = argc - optind;
    if (nonopt_argc != 1)
    {
	printf("Usage: mcalc [-q] <logFile>\n");
	exit(-1);
    }
    
    printf("MCALC: Version %s\n", VERSION);
    
    if ( (logFile = fopen(argv[optind], "r") ) == NULL)
    {
	perror("MCALC: Error opening data file");
	exit(-1);
    }
    
    /* Some initializations */
    faddr.dest.sin_family = AF_INET;
    faddr.src.sin_family = AF_INET;
    
    /* Parse log file and accumulate flow statistics */    
    while(readline(logFile, buffer))
    {
	if(++markCount > 100)
	{
	    mark();
	    markCount = 0;
	}
	line++;
	
	/* What kind of log file entry? */
	if (!strncmp(buffer, "Flow", 4))
	    entry = PACKET;
	 else if (!strncmp(buffer, "JOIN", 4))
	    entry = JOIN;
	 else if (!strncmp(buffer, "LEAVE", 5))
	    entry = LEAVE;
	 else
	    entry = NULL_ENTRY;
	 
	 switch(entry)
	 {
	    case PACKET:
		if(!ParsePacketEntry(buffer, &flow, &seq, 
				     &faddr.src.sin_addr, &faddr.src.sin_port, 
				     &faddr.dest.sin_addr, &faddr.dest.sin_port, 
				     &txTime, &rxTime, &size))
		{
		    fprintf(stderr, "MCALC: Error parsing log at line %d.\n", line);
		    break;
		    /* DestroyFlowStatList(&flowStatList);
		    DestroyGroupInfoList(&groupInfoList);
		    fclose(logFile);
		    exit(-1); */
		}
		if(!(theFlow = FindFlowStat(&faddr, flowStatList)))
		{
		    /* new flow */
		    if(!(theFlow = (FlowStat *) calloc(1, sizeof(FlowStat))))
		    {
			perror("MCALC: calloc(FlowStat) error");
			DestroyFlowStatList(&flowStatList);
			DestroyGroupInfoList(&groupInfoList);
			fclose(logFile);
			exit(-1);
		    }
		    memcpy(&theFlow->flow_addr, &faddr, sizeof(FlowAddress));
		    if(IsMulticast(faddr.dest.sin_addr))
		    {
			if((groupInfo = FindGroupInfo(faddr.dest.sin_addr, groupInfoList)))
			{
			    theFlow->join_time = groupInfo->join_time;
			}
			else
			{
			    theFlow->join_time = 0.0;
			    fprintf(stderr, "MCALC: Warning! Recv'd packet for group not yet joined at line %d.\n", line);
			}
		    }
		    theFlow->id = flow;
		    theFlow->first_pkt_time = rxTime;
		    theFlow->last_pkt_time = rxTime;
		    theFlow->low_seq = seq;
		    theFlow->high_seq = seq;
		    theFlow->pkt_count = 1;
		    theFlow->byte_count = size;
		    delay = DeltaTime(rxTime, txTime);
		    theFlow->delay_total = delay;
		    theFlow->delay_max = delay;
		    theFlow->delay_min = delay;
		    PrependFlowStat(theFlow, &flowStatList);
		}		
		else
		{
		    if (rxTime < theFlow->first_pkt_time)
			theFlow->first_pkt_time = rxTime;
		    else if (rxTime > theFlow->last_pkt_time)
			theFlow->last_pkt_time = rxTime;
		    if (seq < theFlow->low_seq)
			theFlow->low_seq = seq;
		    else if (seq > theFlow->high_seq)
			theFlow->high_seq = seq;
		    theFlow->pkt_count++;
		    theFlow->byte_count += size;
		    delay = DeltaTime(rxTime, txTime);
		    theFlow->delay_total += delay;
		    if (delay > theFlow->delay_max)
			theFlow->delay_max = delay;
		    else if (delay < theFlow->delay_min)
			theFlow->delay_min = delay;
		}
		break;
		
	    case JOIN:
		if(!ParseJoinEntry(buffer, &gaddr, &joinTime))
		{
		    fprintf(stderr, "MCALC: Error parsing log at line %d.\n", line);
		    DestroyFlowStatList(&flowStatList);
		    DestroyGroupInfoList(&groupInfoList);
		    fclose(logFile);
		    exit(-1);
		}
		groupInfo = FindGroupInfo(gaddr, groupInfoList);
		if (groupInfo)
		{
		    printf("MCALC: Warning group %s joined more than once.\n", 
			    inet_ntoa(gaddr));
		}
		else
		{
		    if(!(groupInfo = (GroupInfo *) calloc(1, sizeof(GroupInfo))))
		    {
			perror("MCALC: calloc(GroupInfo) error");
			DestroyFlowStatList(&flowStatList);
			DestroyGroupInfoList(&groupInfoList);
			fclose(logFile);
			exit(-1);
		    }
		    groupInfo->addr.s_addr = gaddr.s_addr;
		    groupInfo->join_time = joinTime;
		    PrependGroupInfo(groupInfo, &groupInfoList);
		    break;
		}
		break;
		
	    case LEAVE:
		/* MCALC doesn't do anything with "LEAVE" log entries yet */
		ParseLeaveEntry(buffer, &gaddr, &joinTime);
		break;
		
	    case NULL_ENTRY:
		fprintf(stderr, "MCALC: Warning! Invalid log entry at line %d.\n", line);
		break;
	 }  /* end switch(entry) */
    }
    fclose(logFile);
    
    /* Remove progress mark */
    printf("\b");
    
    /* Now summarize collected stats */
    theFlow = flowStatList;
    if (Verbose) 
	printf("---------------------------------------------------------\n");
    while(theFlow)
    {
	join_delay = DeltaTime(theFlow->first_pkt_time, theFlow->join_time);
	flow_period = DeltaTime(theFlow->last_pkt_time , 
	                        theFlow->first_pkt_time);
	prate = (float) (theFlow->pkt_count - 1)/ (float) flow_period;
	drate = 0.008 * ((float) theFlow->byte_count) / flow_period;
	drops = theFlow->high_seq - theFlow->low_seq + 1 - 
		theFlow->pkt_count;
	delay = theFlow->delay_total / (float)theFlow->pkt_count;
	jitter = (theFlow->delay_max - theFlow->delay_min);
	
	if (Verbose)
	{
	    printf("FLOW: %04lu   SOURCE:%16s:%-5hu DESTINATION:", theFlow->id, 
			inet_ntoa(theFlow->flow_addr.src.sin_addr), 
			(unsigned short) ntohs(theFlow->flow_addr.src.sin_port));		    
	    printf("%16s:%-5hu\n", inet_ntoa(theFlow->flow_addr.dest.sin_addr), 
			(unsigned short) ntohs(theFlow->flow_addr.dest.sin_port));	    
	    printf("   Num pkts recvd  : %5lu\n", theFlow->pkt_count);
	    printf("   Join delay      : %9.3f sec\n", join_delay);
	    printf("   Recv pkt rate   : %9.3f pkt/sec\n", prate);
	    printf("   Recv data rate  : %9.3f kbps\n", drate);
	    printf("   Pkts dropped    : %5lu\n", drops);
	    
	    printf("   Ave. Tx Delay   : %9.3f sec\n", delay);
	    printf("   Max. Tx Delay   : %9.3f sec\n", theFlow->delay_max);
	    printf("   Min. Tx Delay   : %9.3f sec\n", theFlow->delay_min);
	    printf("   Delay variation : %9.3f sec\n", jitter);
	    printf("---------------------------------------------------------\n");
	}
	if (firstFlow)
	{
	    flowCount = 1;
	    if (join_delay) join_count = 1;
	    join_total = join_delay;
	    join_min = join_delay;
	    join_max = join_delay;
	    delay_total = delay;
	    delay_min = theFlow->delay_min;
	    delay_max = theFlow->delay_max;
	    jitter_total = jitter;
	    jitter_min = jitter;
	    jitter_max = jitter;
	    pkt_count = theFlow->pkt_count;
	    drop_count = drops;
	    pkt_rate = prate;
	    data_rate = drate;
	    firstFlow = FALSE; 
	}
	else
	{
	    flowCount++;
	    join_total += join_delay;
	    if (join_delay) join_count++;
	    if (join_delay < join_min) 
		join_min = join_delay;
	    else if (join_delay > join_max) 
		join_max = join_delay;
	    delay_total += delay;
	    if (theFlow->delay_min < delay_min)
		delay_min = theFlow->delay_min;
	    if (theFlow->delay_max > delay_max)
		delay_max = theFlow->delay_max;
	    jitter_total += jitter;
	    if(jitter < jitter_min)
		jitter_min = jitter;
	    else if (jitter > jitter_max)
		jitter_max = jitter;
	    pkt_count += theFlow->pkt_count;
	    drop_count += drops;
	    pkt_rate += prate;
	    data_rate += drate;
	}
	theFlow = theFlow->child;
    }
    
    groupInfo = groupInfoList;
    groupCount = 0;
    while(groupInfo)
    {
	groupCount++;
	groupInfo = groupInfo->child;
    }
    
    printf("MCALC: SUMMARY RESULTS\n");
    printf("MCALC: Number of active flows  :  %5lu flows\n", flowCount);
    printf("MCALC: Number of groups joined :  %5lu groups\n\n", groupCount);
    printf("MCALC: GROUP JOIN LATENCY STATISTICS\n");
    printf("MCALC: Ave. group join latency :  %9.3f sec\n", join_total/join_count);
    printf("MCALC: Min. group join latency :  %9.3f sec\n", join_min);
    printf("MCALC: Max. group join latency :  %9.3f sec\n\n", join_max);
    printf("MCALC: DATA TRANSMISSION LATENCY STATISTICS (Time-sync'd machines required!)\n");
    printf("MCALC: Ave. data latency       :  %9.3f sec\n", delay_total/flowCount);
    printf("MCALC: Min. data latency       :  %9.3f sec\n", delay_min);
    printf("MCALC: Max. data latency       :  %9.3f sec\n\n", delay_max);
    printf("MCALC: PER-FLOW DATA LATENCY VARIATION\n");
    printf("MCALC: Ave. latency variation  :  %9.3f sec\n", jitter_total/flowCount);
    printf("MCALC: Min. latency variation  :  %9.3f sec\n", jitter_min);
    printf("MCALC: Max. latency variation  :  %9.3f sec\n\n", jitter_max);
    printf("MCALC: PACKET RECEPTION STATISTICS\n");
    printf("MCALC: Total packets received  :  %5lu pkts\n", pkt_count);
    printf("MCALC: Total recv packet rate  :  %9.3f pkt/sec\n", pkt_rate);
    printf("MCALC: Total recv data rate    :  %9.3f kbps\n", data_rate);
    printf("MCALC: Est. num pkts dropped   :  %5lu pkts\n", drop_count);
    
    DestroyFlowStatList(&flowStatList);
    DestroyGroupInfoList(&groupInfoList);
    exit(0);
}  /* end main() */

static int ParsePacketEntry( const char	    *buffer, 
			     unsigned long  *flow, 
			     unsigned long  *seq, 
			     struct in_addr *srcAddr, 
			     unsigned short *srcPort, 
			     struct in_addr *destAddr, 
			     unsigned short *destPort,
			     double	    *txTime, 
			     double	    *rxTime, 
			     int	    *size)
{
    char *ptr, *ptr2;
    static char tempText[64];
    int hour, min;
    double sec;
    
    /* Get Flow ID */
    if(!(ptr = strchr(buffer, '>'))) return FALSE;
    ptr++;
    if(1 != sscanf(ptr, "%lu", flow)) return FALSE;
    /* Get Sequence number */
    if(!(ptr = strchr(ptr, '>'))) return FALSE;
    ptr++;
    if(1 != sscanf(ptr, "%lu", seq)) return FALSE;
    /* Get Source Addr/Port */
    if(!(ptr = strchr(ptr, '>'))) return FALSE;
    ptr++;
    if(1 != sscanf(ptr, "%63s", tempText)) return FALSE;
    if(!(ptr2 = strchr(tempText, '/'))) return FALSE;
    *ptr2++ = '\0';
    if(INADDR_NONE == (srcAddr->s_addr = inet_addr(tempText))) return FALSE;
    if(1 != sscanf(ptr2, "%hu", srcPort)) return FALSE;
    *srcPort = htons(*srcPort);
    /* Get Destination Addr/Port */
    if(!(ptr = strchr(ptr, '>'))) return FALSE;
    ptr++;
    if(1 != sscanf(ptr, "%63s", tempText)) return FALSE;
    if(!(ptr2 = strchr(tempText, '/'))) return FALSE;
    *ptr2++ = '\0';
    if(INADDR_NONE == (destAddr->s_addr = inet_addr(tempText))) return FALSE;
    if(1 != sscanf(ptr2, "%hu", destPort)) return FALSE;
    *destPort = htons(*destPort);
    /* Get TxTime */
    if(!(ptr = strchr(ptr, '>'))) return FALSE;
    ptr++;
    if(3 != sscanf(ptr, "%d:%d:%lf", &hour, &min, &sec)) return FALSE;
    *txTime = Time2Sec(hour, min, sec);
    /* Get RxTime */
    if(!(ptr = strchr(ptr, '>'))) return FALSE;
    ptr++;
    if(3 != sscanf(ptr, "%d:%d:%lf", &hour, &min, &sec)) return FALSE;
    *rxTime = Time2Sec(hour, min, sec);
    /* Get packet payload size */
    if(!(ptr = strchr(ptr, '>'))) return FALSE;
    ptr++;
    if(1 != sscanf(ptr, "%d", size)) return FALSE;
    return TRUE;
}  /* end ParsePacketEntry() */

static int ParseJoinEntry(char *buffer, struct in_addr *gaddr, double *joinTime)
{
    char tempText[64];
    int hour, min;
    float sec;
    
    if(4 != sscanf(buffer, "JOIN %32s Time>%d:%d:%f", 
		    tempText, &hour, &min, &sec))
    {
	return FALSE;
    }   
    if(INADDR_NONE == (gaddr->s_addr = inet_addr(tempText))) return FALSE;
    *joinTime = Time2Sec(hour, min, sec);
    return TRUE;
}  /* end ParseJoinEntry() */

static int ParseLeaveEntry(char *buffer, struct in_addr *gaddr, double *leaveTime)
{
    char tempText[64];
    int hour, min;
    float sec;
    
    if(4 != sscanf(buffer, "LEAVE %32s Time>%d:%d:%f", 
		    tempText, &hour, &min, &sec))
    {
	return FALSE;
    }   
    if(INADDR_NONE == (gaddr->s_addr = inet_addr(tempText))) return FALSE;
    *leaveTime = Time2Sec(hour, min, sec);
    return TRUE;
}  /* end ParseLeaveEntry() */

/* Computes time1 - time2 */
static double DeltaTime(double time2, double time1)
{
    if (time2 < time1)
	return(time2 - time1 + MAX_TIME);
    else
	return(time2 - time1);
}

/* Read one line of a log file */
static int readline(FILE *theFile, char *theBuffer)
{
    int count = 0;
    
    while (fread(&theBuffer[count], 1, 1, theFile) > 0)
    {
	if (theBuffer[count] == '\n') 
	{
	    theBuffer[count] = '\0';
	    if (!count) count++;
	    return (count);
	}
	if (++count == MAXLINES)
	{
	    printf("Long log file line error!\n");
	    theBuffer[MAXLINES-1] = '\0';
	    return MAXLINES-1;
	}
    }
    theBuffer[count] = '\0';
    return count;
}  /* end readline() */



static void mark()
{
    static int i = 0;
    static char chr[] = "|\\-/";
    fprintf(stderr,"\b%c",chr[i++]);
    if (i > 3) i = 0;
    fflush(stderr);
}  /* end mark() */
