#ifndef _MGEN_EVENT
#define _MGEN_EVENT

#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>

#ifdef _RSVP
#include "mgenRsvp.h"
#endif  //  // _RSVP

/* MGEN modes */
typedef enum MgenMode { SCRIPTED, ITERATED } MgenMode;

/* MGEN traffic patterns */
typedef enum MgenPattern 
{
    PERIODIC,   /* Constant, periodic packet rate, constant packet size */
    POISSON     /* Poisson packet rate, constant packet size */
} MgenPattern;

/* MGEN script commands */
typedef enum MgenCmd 
{ 
    NULL_CMD,	/* Invalid command */
    START,	/* Event start time (GMT or local time) */
    ON,		/* Initiate flow data transmission with given parameters */
    MOD,	/* Modify existing flow's data transmission parameters */
    OFF,        /* Terminate flow data transmission */
    PORT,       /* source port */
    INTERFACE,  /* multicast interface name */
    TTL	        /* multicast packet time-to-live */
} MgenCmd;

typedef struct MgenEvent
{
    MgenMode		mode;        /* ITERATED or SCRIPTED */
    MgenCmd		    cmd;
    unsigned long	id;	     /* Flow's ID number */
    unsigned long	sequence;    /* Current sequence number */
    double		    startTime;   /* Event start time (msec) */
    unsigned long	stopTime;    /* Event end time (msec) */
    MgenPattern		pattern;     /* PERIODIC or POISSON */
    float		    interval;    /* Time between packets (msec) */
    int			    size;        /* Packet size (bytes) */
    struct sockaddr_in	addr;        /* Flow's current destination address */
    
    struct in_addr	b_addr;      /* Base address for "iterated flow */
    int			n_groups;    /* Number of groups for "iterated" flow */
    int			count;	     /* Current count for "iterated" flow */
    
#ifdef _RSVP
    int			rsvpSession; /* Flow's current rsvp session id */
    int			rsvp;        /* Event contains rsvp params (TRUE or FALSE) */
    rapi_tspec_t	tspec;       /* Event TSpec params (if rsvp = TRUE) */
#endif  // _RSVP
    
    int         tos;         /* Event contain TOS params */

    struct MgenEvent	*next;       /* Points to next event for _this_ flow */
    struct MgenEvent	*parent;     /* Points to event for previous flow */
    struct MgenEvent	*child;      /* Points to event for next flow */
} MgenEvent;

typedef struct MgenFlowList
{
    MgenEvent *head;
    MgenEvent *tail;
} MgenFlowList;

/* Public function prototypes */
MgenEvent *DiscardMgenEvent(MgenEvent *theEvent, MgenFlowList *theList, 
			    MgenFlowList *theTrash);
MgenEvent *FindMgenFlowByID(int id, MgenFlowList *theList);
void InsertMgenFlow(MgenEvent *theEvent,  MgenFlowList *theList);
void AppendMgenFlow(MgenEvent *theEvent, MgenFlowList *theList);
void DestroyMgenFlowList(MgenFlowList *theList);

#endif  // _MGEN_EVENT
