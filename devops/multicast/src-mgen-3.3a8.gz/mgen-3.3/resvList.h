#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>


/* 
 * (TBD) Use some type of tree instead of simple link list to speed up
 * use of ResvList
 */
 
typedef struct ResvItem
{
    int		        sessID;  /* RSVP session id from rsvpd API */
    struct sockaddr_in	addr;    /* address:port of RSVP session */
    struct ResvItem	*parent;
    struct ResvItem     *child; 
} ResvItem;

typedef struct
{
    ResvItem *head;
    ResvItem *tail;
} ResvList;

/* Public function prototypes */
void AppendResvItem(ResvItem *theItem, ResvList *theList);
void DeleteResvItem(ResvItem *theItem, ResvList *theList);
ResvItem *FindResvItemByAddress(struct sockaddr_in *theAddress, 
				ResvList *theList);

