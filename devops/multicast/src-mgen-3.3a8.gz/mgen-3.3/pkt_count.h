#ifndef _PKT_COUNT
#define _PKT_COUNT

/*
 * pkt_count.h - header file for local network interface 
 *		 statistics/address routine
 */

/* Public function prototypes */
int GetPktCount(char	      *interface, 
	        unsigned long *Ipkts, 
		unsigned long *Ierrs, 
		unsigned long *Opkts, 
		unsigned long *Oerrs, 
		unsigned long *collide, 
		unsigned long *addr);

#endif  // _PKT_COUNT
