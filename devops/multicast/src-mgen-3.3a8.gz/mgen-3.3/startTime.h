/* "startTime.h" - This is used to convert the start time of a program to 
 *                 the appropriate time_t equivalent.
 */

#include <time.h>

time_t startTime(char *);
