#include <stdlib.h>
#include "resvList.h"

#ifndef NULL
#define NULL 0
#endif

ResvItem *FindResvItemByAddress(struct sockaddr_in *theAddress, 
				ResvList	   *theList)
{
    ResvItem *nextItem = theList->head;
    while(nextItem)
    {
	if (!memcmp(&nextItem->addr, theAddress, sizeof(struct sockaddr_in)))
	    return nextItem;
	else
	    nextItem = nextItem->child;
    }
    return NULL;
}  /* end FindResvItemByAddress() */

void AppendResvItem(ResvItem *theItem, ResvList *theList)
{  
    if ((theItem->parent = theList->tail))
	theList->tail->child = theItem;
    else
	theList->head = theItem;
    theItem->child = NULL;
    theList->tail = theItem;
}  /* end AppendResvItem() */

void DeleteResvItem(ResvItem *theItem, ResvList *theList)
{
    if (theItem->parent)
	theItem->parent->child = theItem->child;
    else
	theList->head = theItem->child;
    if (theItem->child)
	theItem->child->parent = theItem->parent;
    else
	theList->tail =theItem->parent;
    free(theItem);
}  /* end RemoveResvItem() */
