#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "sysdefs.h"  /* for NETSTAT_CMD definition */
#include "util.h"

#ifndef TRUE
static const int TRUE  = 1;
static const int FALSE = 0;
#endif //

int GetPktCount(
    char	  *interface, 
    unsigned long *Ipkts, 
    unsigned long *Ierrs,  
    unsigned long *Opkts, 
    unsigned long *Oerrs, 
    unsigned long *collide, 
    unsigned long *addr)
{
    char cmd[128];
    char format_string[128];
    FILE *statPipe;
    char buffer[MAXLINES];
    int mtu;
    int len = TRUE;
    char network[64], address[64];
#if defined(_LINUX)
    char *ptr;
    int status;
#endif // _LINUX
    
    strcpy(cmd, NETSTAT_CMD);
    strcat(cmd, interface); 
    
    if ( (statPipe = popen(cmd, "r")) == NULL)
    {
	    perror("GetPktCount: popen() error:");
	    return FALSE;
    }
    
    /* Seek the line that begins with the interface name */
    len = strlen(interface);	
    while (1)
    {
        if (!readline(statPipe, buffer))
	    {
	        perror("GetPktCount: readline() error1");
	        pclose(statPipe);
	        return FALSE;	
	    }
        /* Is this our interface ??? */
        if (!strncmp(interface, buffer, len)) break;	
    }  /* end while(seeking) */


#ifndef _LINUX    

    /* read next line for FREEBSD? */
#ifdef _FREEBSD
 if (!readline(statPipe, buffer))
    {
	    perror("GetPktCount: readline() error2");
	    pclose(statPipe);
	    return FALSE;	
    }
#endif // /* _FREEBSD */
    
    pclose(statPipe);
    strcpy(format_string, interface);
    strcat(format_string, " %d %s %s %lu %lu %lu %lu %lu");
    if (sscanf(buffer, format_string, &mtu, network,  
	       address, Ipkts, Ierrs, Opkts, Oerrs, collide) != 8)
    {
	    printf("GetPktCount: Error parsing netstat output!\n");
	    return FALSE;
    }
#else  
    if (!readline(statPipe, buffer))
	{
	    perror("GetPktCount: readline() error1a");
	    pclose(statPipe);
	    return FALSE;	
	}
    if (!(ptr = strstr(buffer, "addr:")))
    {
	    printf("GetPktCount: Error parsing ifconfig output!");
	    pclose(statPipe);
	    return FALSE;
    }
    if (sscanf(ptr, "addr:%s", address) != 1)
    {
	    printf("GetPktCount: Error parsing ifconfig output!");
	    pclose(statPipe);
	    return FALSE;
    }
    
    /* Skip line with MTU and other info */
    if (!readline(statPipe, buffer))
    {
	    perror("GetPktCount: readline() error");
	    pclose(statPipe);
	    return FALSE;	
    }
    
    /* Skip IPv6 stuff if applicable */
    if ((ptr = strstr(buffer, "inet6"))) readline(statPipe, buffer);
    
    /* Next line should have RX stats */
    if (!readline(statPipe, buffer))
    {
	    perror("GetPktCount: readline() error");
	    pclose(statPipe);
	    return FALSE;	
    }
    if (!(ptr = strstr(buffer, "RX")))
    {
	    printf("GetPktCount: Error finding RX stats!");
	    pclose(statPipe);
	    return FALSE;
    }   
    /* Get Rx packet count */
    if (!(ptr = strstr(buffer, "packets:")))
    {
	    printf("GetPktCount: Error finding RX packet count!");
	    pclose(statPipe);
	    return FALSE;
    }
    if (sscanf(ptr, "packets:%lu", Ipkts) != 1)
    {
	printf("GetPktCount: Error parsing RX packets!");
	pclose(statPipe);
	return FALSE;
    }
    /* Get Rx error count */
    if (!(ptr = strstr(buffer, "errors:")))
    {
	printf("GetPktCount: Error finding RX error count!");
	pclose(statPipe);
	return FALSE;
    }
    if (sscanf(ptr, "errors:%lu", Ierrs) != 1)
    {
	printf("GetPktCount: Error parsing RX error count!");
	pclose(statPipe);
	return FALSE;
    }
    
    /* Next line should have TX stats */
    if (!(status = readline(statPipe, buffer)))
    {
	perror("GetPktCount: readline() error3");
	pclose(statPipe);
	return FALSE;	
    }
    if (!(ptr = strstr(buffer, "TX")))
    {
	printf("GetPktCount: Error finding TX stats!");
	pclose(statPipe);
	return FALSE;
    }
    
    /* Get Tx packet count */
    if (!(ptr = strstr(buffer, "packets:")))
    {
	printf("GetPktCount: Error finding TX packet count!");
	pclose(statPipe);
	return FALSE;
    }
    status = sscanf(ptr, "packets:%lu", Opkts);
    if (status != 1)
    {
	    printf("GetPktCount: Error parsing TX packets!");
	    pclose(statPipe);
	    return FALSE;
    }
    /* Get Tx error count */
    ptr = strstr(buffer, "errors:");
    if (!ptr)
    {
	printf("GetPktCount: Error finding TX error count!");
	pclose(statPipe);
	return FALSE;
    }
    status = sscanf(ptr, "errors:%lu", Oerrs);
    if (status != 1)
    {
	printf("GetPktCount: Error parsing TX error count!");
	pclose(statPipe);
	return FALSE;
    }
    
    /* We're not sure that LINUX ifconfig -e is giving us collision counts */
    ptr = strstr(buffer, "dropped:");
    if (!ptr)
    {
	printf("GetPktCount: Error finding TX error count!");
	pclose(statPipe);
	return FALSE;
    }
    status = sscanf(ptr, "dropped:%lu", collide);
    if (status != 1)
    {
	printf("GetPktCount: Error parsing TX error count!");
	pclose(statPipe);
	return FALSE;
    }
    
#endif // _LINUX
    
    *addr = (unsigned long) inet_addr(address);
    return TRUE;
  
}  /* end GetPktCount() */
