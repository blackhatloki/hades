#include <stdlib.h>
#include <stdio.h>

#ifdef _LINUX
#include <math.h>  /* for RSVP defs for Linux */
#endif //

#include "mgenEvent.h"

#ifndef NULL
#define NULL 0
#endif // NULL

MgenEvent *FindMgenFlowByID(int id, MgenFlowList *theList)
{
    MgenEvent *nextEvent = theList->head;
    while(nextEvent)
    {
	    if (nextEvent->id == id) 
	        return nextEvent;
	    else
	        nextEvent = nextEvent->child;
    }
    return NULL;
}  /* end FindFlowByID() */

/* Flows are listed in order of their "startTime" */
void InsertMgenFlow(MgenEvent *theEvent,  MgenFlowList *theList)
{
    unsigned long eventTime = theEvent->startTime;
    MgenEvent *nextFlow = theList->tail;

    while(nextFlow)
    {
	    if (eventTime >= nextFlow->startTime)
	    {
	        theEvent->parent = nextFlow;
	        if(nextFlow->child)
		        nextFlow->child->parent = theEvent;
	        else
		        theList->tail = theEvent;
	        theEvent->child = nextFlow->child;
	        nextFlow->child = theEvent;
	        return;
	    }
	    else
	    {
	        nextFlow = nextFlow->parent;
	    }
    }
    
    /* Reached top of list */
    theEvent->parent = NULL;
    theEvent->child = theList->head;
    if(theList->head) 
	    theList->head->parent = theEvent;
    else
	    theList->tail = theEvent;
    theList->head = theEvent;
}  /* end InsertMgenFlow() */


void AppendMgenFlow(MgenEvent *theEvent, MgenFlowList *theList)
{
    if ((theEvent->parent = theList->tail))
	    theList->tail->child = theEvent;
    else
	    theList->head = theEvent;
    theList->tail = theEvent;
    theEvent->child = NULL;
}  /* end AppendMgenFlow() */

MgenEvent *DiscardMgenEvent(MgenEvent*      theEvent, 
                            MgenFlowList*   theList, 
		                    MgenFlowList*   theTrash)
{
    MgenEvent *nextEvent = NULL;
    
/* Are there any more events for this flow? */
    
    if ((nextEvent = theEvent->next))
    {
        nextEvent->sequence = theEvent->sequence;
#ifdef _RSVP
	    nextEvent->rsvpSession = theEvent->rsvpSession;
#endif // _RSVP
	    if((nextEvent->parent = theEvent->parent))
            nextEvent->parent->child = nextEvent;
        else
            theList->head = nextEvent;
        if((nextEvent->child = theEvent->child))
            nextEvent->child->parent = nextEvent;
        else
	        theList->tail = nextEvent;
    }
    else if ((nextEvent = theEvent->child))
    {
        if((nextEvent->parent = theEvent->parent))
            nextEvent->parent->child = nextEvent;
        else
            theList->head = nextEvent;
    }
    else
    {
        nextEvent = NULL;
        if((theList->tail = theEvent->parent))
            theEvent->parent->child = NULL;
        else
            theList->head = NULL;
    }
         
    if (theTrash->tail)
	    theTrash->tail->child = theEvent;
    else
	    theTrash->head = theEvent;     
    theTrash->tail = theEvent;
    theEvent->next = NULL;
    return nextEvent;
}  /* end DiscardMgenEvent() */


void DestroyMgenFlowList(MgenFlowList *theList)
{
    MgenEvent *nextFlow, *nextEvent, *thisEvent;
    
    while((nextFlow = theList->head))
    {
	    nextEvent = nextFlow->next;
	    while(nextEvent)
	    {
	        thisEvent = nextEvent;
	        nextEvent = thisEvent->next;
	        free(thisEvent);
	    }
	    theList->head = nextFlow->child;
	    free(nextFlow);
    }
    theList->tail = NULL;
}  /* end DestroyMgenFlowList() */
