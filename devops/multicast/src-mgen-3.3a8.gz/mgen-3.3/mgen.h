#ifndef _MGEN
#define _MGEN

#include "mgenEvent.h"

/* MGEN Globals used by GUI when "-g" option is invoked */
extern MgenMode Mode;
extern char ScriptFile[];

extern struct in_addr baseAddress;
extern int numGroups;
extern unsigned short destPort;
extern unsigned char ttl;

extern MgenPattern pktPattern;
extern float pktRate;
extern int pktSize;  

extern unsigned short srcPort;  /* Grab any available port by default */
extern char interfaceName[];

extern char StartTime[32];
extern int Duration;
extern int current_tos;

/* Public function prototypes */
int PreLoadMgenScript(char *scriptFile, 
		      char *portString, 
		      char *interfaceString, 
		      char *startString, 
		      char *ttlString);

#endif  // _MGEN
