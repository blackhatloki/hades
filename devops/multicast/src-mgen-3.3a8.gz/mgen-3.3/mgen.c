#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <signal.h>

#ifdef _LINUX
#include <netinet/ip.h>  /* for IPTOS defs for Linux */
#include <math.h>        /* for RSVP defs for Linux */
#endif  //  //

#include "mgen.h"
#include "mgenWait.h"
#include "pkt_count.h"
#include "startTime.h"
#include "util.h"
#include "ranlib.h"
#include "sysdefs.h"
#include "version.h"

#include "gpsPub.h"

#ifndef INADDR_NONE
#define INADDR_NONE 0xffffffff
#endif  //

#ifdef _GUI
extern void startGUI(int *argc, char *argv[], int animate);
#endif  //

/* Private constants */
static const unsigned long MGEN_TIME_MAX = 0xffffffff;
static const int MAX_FLOWS = 4096;
static const int MAX_PACKET = 4096;
#ifndef TRUE
static const int TRUE  = 1;
static const int FALSE = 0;
#endif  // _TRUE
static const int PROCESSED_FLAG = 0x02;
#define NOW 0

/* Public globals */
char ScriptFile[256];
struct in_addr baseAddress;
unsigned short destPort = 5000;
int numGroups = 1;
char StartTime[32];
int Duration = 0;
MgenPattern pktPattern = PERIODIC;
float pktRate = 1.0;
int pktSize = 64;  
unsigned short srcPort = 0;  /* Grab any available port by default */
char interfaceName[32];
unsigned char ttl = 3;
MgenMode Mode = SCRIPTED;

/* Private variables */
static MgenFlowList pendingFlows, activeFlows, expiredEvents;
static unsigned long Ipkts, Ierrs, Opkts, Oerrs, collide; 
static unsigned long packetCount = 0;
static struct timeval beginTime;
static GPSHandle gps_handle = NULL;
static GPSHandle payload_handle = NULL;

#ifdef _RSVP
static int need_rsvp = 0;  /* Global "need" for rsvpd to be running */
#endif  // _RSVP
static int GUI_Controlled = 0;

/* Private function prototypes */
static void FinishUp();
static int LoadScript(char *scriptFile, MgenFlowList *theList, 
		      unsigned short *scriptPort, char *scriptInterfaceName, 
		      char *scriptStartTime, unsigned char *scriptTTL);
static int InsertOnEvent(MgenFlowList *theList, char *theBuffer, int line);
static int InsertOffEvent(MgenFlowList *theList, char *theBuffer, int line);
static int OpenTxSocket(unsigned short *thePort, 
			unsigned char theTTL, 
			struct in_addr localAddr);
static inline int IsMulticast(struct in_addr theAddress)
{
    return ((htonl(0xf0000000) & theAddress.s_addr) == 
            htonl(0xe0000000));
}  /* end IsMulticast() */

void PrintUsage()
{
    printf("\nMGEN Version %s Usage:\n", VERSION);
    printf("Scripted  - mgen [-gqv][-i interface][-p srcPort][-t ttl][-o <offsetTime> scriptFile\n");
    printf("          or\n");
    printf("Fast mode - mgen [-gqv] -b baseAddress:port [-n numGroups][-P][-r rate (pkts/sec)][-s size (bytes)]\n");
    printf("                 [-S startTime (h:m:s[GMT])][-d duration (sec)][-i interface][-p srcPort][-t ttl]\n");
}  /* end PrintUsage() */

int main(int argc,  char *argv[])
{
    register MgenEvent *nextEvent;
    register double thisTime = 0;
    register double nextTime;
#ifdef HAVE_TOS
    int current_tos = 0;
    int tos_bits, priority_bits;
#endif  // HAVE_TOS
    MgenTicker myTicker;
    char txBuffer[MAX_PACKET];
    unsigned long *pkt_seq_num, *pkt_time_sec, *pkt_time_usec, 
		  *pkt_flow_id, *pkt_dest_addr, 
          *pkt_gps_position_long, *pkt_gps_position_lat,
          *pkt_gps_position_alt, *pkt_gps_position_stat;
    unsigned char* pkt_payload;
    register int txSocket;
    struct timeval the_time;
    struct timezone tzone;
    
    extern char *optarg;
    extern int optind, opterr;
    register int op;
    int nonopt_argc;
    
    char *strPtr;
    int tempint;
    
    int UseGUI = FALSE;
    int UseAnimation = TRUE;
    int CmdLineInterfaceName = FALSE;
    int CmdLineTTL = FALSE;
    unsigned char scriptTTL;
    time_t absoluteStartTime = NOW;
    char scriptInterfaceName[64], scriptStartTime[64];
    unsigned short scriptPort;
    struct sockaddr_in interfaceAddress;
    
    int using_gps = FALSE;
    unsigned long longitude, latitude, altitude, status;
    GPSPosition pos;
    
    int using_payload = FALSE;
    
    unsigned long offset = 0;
    
    /* Some initializations */
    baseAddress.s_addr = INADDR_NONE;
    strcpy(interfaceName, DEFAULT_INTERFACE);
    
    /* Parse command line arguments */
    optind = 1; 
    opterr = 0;
    while ((op = getopt(argc, argv, "gqvPGb:n:d:r:s:p:t:i:S:o:")) != EOF)
    {
	    switch(op)
	    {
	        case 'v':
		    printf("MGEN Version %s\n", VERSION);
		    exit(0);
		    break;

	        case 'g':
		    UseGUI = TRUE;
#ifndef _GUI
		    printf("MGEN: Not compiled with GUI support!\n");
		    exit(0);
#endif  /* _GUI */
		    break;

	        case 'G':
		    GUI_Controlled = TRUE;
		    break;

	        case 'q':
		    UseAnimation = FALSE;
		    break;

	        case 'b':
		    /* Guess what? MGEN 3.x's SCRIPTED mode is _faster_ than the fgen mode */
		    Mode = ITERATED;   /* "fgen" mode with one fast, iterated flow */
		    if ((strPtr = strstr(optarg, ":")))
		    {
		        strPtr[0] = '\0';
		        strPtr++;
		        baseAddress.s_addr = inet_addr(optarg);
		        tempint = atoi(strPtr);
		    }
		    else
		    {
		        baseAddress.s_addr = inet_addr(optarg);
		        tempint = 5000;	    
		    }		
		    if ((baseAddress.s_addr == INADDR_NONE) ||
		        (tempint < 0) || (tempint > 0xffff))
		    {
		        printf("MGEN: Invalid baseAddress:destPort!\n");
		        exit(-1);
		    }
		    destPort = (unsigned short) tempint;
		    break;
            
            case 'o':
            offset = atoi(optarg);    
            break;

	        case 'n':
		    numGroups = atoi(optarg);
		    if (numGroups < 1)
		    {
		        printf("MGEN: Invalid numGroups!\n");
		        exit(-1);
		    }
		    break;

	        case 'd':
		    Duration = atoi(optarg);
		    if (Duration < 0)
		    {
		        printf("MGEN: Invalid duration!\n");
		        exit(-1);
		    }
		    break;

	        case 'P':
		    pktPattern = POISSON;
		    break;

	        case 'r':
		    tempint = sscanf(optarg, "%f", &pktRate);
		    if (tempint != 1)
		    {
		        printf("MGEN: Bad packet rate!\n");
		        exit(-1);
		    }
		    break;

	        case 's':
		    pktSize = atoi(optarg);
		    if (pktSize < 37)
		    {
		        printf("MGEN: Minimum payload size is 37 bytes!\n");
		        exit(-1);
		    }
		    break;

	        case 'p':
		    tempint = atoi(optarg);
		    if ((tempint < 0) || (tempint > 0xffff))
		    {
		        printf("MGEN: Invalid port!\n");
		        exit(-1);
		    }
		    srcPort = (unsigned short) tempint;
		    break;

	        case 't':
		    tempint = atoi(optarg);
		    if ((tempint < 0) || (tempint > 255))
		    {
		        printf("MGEN: Invalid ttl value!\n");
		        exit(-1);
		    }
		    CmdLineTTL = TRUE;
		    ttl = (unsigned char) tempint;
		    break;

	        case 'i':
		    strncpy(interfaceName, optarg, 32);
		    interfaceName[31] = '\0';
		    CmdLineInterfaceName = TRUE;
		    break;

	        case 'S':
		    strncpy(StartTime, optarg, 32);
		    StartTime[31] = '\0';
		    if ((absoluteStartTime = startTime(StartTime)) < 0)
		    {
		        printf("MGEN: Invalid start time format!\n");
		        printf("      (hh:mm:ss, hh:mm:ssGMT, or NOW)\n");
		        exit(-1);
		    }
		    break;

	        default:
		    fprintf(stderr, "MGEN: Invalid command line option: -'%c'\n", op);
		    PrintUsage();
		    exit(0);
	    } /* end switch() */
    } /* end while() */
    
    nonopt_argc = argc - optind;

#ifdef _GUI
    if (UseGUI) 
    {
	if ((Mode == SCRIPTED) && (nonopt_argc == 1))
	    strncpy(ScriptFile, argv[optind], 256);
	else
	    strcpy(ScriptFile, "mgenScript");
	startGUI(&argc, argv, UseAnimation);
    }
#endif  /* _GUI */
   
    if ((Mode == SCRIPTED) && (nonopt_argc != 1))
    {
	    PrintUsage();
	    exit(0);
    }
    
    printf("\nMGEN: Version %s\n", VERSION);
    
      	  
    pendingFlows.head = NULL;
    pendingFlows.tail = NULL;
    activeFlows.head = NULL;
    activeFlows.tail = NULL;
    expiredEvents.head = NULL;
    expiredEvents.tail = NULL;
    
    printf("MGEN: Loading event queue ...\n");
    switch(Mode)
    {
	case SCRIPTED:
	    strcpy(scriptStartTime, "NOW");
	    scriptInterfaceName[0] = '\0';
	    scriptPort = 0;
	    scriptTTL = 0;
	    if(!LoadScript(argv[optind], &pendingFlows, 
			   &scriptPort, scriptInterfaceName, 
			   scriptStartTime, &scriptTTL))
	    {
		    fprintf(stderr, "MGEN: Error loading script!\n");
		    exit(-1);
	    }
	    if(!srcPort) 
		srcPort = scriptPort;
	    if(!absoluteStartTime)
	    {
		    if ((absoluteStartTime = startTime(scriptStartTime)) < 0)
		    {
		        printf("MGEN: Invalid script start time format!\n");
		        printf("      (hh:mm:ss, hh:mm:ssGMT, or NOW)\n");
		        exit(-1);
		    }
	    }
	    if(!CmdLineInterfaceName && strlen(scriptInterfaceName))
		strcpy(interfaceName, scriptInterfaceName);
	    if(!CmdLineTTL && scriptTTL) ttl = scriptTTL;
	    break;
	    
	case ITERATED:
	    /* Make sure "baseAddress" is valid */
	    if ((baseAddress.s_addr == INADDR_NONE) || 
		((numGroups > 1) && (!IsMulticast(baseAddress))))
	    {
		    printf("MGEN: Invalid baseAddress! (must be multicast for numGroups > 1)\n");
		    exit(-1);
	    }
	    
	    nextEvent = (MgenEvent *) calloc(1, sizeof(MgenEvent));
	    if (!nextEvent)
	    {
		    perror("MGEN: calloc(MgenEvent) error");
		    exit(-1);
	    }
	    nextEvent->mode = ITERATED;
	    nextEvent->cmd = ON;
	    nextEvent->id = 1;                /* Assume 1 for now */
	    nextEvent->sequence = 0;
	    nextEvent->startTime = 0.0;
	    if (Duration)
		nextEvent->stopTime = Duration * 1000;
	    else
		nextEvent->stopTime = MGEN_TIME_MAX;
	    nextEvent->pattern = pktPattern;
	    if (pktRate)
		nextEvent->interval = 1000.0 / pktRate;
	    else
		nextEvent->stopTime = nextEvent->startTime;
	    nextEvent->size = pktSize;
	    nextEvent->addr.sin_addr = baseAddress;
	    nextEvent->addr.sin_port = htons(destPort);
	    nextEvent->addr.sin_family = AF_INET;
	    nextEvent->b_addr = baseAddress;
	    nextEvent->n_groups = numGroups;
	    nextEvent->count = 0;
	    nextEvent->parent = NULL;
	    nextEvent->child = NULL;
	    nextEvent->next = NULL;
	    pendingFlows.head = nextEvent;
	    pendingFlows.tail = nextEvent;
	    break;
	    
	default:
	    fprintf(stderr, "MGEN: Invalid mode!\n");
	    exit(-1);
	    break;
    }  /* end switch() */
    
    /* Subscribe to GPS position advertisements (if available) */
    gps_handle = GPSSubscribe(NULL);  /* (TBD) allow gpsKey file option */
    if (gps_handle) using_gps = TRUE;
    
    
    payload_handle = GPSSubscribe("/tmp/mgenPayloadKey");
    if (payload_handle) using_payload = TRUE;
    
    /* Get interface IP address and initial stats */
    if(!GetPktCount(interfaceName, 
		    &Ipkts, &Ierrs, 
		    &Opkts, &Oerrs, 
		    &collide, 
		    (unsigned long *) &interfaceAddress.sin_addr.s_addr))
    {
	    fprintf(stderr, "MGEN: Error getting interface statistics for %s\n", interfaceName);
	    interfaceAddress.sin_addr.s_addr = INADDR_ANY;
    }
    interfaceAddress.sin_family = AF_INET;
    interfaceAddress.sin_port = 0;
    
    /* Open transmit socket */
    if ((txSocket = OpenTxSocket(&srcPort, ttl, interfaceAddress.sin_addr)) < 0)
    {
	    DestroyMgenFlowList(&pendingFlows); 
	    exit(-1);
    }
    
    /* Later calls to RsvpSender() use the "interfaceAddress" variable and for
     * the Mgen "-p" command line option or Mgen script "PORT" command to 
     * work as advertised to set the full sender address in RSVP PATH messages, 
     * RsvpSender() must have the sender port value also.
     */
    interfaceAddress.sin_port = htons(srcPort);

#ifdef _RSVP    
    if (need_rsvp)
	    printf("MGEN: Script uses RSVP, make sure 'rsvpd' is running ...\n");
#endif  // _RSVP
    
    /* Init pointers to MGEN packet fields */ 
    pkt_seq_num =    (unsigned long *) txBuffer; 
    pkt_time_sec =   (unsigned long *) (txBuffer +  4);
    pkt_time_usec =  (unsigned long *) (txBuffer +  8);
    pkt_flow_id =    (unsigned long *) (txBuffer + 12);
    pkt_dest_addr =  (unsigned long *) (txBuffer + 16);
    pkt_gps_position_long =  (unsigned long *) (txBuffer + 20);
    pkt_gps_position_lat =  (unsigned long *) (txBuffer + 24);
    pkt_gps_position_alt =  (unsigned long *) (txBuffer + 28);
    pkt_gps_position_stat =  (unsigned long *) (txBuffer + 32);
    pkt_payload = (unsigned char*) (txBuffer + 36);
    
    /* Seed rand generator with time of day */   
    printf("MGEN: Seeding random number generator ...\n"); 
    gettimeofday(&beginTime, &tzone);   
    setall(beginTime.tv_sec, beginTime.tv_usec);
       
    printf("MGEN: Beginning packet generation ...\n");
    if (!GUI_Controlled) printf("      (Hit <CTRL-C> to stop) \n");
    fflush(stdout);
    
    /* Install <CTRL-C> handler */
    signal(SIGINT, FinishUp);
    
    /* Get interface IP address and initial stats */
    if(!GetPktCount(interfaceName, 
		    &Ipkts, &Ierrs, 
		    &Opkts, &Oerrs, 
		    &collide, 
		    (unsigned long *) &interfaceAddress.sin_addr.s_addr))
    {
	    fprintf(stderr, "MGEN: Error getting interface statistics for %s\n", interfaceName);
	    Ipkts = 0;
	    Ierrs = 0;
	    Opkts = 0;
	    Oerrs = 0;
	    collide = 0;
	    interfaceAddress.sin_addr.s_addr = INADDR_ANY;
    }
    
    nextTime = 0.0;   /* Start at time ZERO by default */
    
    /* Init timing */
    InitMgenTicker(&myTicker);
    
    /* Record start of packet generation */
    gettimeofday(&beginTime, &tzone);
    
    /* If an absolute start time is given */
    if (absoluteStartTime)
    {
	    if (beginTime.tv_sec > absoluteStartTime)
	    {
	        if (!GUI_Controlled) 
		    printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
	        printf("MGEN: Specified startTime has already passed!\n");
	        close(txSocket);
	        exit(-1);
	    }
	    nextTime = (beginTime.tv_sec - absoluteStartTime) * 1000.0;
	    nextTime += (beginTime.tv_usec + 500)/1000;
    }
    
    nextTime += offset;
    
    /* Process MGEN flow queues until empty */
    while(activeFlows.head || pendingFlows.head) 
    {
        thisTime = nextTime;
        nextTime = MGEN_TIME_MAX;	        
	    if (pendingFlows.head)
	    {
	        nextEvent = pendingFlows.head;
	        while(nextEvent)
	        {
                if (nextEvent->startTime < nextTime)
                    nextTime = nextEvent->startTime;
                if ((nextEvent->startTime <= thisTime) || !activeFlows.head)
		        {
		            /* A pending flow is ready, so fetch it */
		            pendingFlows.head = nextEvent->child;
		            if (pendingFlows.head)
			            pendingFlows.head->parent = NULL;
		            else
			            pendingFlows.tail = NULL;
		            /* Move pending flow to active flow list */
		            AppendMgenFlow(nextEvent, &activeFlows);
		            nextEvent = pendingFlows.head;
		        }
		        else
		        {
		            nextEvent = NULL;
		        }
	        }
	    }
        
	    /* Pass through list, dispatching packets and keeping min. interval */
    
	    nextEvent = activeFlows.head;
	    while(nextEvent)
	    {
	        if (nextEvent->stopTime <= thisTime)
	        {
#ifdef _RSVP
		        if (!nextEvent->next || (nextEvent->next->cmd == ON))
		        {
		            if (nextEvent->rsvpSession >= 0)
		            {
			            RsvpRelease(nextEvent->rsvpSession);
			            nextEvent->rsvpSession = -1;
		            }
		        }
#endif  // _RSVP
                nextEvent = DiscardMgenEvent(nextEvent, &activeFlows, &expiredEvents);
                continue;
	        }
	        else 
	        {
		        /* Is event ready? */
		        if (nextEvent->startTime <= thisTime)
		        {
		            /* Build packet */
		            *pkt_seq_num = htonl(nextEvent->sequence); 
		            *pkt_flow_id = htonl(nextEvent->id);
		            gettimeofday(&the_time, &tzone);
		            *pkt_time_sec =  htonl((unsigned long) the_time.tv_sec);
		            *pkt_time_usec = htonl((unsigned long) the_time.tv_usec);
		    
		            /* Set next packet sequence number */
		            switch(nextEvent->mode)
		            {
			            case SCRIPTED:
			                nextEvent->sequence++;
			                break;

			            case ITERATED:
			                if (nextEvent->count++ == 0)
			                {
				                nextEvent->addr.sin_addr = nextEvent->b_addr;
			                }
			                else
			                {   
				                nextEvent->addr.sin_addr.s_addr = 
				                    htonl(ntohl(nextEvent->addr.sin_addr.s_addr) + 1);
				                nextEvent->id++;
			                }
			                if (nextEvent->count == nextEvent->n_groups) 
			                {
				                nextEvent->sequence++;
				                nextEvent->count = 0;
				                nextEvent->id = 1;
			                }
			                break;
		            }
		            *pkt_dest_addr = nextEvent->addr.sin_addr.s_addr;
                    
                    /* Fill in GPS position if applicable (8 bytes)*/
                    longitude = (unsigned long)((999.0 + 180.0)*60000.0);
                    latitude = (unsigned long)((999.0 + 180.0)*60000.0);
                    altitude = -999;
                    status = 0;
                    if (using_gps)
                    {
                        GPSGetCurrentPosition(gps_handle, &pos);
                        if (pos.xyvalid)
                        {
                            longitude = (unsigned long)((pos.x + 180.0)*60000.0);
                            latitude = (unsigned long)((pos.y + 180.0)*60000.0); 
                            status++;
                        }
                        if (pos.zvalid)
                        {
                            altitude = (long)(pos.z + 0.5);
                            if (!status) status++;  /* this shouldn't occur */
                        }
                        if (!pos.stale) status++;
                    }
                    *pkt_gps_position_long = htonl(longitude);
                    *pkt_gps_position_lat = htonl(latitude);
		            *pkt_gps_position_alt = htonl(altitude);
                    *pkt_gps_position_stat = htonl(status);
                    
                    
                    if (using_payload)
                    {
                       unsigned char payloadLen = 0;
                       GPSGetMemory(payload_handle, 0, (char*)&payloadLen, 1);
                       if ((payloadLen+37) > nextEvent->size)
                            payloadLen = nextEvent->size - 37;
                       GPSGetMemory(payload_handle, 0, (char*)pkt_payload, payloadLen+1);
                    }
                    else
                    {
                        *pkt_payload = 0;   
                    }
                    
		            /* Send packet and calculate next packet transmission time */
		            if (nextEvent->interval)
		            {
#ifdef HAVE_TOS                    
#ifdef _LINUX                   
                        if (nextEvent->tos != current_tos)
                        {
                           current_tos = nextEvent->tos;
                           priority_bits = IPTOS_PREC(current_tos);
                           if (setsockopt(txSocket, SOL_SOCKET, SO_PRIORITY, &priority_bits, 
                                          sizeof(priority_bits)) < 0)                
                               perror("MGEN : setsockopt(SO_PRIORITY) error");                           
                           tos_bits = IPTOS_TOS(current_tos);
                           if (setsockopt(txSocket, SOL_IP, IP_TOS, &tos_bits, 
                                          sizeof(tos_bits)) < 0)                
                               perror("MGEN : setsockopt(IP_TOS) error");
                           
                        }
#else
                        if (nextEvent->tos != current_tos)
                        {
                            current_tos = nextEvent->tos;
                            if (setsockopt(txSocket, IPPROTO_IP, IP_TOS, &current_tos, 
                                           sizeof(current_tos)) < 0)                
                                perror("MGEN : setsockopt(IP_TOS) error");
                        }
#endif  // /* if/else _LINUX */                    
#endif  // /* HAVE_TOS       */ 
                        
			            if (sendto(txSocket, txBuffer, nextEvent->size, 0, 
				               (struct sockaddr *) &nextEvent->addr, sizeof(struct sockaddr_in)) < 0)
			                perror("MGEN: sendto() error");   
			            else
			                packetCount++;

			            switch(nextEvent->pattern)
			            {
			                case PERIODIC:
				            nextEvent->startTime += nextEvent->interval;
				            break;

			                case POISSON:
				            nextEvent->startTime += genexp(nextEvent->interval);
				            break;
			            }			
		            }
		            else
		            {
			            /* Zero rate flows are removed unless we need to keep
			               them around for or subsequent events follow for the flow */
			            if (nextEvent->stopTime < MGEN_TIME_MAX)
			                nextEvent->startTime = nextEvent->stopTime;
#ifdef _RSVP
			            else if (nextEvent->rsvp)
			                nextEvent->startTime = MGEN_TIME_MAX - 1;
#endif  // _RSVP    
			            else
                        {
                            printf("Killing ZERO rate flow.\n");
			                nextEvent->stopTime = nextEvent->startTime;  /* Remove flow from event queue */
		                }   
                    }          		    
#ifdef _RSVP
		            /* Handle RSVP if applicable */
		            if (nextEvent->rsvp)
		            {
			            if (!(nextEvent->rsvp & PROCESSED_FLAG))
			            {			    
			                if ((nextEvent->rsvpSession >= 0) &&
			                    (nextEvent->cmd == ON))
			                {
				                RsvpRelease(nextEvent->rsvpSession);
				                nextEvent->rsvpSession = -1;
			                }			    
			                if (nextEvent->rsvpSession < 0)
			                {
				                nextEvent->rsvpSession = 
				                    RsvpSession(&nextEvent->addr, nextEvent->id);
			                }			
			                if (nextEvent->rsvpSession >= 0)
			                {
				                if(!RsvpSender(&nextEvent->rsvpSession, 
					                       &nextEvent->tspec, ttl, 
					                       &interfaceAddress))
				                {
				                    printf("MGEN: RsvpSender() error\n");
				                }
			                }
			                else
			                {				
				                printf("MGEN: RsvpSession() error\n");
			                }
			                nextEvent->rsvp |= PROCESSED_FLAG;
			            }		    
		            }
		            else
		            {
			            if (nextEvent->rsvpSession >= 0)
			            {
			                RsvpRelease(nextEvent->rsvpSession);
			                nextEvent->rsvpSession = -1;
			            }
		            }
#endif  // _RSVP   
		        }  /* end if(nextEvent->startTime <= thisTime) */
		        if (nextEvent->startTime < nextTime)
		            nextTime = nextEvent->startTime;
		        nextEvent = nextEvent->child;
	        }  /* end if/else(nextEvent->stopTime) */
	    }  /* end while(nextEvent) */
	    /* Flow control ourselves, avoiding infinite wait */
	    if (nextTime != MGEN_TIME_MAX) MgenWait((nextTime-thisTime), &myTicker);
    }  /* end while(activeFlows.head || pendingFlows.head) */
    FinishUp();
    exit(0);
}  /* end main() */

static void FinishUp()
{
    unsigned long new_Ipkts, new_Ierrs, new_Opkts, new_Oerrs, new_collide;
    unsigned long pkts, errs, collisions;
    struct in_addr interfaceAddress;
    struct timeval endTime;
    struct timezone tzone;
    double tx_time;
    
    gettimeofday(&endTime, &tzone);
    
    /* Get interface IP address and initial stats */
    if(!GetPktCount(interfaceName, 
		    &new_Ipkts, &new_Ierrs, 
		    &new_Opkts, &new_Oerrs, 
		    &new_collide, 
		    (unsigned long *) &interfaceAddress.s_addr))
    {
	    fprintf(stderr, "MGEN: Error getting interface statistics for %s\n", interfaceName);
	    new_Ipkts = 0;
	    new_Ierrs = 0;
	    new_Opkts = 0;
	    new_Oerrs = 0;
	    new_collide = 0;
	    interfaceAddress.s_addr = INADDR_ANY;
    }
    
    GPSUnsubscribe(gps_handle);
    
    if (!GUI_Controlled) 
	printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
    
    /* Empty any remaining pending events */
    DestroyMgenFlowList(&pendingFlows);   
    /* Empty any remaining active flows */
    DestroyMgenFlowList(&activeFlows);    
    /* Empty trash */   
    DestroyMgenFlowList(&expiredEvents);
    
    tx_time = (double) (((double) endTime.tv_sec + ((double) endTime.tv_usec)/1000000.0) -
	      ((double) beginTime.tv_sec + ((double) beginTime.tv_usec)/1000000.0));
    
    printf("Opkts: new:%lu old:%lu\n", new_Opkts, Opkts);
    pkts = new_Opkts - Opkts;
    errs = new_Oerrs - Oerrs;
    collisions = new_collide - collide;
    
    printf("MGEN: Packets Tx'd       : %8lu\n", packetCount);
    printf("MGEN: Transmission period: %9.3f seconds.\n", tx_time);
    printf("MGEN: Ave Tx pkt rate    : %9.3f pps.\n", ((float)packetCount)/(tx_time));
    printf("MGEN: Interface Stats    : %8s\n", interfaceName);
    printf("             Frames Tx'd : %8lu\n", pkts);
    printf("               Tx Errors : %8lu\n", errs);
#ifndef _LINUX
    printf("              Collisions : %8lu\n", collisions);
#else
    /* printf("                   Drops : %8lu\n", collisions); */
#endif  // _LINUX
    printf("MGEN: Done.\n\n");   
    exit(0);
}  /* end FinishUp() */

static int LoadScript(char *scriptFile, MgenFlowList *theList, 
		      unsigned short *scriptPort, char *scriptInterfaceName, 
		      char *scriptStartTime, unsigned char *scriptTTL)
{
    FILE *inFile;
    char scriptBuffer[MAXLINES+8];
    int tempint, line = 0;
    unsigned long msec;
    int flow;
    char cmd_text[8];
    MgenCmd cmd;
    
    /* Open the script file */
    if ( (inFile = fopen(scriptFile, "r") ) == NULL)
    {
	perror("MGEN: Error opening scriptfile");
	return FALSE;
    }
    
    /* Parse script one line at a time, creating flowList */
    while(readline(inFile, scriptBuffer))
    {
	    line++;
	    /* Determine line's script command type */
	    if (!strncmp(scriptBuffer, "START", 5))
	    {
	        cmd = START;
	    }
	    else if (!strncmp(scriptBuffer, "PORT", 4))
	    {
	        cmd = PORT;
	    }
	    else if (!strncmp(scriptBuffer, "INTERFACE", 9))
	    {
	        cmd = INTERFACE;
	    }
	    else if (!strncmp(scriptBuffer, "TTL", 3))
	    {
	        cmd = TTL;
	    }
	    else if (scriptBuffer[0] == '#')
	    {
	        cmd = (MgenCmd) NULL;  /* Comment line */
	    }
	    else if (3 == sscanf(scriptBuffer, "%ld %d %s", &msec, &flow, cmd_text))
        {
            if (!strcmp(cmd_text, "ON")) 
		        cmd = ON;
	        else if (!strcmp(cmd_text, "OFF")) 
		        cmd = OFF;
	        else if (!strcmp(cmd_text, "MOD")) 
		        cmd = MOD;
	        else
	        {
		        fprintf(stderr, "MGEN: Bad script command at line %d\n", line);
		        cmd = NULL_CMD;
	        }
	    }
	    else
	    {
	        /* Assume blank line or comment */
	        cmd = NULL_CMD;
	    }

	    switch(cmd)
	    {
	        case START:
		        if (2 != sscanf(scriptBuffer, "%s %32s", cmd_text, scriptStartTime))
		        {
		            fprintf(stderr, "MGEN: Script startTime error at line %d\n", line);		    
		            DestroyMgenFlowList(theList);
		            fclose(inFile);
		            return FALSE;
		        }
		        break;

	        case PORT:
		        if (2 != sscanf(scriptBuffer, "%s %d", cmd_text, &tempint))
		        {
		            fprintf(stderr, "MGEN: Script source port parse error at line %d\n", line);		    
		            DestroyMgenFlowList(theList);
		            fclose(inFile);
		            return FALSE;
		        }
		        if((tempint<=0) || (tempint>0xffff))
		        {
		            fprintf(stderr, "MGEN: Invalid script source port error at line %d\n", line);		    
		            DestroyMgenFlowList(theList);
		            fclose(inFile);
		            return FALSE;
		        }
		        *scriptPort = tempint;
		        break;

	        case TTL:
		        if (2 != sscanf(scriptBuffer, "%s %d", cmd_text, &tempint))
		        {
		            fprintf(stderr, "MGEN: Script ttl parse error at line %d\n", line);		    
		            DestroyMgenFlowList(theList);
		            fclose(inFile);
		            return FALSE;
		        }
		        if((tempint<0) || (tempint>255))
		        {
		            fprintf(stderr, "MGEN: Invalid script ttl error at line %d\n", line);		    
		            DestroyMgenFlowList(theList);
		            fclose(inFile);
		            return FALSE;
		        }
		        *scriptTTL = tempint;
		        break;

	        case INTERFACE:
		        if (2 != sscanf(scriptBuffer, "%s %32s", cmd_text, scriptInterfaceName))
		        {
		            fprintf(stderr, "MGEN: Script interfaceName error at line %d\n", line);		    
		            DestroyMgenFlowList(theList);
		            fclose(inFile);
		            return FALSE;
		        }
		        break;

	        case ON:
		        if(!InsertOnEvent(theList, scriptBuffer, line))
		        {
		            DestroyMgenFlowList(theList);
		            fclose(inFile);
		            return FALSE; 
		        }
		        break;

	        case MOD:
		        if(!InsertOnEvent(theList, scriptBuffer, line))
		        {
		            DestroyMgenFlowList(theList);
		            fclose(inFile);
		            return FALSE;
		        }
		        break;

	        case OFF:
		        if(!InsertOffEvent(theList, scriptBuffer, line))
		        {
		            DestroyMgenFlowList(theList);
		            fclose(inFile);
		            return FALSE;
		        }
		        break;

	        default:
		        break;
	    }
        strcpy(scriptBuffer, " ");
    }  /* end while(readline) */
    fclose(inFile);
    
    return TRUE;
}  /* end LoadScript() */

/* Scan Mgen script for PORT, INTERFACE, TTL, or START commands */
int PreLoadMgenScript(char *scriptFile, 
		      char *portString, 
		      char *interfaceString, 
		      char *startString, 
		      char *ttlString)
{
    FILE *inFile;
    int line = 0, count = 0;
    MgenCmd cmd;
    char cmd_text[16];
    char scriptBuffer[MAXLINES];
    
    /* Open the script file */
    if ( (inFile = fopen(scriptFile, "r") ) == NULL)
    {
	perror("MGEN: Error opening scriptfile");
	return FALSE;
    }
    
    /* Parse script one line at a time, creating flowList */
    strcpy(scriptBuffer, " ");
    while(readline(inFile, scriptBuffer) && count < 3)
    {
	    line++;
	    /* Determine line's script command type */
	    if (!strncmp(scriptBuffer, "START", 5))
	    {
	        cmd = START;
	        count++;
	    }
	    else if (!strncmp(scriptBuffer, "PORT", 4))
	    {
	        cmd = PORT;
	        count++;
	    }
	    else if (!strncmp(scriptBuffer, "INTERFACE", 9))
	    {
	        cmd = INTERFACE;
	        count++;
	    }
	    else if (!strncmp(scriptBuffer, "TTL", 3))
	    {
	        cmd = TTL;
	        count++;
	    }
	    else 
	    {
	        cmd = (MgenCmd) NULL;  /* Comment line */
	    }

	    switch(cmd)
	    {
	        case START:
		        if (2 != sscanf(scriptBuffer, "%s %32s", cmd_text, startString))
		        {
		            fprintf(stderr, "MGEN: Script START command error at line %d\n", line);		    
		            fclose(inFile);
		            return FALSE;
		        }
		        break;

	        case PORT:
		        if (2 != sscanf(scriptBuffer, "%s %s", cmd_text, portString))
		        {
		            fprintf(stderr, "MGEN: Script PORT command error at line %d\n", line);		    
		            fclose(inFile);
		            return FALSE;
		        }
		        break;

	        case INTERFACE:
		        if (2 != sscanf(scriptBuffer, "%s %32s", cmd_text, interfaceString))
		        {
		            fprintf(stderr, "MGEN: Script INTERFACE command error at line %d\n", line);		    
		            fclose(inFile);
		            return FALSE;
		        }
		        break;

	        case TTL:
		        if (2 != sscanf(scriptBuffer, "%s %s", cmd_text, ttlString))
		        {
		            fprintf(stderr, "MGEN: Script TTL command error at line %d\n", line);		    
		            fclose(inFile);
		            return FALSE;
		        }
		        break;

	        case NULL_CMD:
		        /* Do nothing */
		        break;

	        default:
		        /* This shouldn't happen, but you never know */
		        fprintf(stderr, "MGEN:  Attempted to process invalid command!\n");
		        break;
	    }
	    strcpy(scriptBuffer, " ");
    }  /* end while(readline) */
    
    fclose(inFile);
    return TRUE;
}  /* end PreLoadMgenScript() */

static int InsertOnEvent(MgenFlowList *theList, char *theBuffer, int line)
{
    MgenEvent *theEvent, *theFlow;
    unsigned long eventTime, destAddr;
    unsigned int IPAddr[4];
    int flowID;
    char cmd_text[8], temp_text[32];
    char flowType[32];
    unsigned short port;
    float rate;
    int size, result;
    
#if defined(_RSVP) || defined(HAVE_TOS)
    char *strPtr;
#endif  //
#ifdef _RSVP
    float32_t resv_r, resv_b, resv_p;
    u_int32_t resv_m, resv_M;
#endif  // _RSVP
    
    /* Alloc memory for the event */    
    theEvent = (MgenEvent *) calloc(1,  sizeof(MgenEvent));
    if (!theEvent)
    {
	    perror("calloc(MgenEvent) error:");
	    return FALSE;
    }
    
    result = sscanf(theBuffer, "%lu %d %s %u.%u.%u.%u:%hu %s %f %d", 
		    &eventTime, &flowID, cmd_text, 
		    &IPAddr[0], &IPAddr[1], &IPAddr[2], &IPAddr[3], 
		    &port, flowType, &rate, &size);
    if (result != 11)
    {
	    fprintf(stderr, "MGEN: Error parsing script event at line %d\n", line);
	    free(theEvent);
	    return FALSE;
    }
    
    /* Set event mode */
    theEvent->mode = SCRIPTED;
    
    /* Set event pattern */
    if (!strcmp(flowType, "PERIODIC"))
	    theEvent->pattern = PERIODIC;
    else if (!strcmp(flowType, "POISSON"))
	    theEvent->pattern = POISSON;
    else
    {
	    fprintf(stderr, "MGEN: Unknown flow type at script line %d\n", line);
	    free(theEvent);
	    return FALSE;
    }
    
    /* Set event cmd */
    if (!strcmp(cmd_text, "ON"))
	    theEvent->cmd = ON;
    else
	    theEvent->cmd = MOD;
    
    /* Set event flow id */
    if ((flowID < 0) || (flowID > MAX_FLOWS))
    {
	    fprintf(stderr, "MGEN: Illegal flow ID at script line %d\n", line);
	    free(theEvent);
	    return FALSE;
    }
    theEvent->id = flowID;
    
    /* Set event sequence, time, interval, and packet size */
    theEvent->sequence = 0;
    theEvent->startTime = (double) eventTime;
    theEvent->stopTime = 0xffffffff;
    if (rate)
	    theEvent->interval = 1000.0/rate;
    else
	    theEvent->interval = 0.0; 
	
    theEvent->size = size;
    
    /* Set flow destination address */
    sprintf(temp_text, "%d.%d.%d.%d", IPAddr[0], IPAddr[1], IPAddr[2], IPAddr[3]);
    destAddr = inet_addr(temp_text);
    if (destAddr != INADDR_NONE)
    {
	    theEvent->addr.sin_family = AF_INET;
	    theEvent->addr.sin_addr.s_addr = destAddr;
	    theEvent->addr.sin_port = htons(port);
    }
    else
    {
	    fprintf(stderr, "MGEN: Bad destination address at script line %d\n", line);
	    free(theEvent);
	    return FALSE;
    }
    
    theEvent->next = NULL;
    theEvent->parent = NULL;
    theEvent->child = NULL;
    
#ifdef _RSVP
    theEvent->rsvpSession = -1;
    /* Look for RSVP keyword and act accordingly */
    if ((strPtr = strstr(theBuffer, "RSVP")))
    {
	    /* Find TSpec and get parameters */
	    if((strPtr = strstr(strPtr, "[t")))
	    {
	        result = sscanf(strPtr, "[t %f %f %f %u %u]", &resv_r, 
			      &resv_b, &resv_p, &resv_m, &resv_M);
	        if (result != 5)
	        {
		        printf("MGEN: Error parsing RSVP params at file line %d.\n", line);
		        free(theEvent);
		        return FALSE;
	        }
	        need_rsvp = TRUE;  /* Global indication of need for rsvpd */
	        theEvent->rsvp = TRUE;
	        GetTspec(&theEvent->tspec, 
		         resv_r, resv_b, resv_p, 
		         resv_m, resv_M);	  
	    }
	    else
	    {
	        printf("MGEN: Error parsing RSVP params at file line %d.\n", line);
	        free(theEvent);
	        return FALSE;
	    }  /* end if (strPtr) */
	    need_rsvp = TRUE;  /* Global indication of need for->rsvp = FALSE; */
    }
#endif  // _RSVP
    
#ifdef HAVE_TOS
    theEvent->tos = 0;
    /* Look for TOS keyword and act accordingly */
    if ((strPtr = strstr(theBuffer, "TOS")))
    {
	    /* Find and retrieve TOS */
	    if((strPtr = strstr(strPtr, "TOS ")))
	    {
	        result = sscanf(strPtr, "TOS %i", &theEvent->tos);
	        if ((theEvent->tos < 0 || theEvent->tos > 255) || (result !=1))
            {
    		    printf("MGEN: Error parsing TOS params at file line %d. (range 0 - 255)\n", line);
	    	    free(theEvent);
		        return FALSE;
	        } 

        }
    }
#endif  // HAVE_TOS

    /* Is this flow already in list? */
    theFlow = FindMgenFlowByID(flowID, theList);
    if (theFlow)
    {
	    /* Find last event for flow */
	    while(theFlow->next) theFlow = theFlow->next;
        
	    /* Make sure this event comes later */
	    if (((theFlow->stopTime != MGEN_TIME_MAX) && 
	         (theEvent->startTime < theFlow->stopTime)) ||
	        (theEvent->startTime < theFlow->startTime))
	    {
	        fprintf(stderr, "MGEN: Script Error! Out of order event at line %d.\n", line);
	        free(theEvent);
	        return FALSE;
	    }

	    /* For "MOD", make sure it's an active flow */
	    if ((theEvent->cmd == MOD) &&
	        (theFlow->stopTime != MGEN_TIME_MAX))
	    {
	        fprintf(stderr, "MGEN: Script Error! Tried to MOD inactive flow at line %d.\n", line);
	        fprintf(stderr, "      (Should use 'ON' command instead)\n");
	        free(theEvent);
	        return FALSE;
	    }
	
	    /* For "ON", make sure it's an inactive flow */
	    if ((theEvent->cmd == ON) &&
	        (theFlow->stopTime == MGEN_TIME_MAX))
	    {
	        fprintf(stderr, "MGEN: Script Error! Tried to turn ON already active flow at line %d.\n", line);
	        fprintf(stderr, "      (Should use 'MOD' command instead)\n");
	        free(theEvent);
	        return FALSE;
	    }
	
	    /* If flow's dest address is changed, change cmd to ON */
	    if ((theEvent->cmd == MOD) &&
	        (memcmp(&theEvent->addr, &theFlow->addr, sizeof(struct sockaddr_in))))
	    {
	        theEvent->cmd = ON;
	    }
	
	    if (theFlow->stopTime == MGEN_TIME_MAX)
	        theFlow->stopTime = theEvent->startTime;
	    theFlow->next = theEvent;
	    theEvent->child = theFlow->child;
	    theEvent->parent = theFlow->parent;
    }
    else
    {
	    if (ON == theEvent->cmd)
	    {
	        InsertMgenFlow(theEvent, theList);
	    }
	    else
	    {
	        fprintf(stderr, "MGEN: Script Error! Out of order MOD event at line %d.\n", line);
	        free(theEvent);
	    }
    }
    return TRUE;  /* Everything went OK */
}  /* end InsertOnEvent() */

int InsertOffEvent(MgenFlowList *theList, char *theBuffer, int line)
{
    MgenEvent *theFlow;
    int result; 
    unsigned long eventTime;
    int flowID;
       
    result = sscanf(theBuffer, "%lu %d", 
		    &eventTime, &flowID);
    if (result != 2)
    {
	fprintf(stderr, "MGEN: Error parsing script event at line %d\n", line);
	return FALSE;
    }
        
    theFlow = FindMgenFlowByID(flowID, theList);   
    if (theFlow)
    {
	/* Find last event for flow */
	while(theFlow->next) theFlow = theFlow->next;
	/* Make sure this event comes later */
	if (eventTime < theFlow->startTime)
	{
	    fprintf(stderr, "MGEN: Script Error! Out of order event at line %d.\n", line);
	    return FALSE;
	}
	theFlow->stopTime = eventTime;
    }
    else
    {
	    fprintf(stderr, "MGEN: Script Error! Out of order OFF event at line %d.\n", line);
	    return FALSE;
    }   
    return TRUE;
}  /* end InsertOffEvent() */



static int OpenTxSocket(unsigned short *thePort, unsigned char theTTL, 
			struct in_addr localAddr)
{
    int fd;
    struct sockaddr serv_addr;
    int broadcast = 1;
    
    /* Open a socket */      
    if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0)
    {
       perror("MGEN: OpenTxSocket: socket() error");
       return -1;
    }    
    
    if (*thePort)
    {
	memset((char *)&serv_addr, 0, sizeof(struct sockaddr));	
	((struct sockaddr_in *)&serv_addr)->sin_family = AF_INET;
	((struct sockaddr_in *)&serv_addr)->sin_addr.s_addr = htonl(INADDR_ANY);
	((struct sockaddr_in *)&serv_addr)->sin_port = htons(*thePort); 
       
	if (bind(fd, &serv_addr, sizeof(struct sockaddr)) < 0)
	{
	   perror("MGEN: OpenTxSocket: bind() error");
	   close(fd);
	   return -2;
	}
    }
    
    if (setsockopt(fd, IPPROTO_IP, IP_MULTICAST_TTL, 
			&theTTL, sizeof(theTTL)) < 0) 
    { 
	perror("MGEN: OpenTxSocket: setsockopt(IP_MULTICAST_TTL) error"); 
    }   
    
    if (setsockopt(fd, IPPROTO_IP, IP_MULTICAST_IF, 
		   (char *)&localAddr, sizeof(struct in_addr)) < 0) 
    { 
	    perror("MGEN:  OpenTxSocket: setsockopt(IP_MULTICAST_IF) error");
    }
    
    if (setsockopt(fd, SOL_SOCKET, SO_BROADCAST, &broadcast, sizeof(int)) < 0)
    {
        perror("MGEN:  OpenTxSocket: setsockopt(SO_BROADCAST) error");
    }
    
    return fd;
}  /* end OpenTxSocket() */



