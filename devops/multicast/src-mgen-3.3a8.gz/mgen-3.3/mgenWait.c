#include <unistd.h>
#include <string.h>
#include "mgenWait.h"


void MgenWait(double msec,  MgenTicker *theTicker)
{
    struct timeval timeout;
    
    UpdateMgenTicker(theTicker);
    if (msec <= theTicker->count)
    {
	theTicker->count -= msec;
    }
    else
    {
	while(msec > theTicker->count)
	{
	    msec -= theTicker->count;
	    theTicker->count = 0.0;
	    timeout.tv_sec = msec/1000;
	    timeout.tv_usec = (msec - (timeout.tv_sec*1000))*1000;
	    select(1, NULL, NULL, NULL, &timeout);
	    UpdateMgenTicker(theTicker);
	}
	theTicker->count -= msec;
    }
}  /* end MgenWait() */


void InitMgenTicker(MgenTicker *theTicker)
{
    struct timezone theZone;
    theTicker->count = 0.0;
    gettimeofday(&theTicker->lastTime, &theZone);
}  /* end InitMgenTicker() */


void UpdateMgenTicker(MgenTicker *theTicker)
{
    struct timeval thisTime, *lastTime = &theTicker->lastTime;
    struct timezone theZone;
    
    gettimeofday(&thisTime, &theZone); 
    theTicker->count += ((double)(thisTime.tv_sec - lastTime->tv_sec))*1000.0 + 
	     		((double)(thisTime.tv_usec - lastTime->tv_usec))/1000.0;
    *lastTime = thisTime;
}  /* end UpdateTicker() */
