#include "util.h"

const int MAXLINES = 1024;

/* Read one line of a script file */
int readline(FILE *theFile, char *theBuffer)
{
    int count = 0;
    
    while (fread(&theBuffer[count], 1, 1, theFile) > 0)
    {
        if (theBuffer[count] == '\n') 
	    {
	        theBuffer[count] = '\0';
	        if(!count) count++;
	        return (count);
	    }
	    if (++count == MAXLINES)
	    {
	        fprintf(stderr, "Script file line too long!\n");
	        theBuffer[MAXLINES-1] = '\0';
	        return MAXLINES-1;
	    }
    }
    return count;
}  /* end readline() */

