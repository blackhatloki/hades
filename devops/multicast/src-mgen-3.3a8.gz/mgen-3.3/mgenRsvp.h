/* mgen_rsvp.h - Header file for MGEN RSVP stuff */

#ifndef _MGEN_RSVP
#define _MGEN_RSVP

#include <math.h>      /* RSVP code includes a bit messed up */
#include <rapi_lib.h>

/* MGEN Reservation Styles */
#define WILDCARD 1   
#define FIXED 2      
#define SE 3

/* MGEN RSVP Session Modes */
#define RECV	1
#define SEND	2

/* MGEN Reservation Types */
#define CONT_DELAY 1
#define PREDICTIVE 2
#define GUARANTEED 3

/* ERROR CODE DEFINES */
#define NO_ERROR 5000

/* Used to test for RSVP requirements */
#define NO_RSVP -1

int RsvpSession(struct sockaddr_in *destAddr, int flow_id);
int RsvpSender(int *sessID, 
	       rapi_tspec_t *sendTspec, 
	       int ttl, 
	       struct sockaddr_in *senderAddress);
	       
int RsvpReserve(int sessID, void *event, 
                struct sockaddr_in *localAddress);
    
void RsvpRelease(int sessID);

int GetFlowspec(rapi_flowspec_t *flowspec, int type, 
		 float32_t resv_R, float32_t resv_S, 
		 float32_t resv_r, float32_t resv_b, float32_t resv_p, 
		 u_int32_t resv_m, u_int32_t resv_M);
		
void GetTspec(rapi_tspec_t *tspec, 
	      float32_t resv_r, float32_t resv_b, float32_t resv_p, 
              u_int32_t resv_m, u_int32_t resv_M);
	     
void GetFilterSpec(struct in_addr host, unsigned short port, 
		   rapi_filter_t *filt);

#endif  _MGEN_RSVP 

