#include <stdlib.h>
#include "drecEvent.h"

#ifndef NULL
#define NULL 0
#endif

void DestroyDrecEventList(DrecEventList *theList)
{
    DrecEvent *theEvent;
    
    while(theList->head)
    {
	theEvent = theList->head;
	theList->head = theEvent->child;
	free(theEvent);
    }
    theList->tail = NULL;
}  /* end DestroyDrecEventList() */


/* Insert event, searching list from the bottom up */
void InsertDrecEvent(DrecEvent *theEvent, DrecEventList *theList)
{
    DrecEvent *nextEvent = theList->tail;
    
    while(nextEvent)
    {
	if (nextEvent->time > theEvent->time)
	{
	    nextEvent = nextEvent->parent;
	}
	else
	{
	    /* Insert event here after "nextEvent" */
	    if(!(theEvent->child = nextEvent->child))
		theList->tail = theEvent;
	    theEvent->parent = nextEvent;
	    nextEvent->child = theEvent;
	    return;
	}
    }  /* end while(nextEvent) */
       
    if ((theEvent->child = theList->head))
	theEvent->child->parent = theEvent;
    else
	theList->tail = theEvent;
    theList->head = theEvent;
    
}  /* InsertDrecEvent() */

void AppendDrecEvent(DrecEvent *theEvent,  DrecEventList *theList)
{
    if ((theEvent->parent = theList->tail))
	theList->tail->child = theEvent;
    else
	theList->head = theEvent;
    theList->tail = theEvent;
    theEvent->child = NULL;
}  /* end AppendDrecEvent() */


DrecEvent *DiscardDrecEvent(DrecEvent *theEvent, DrecEventList *theList, 
			    DrecEventList *theTrash)
{
    DrecEvent *nextEvent;
    
    if ((nextEvent = theEvent->child))
	nextEvent->parent = theEvent->parent;
    else
	theList->tail = theEvent->parent;    
    if (theEvent->parent)
	theEvent->parent->child = nextEvent;
    else
	theList->head = nextEvent;	
    if (theTrash->tail)
	theTrash->tail->child = theEvent;
    else
	theTrash->head = theEvent;
    theTrash->tail = theEvent;    
    return nextEvent;
}  /* end DiscardDrecEvent() */
