#ifndef _UTIL
#define _UTIL

#include <stdio.h>

/* Public globals */
extern const int MAXLINES;

/* Public function prototypes */
int readline(FILE *theFile, char *theBuffer);

#endif // _UTIL
