/* ranwalk.c : dynamic script generator for MGEN tools
 *             Generates a script for Drec to randomly 
 *             walk through a range of multicast addresses 
 *             with dynamic,  possibly overlapping joins
 *             & leaves
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <arpa/inet.h> 

#include "version.h" 
#include "ranlib.h"

#define TRUE  1
#define FALSE 0

#ifndef INADDR_NONE
#define INADDR_NONE 0xFFFFFFFF
#endif

#define MAX_GROUPS 3000

/* Private members */
int GroupInUse[MAX_GROUPS];
unsigned long LeaveTime[MAX_GROUPS];

/* Private function prototypes */
static int GetNextGroup(int current, int num);
 
int main(int argc,  char *argv[])
{

    extern char *optarg;
    extern int optind, opterr;
    register int op;
    int nonopt_argc;
    
    float joinRate = 1.0 , joinPeriod;
    char baseAddress[32], dottedAddress[32];
    int numGroups = 1;
    unsigned long lingerTime = 10;
    unsigned long duration = 10;
    unsigned short port = 5000;
    unsigned long base;
    struct in_addr theAddress;
    char fileName[256];
    FILE *outFile;
    int i, currentGroup, tmp;
    unsigned long currentTime;
    struct timeval beginTime;
    struct timezone tzone;
    
    strcpy(baseAddress, "255.255.255.255");
    
    printf("ranwalk: Version %s\n", VERSION);
    
    /* Parse options */  
    optind = 1;
    opterr = 0;
    
    while ((op = getopt(argc,  argv,  "n:r:b:l:d:p:v")) != EOF)
    {
	switch(op)
	{
	   case 'b':
	    strcpy(baseAddress, optarg);
	    break;
	    
	   case 'n':
	    numGroups = atoi(optarg);
	    if (numGroups < 1)
	    {
		printf("ranwalk: numGroups must be greater than or equal to one!\n");
		exit(0);
	    }
	    if (numGroups > MAX_GROUPS)
	    {
		printf("ranwalk: numGroups must be 3000 or less!\n");
		exit(0);
	    }
	    break;
	    
	   case 'r':
	    if (1 != sscanf(optarg, "%f", &joinRate))
	    {
		printf("ranwalk: Invalid join rate!\n");
		exit(0);
	    }
	    break;
	   
	   case 'l':
	    lingerTime = atoi(optarg);
	    if (lingerTime < 0)
	    {
		printf("ranwalk: Invalid lingerTime!\n");
		exit(0);
	    }
	    break;
	    
	   case 'd':
	    duration = atoi(optarg);  /* default is forever */
	    if (duration < 0)
	    {
		printf("ranwalk: Invalid duration!\n");
		exit(0);
	    }
	    break;
	    
	   case 'p':
	    port = atoi(optarg);
	    if (atoi(optarg) < 0)
	    {
		printf("ranwalk: Invalid port!\n");
		exit(0);
	    }
	    break;
	   
	   case 'v':
	    exit(0);
	    break;
		
	   default:
	    printf("ranwalk: Invalid command line option!\n");
	    exit(0);
	    break;
       }
   }
   
   
    nonopt_argc = argc - optind;
    
    if (nonopt_argc != 1)
    {
       printf("Usage: ranwalk [-b baseAddress] [-n numGroups] [-l lingerTime] [-d duration] outFile\n");
       exit(0);
    }
    
    /* Test for unicast vs. multicast */
    if ( (base = inet_addr(baseAddress)) == INADDR_NONE) 
    {						
	printf("ranwalk: Invalid baseAddress!\n");
	exit(0);
    } 
    if ((base & htonl(0xf0000000)) != htonl(0xe0000000))
    {
	printf("ranwalk: baseAddress not multicast!\n");
	exit(0);
    }
    
    if ( ( outFile = fopen(argv[optind], "w+") ) == NULL)
    {
	perror("ranwalk: Error opening output scriptFile\n");
	exit(0);
    }
    
    printf("ranwalk: Opened output script file: %s ...\n",  fileName);
    
    fprintf(outFile, "# Drec script created by ranwalk.\n");
    fprintf(outFile, "# (baseAddress = %s numGroups = %d\n\n", baseAddress, numGroups);
    fprintf(outFile, "PORT %hu\n",  port);
   
   /* Convert duration from sec to msec */
   duration = 1000 * duration;
   lingerTime = 1000 * lingerTime;
   joinPeriod = 1000.0 * (1.0/joinRate);

/* Seed rand generator with time of day */   
    printf("ranwalk: Seeding random number generator ...\n"); 
    gettimeofday(&beginTime, &tzone);   
    setall(beginTime.tv_sec, beginTime.tv_usec);
   
   for(i=0; i < numGroups; i++) GroupInUse[i] = 0;
   
   currentTime = 0;
   currentGroup = 0;
   while(currentTime < duration)
   {
       tmp = GetNextGroup(currentGroup, numGroups);
       if (tmp >= 0)
       {
	   currentGroup = tmp;
	   /* Write JOIN event */
	   theAddress.s_addr = htonl(base + currentGroup);
	   strcpy(dottedAddress,  (char *) inet_ntoa(theAddress)); 	
	   fprintf(outFile, "%07lu JOIN  %15s\n", currentTime, dottedAddress);
	   
	   /* Calculate LEAVE time */
	   LeaveTime[currentGroup] = (unsigned long) genexp((double)lingerTime) +
				     currentTime;
	   GroupInUse[currentGroup] = TRUE;
       }
       
       currentTime += (unsigned long) genexp(joinPeriod);
       
       /* Write pending group leaves */
       for (i=0; i < numGroups; i++)
       {
	   if (GroupInUse[i])
	   {
	       if (LeaveTime[i] < currentTime)
	       {
		   /* Write LEAVE event */
		   theAddress.s_addr = htonl(base + i);
		   strcpy(dottedAddress,  (char *) inet_ntoa(theAddress)); 	
		   fprintf(outFile, "%07lu LEAVE %15s\n", LeaveTime[i], dottedAddress);
		   GroupInUse[i] = FALSE;
	       }
	   }
       }
   }
   
   /* Flush remaining groups in use with LEAVES */
   for (i=0; i < numGroups; i++)
   {
       if (GroupInUse[i])
       {
	  /* Write LEAVE event */
	   theAddress.s_addr = htonl(base + i);
	   strcpy(dottedAddress,  (char *) inet_ntoa(theAddress)); 	
	   fprintf(outFile, "%07lu LEAVE %15s\n", LeaveTime[i], dottedAddress);
	   GroupInUse[i] = FALSE;
       }
   }
   
   fclose(outFile);
   printf("ranwalk: Done.\n");
   exit(0);
}  /* end main() */
   
static int GetNextGroup(int current, int num)
{
    int tmp;
    
    if (GroupInUse[current])
    {
	tmp = current;
	if (++current > (num-1)) current = 0;
	while(current != tmp)
	{
	    if (!GroupInUse[current])
		return current;
	    else
		if (++current > (num-1)) current = 0;
	}
	return -1;  /* All groups in use */
    }
    else
    {
	return current;
    }
}
