#ifdef _GUI 

// Test comment
#include <Xm/XmAll.h>
#include <X11/xpm.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netdb.h>

#ifdef _LINUX
#include <math.h>  /* for RSVP defs for Linux */
#endif //

#include "mgen.h"
#include "sysdefs.h"
#include "version.h"

#ifndef INADDR_NONE
#define INADDR_NONE 0xffffffff
#endif // 

#include "icons/nrl.xpm"
#include "icons/mgenIcon1.xpm"
#include "icons/mgenIcon2.xpm"
#include "icons/go.xpm"
#include "icons/stop.xpm"
#include "icons/m_bang1.xpm"
#include "icons/m_bang2.xpm"
#include "icons/m_bang3.xpm"
#include "icons/m_bang4.xpm"
#include "icons/m_bang5.xpm"

/* Private constants */
#define NUM_BANGS 5
#define BANG_INTERVAL 125    /* 125 msec = 8 frames/sec */
static const int BUFFER_SIZE = 1440;

#define NUM_SCRIPT_PARAMS    5
#define NUM_ITERATED_PARAMS    11

/* Private globals */
#ifndef TRUE
static const int TRUE = 1;
static const int FALSE = 0;
#endif //
static int UseAnimation = TRUE;

static char *outputBuffer;
static int outIndex = 0;

static char cmdPath[256];
static int mgenID = 0;
static int liveChild = FALSE;
static int readPipeFd;
static int killPipe = FALSE;

/* GUI globals */
static XtAppContext appContext;
static Widget topLevel;
static XtInputId mgenInputID = 0;
static XmFontList fontlist;
static XFontStruct *font;
static GC gc;
static char *Fallbacks[] = 
{
    "*.background:			gray",
    "*.XmToggleButton.selectColor:	green",
    "*.XmRadioButton.selectColor:	green", 
    NULL
};
static Pixmap nrlMap, goMap, stopMap, mgenMap1, mgenMap2;
static Widget startButton, stopButton, quitButton;
static Widget paramFrame[2], paramPanel[2];
static Widget LastAddressText;
static Widget outText;

static Widget script_paramWidget[NUM_SCRIPT_PARAMS];
static char *script_paramLabel[NUM_SCRIPT_PARAMS] = 
{
    "scriptFile:", 
    "ttl:", 
    "srcPort:", 
    "interface:", 
    "startTime:"
};
static char script_paramValue[NUM_SCRIPT_PARAMS][256];
static char *script_arg[NUM_SCRIPT_PARAMS] = 
{ 
    "XX", 
    "-t", 
    "-p", 
    "-i", 
    "-S", 
};

static Widget fixed_paramWidget[NUM_ITERATED_PARAMS];
static char *fixed_paramLabel[NUM_ITERATED_PARAMS] = 
{
    "baseAddress:", 
    "destPort:", 
    "numGroups:", 
    "ttl:", 
    "srcPort:", 
    "interface:", 
    "pattern:", 
    "rate (pkt/sec):", 
    "size (bytes):", 
    "startTime:", 
    "duration (sec):"
};
static char *fixed_arg[NUM_ITERATED_PARAMS] = 
{
    "-b", 
    "XX", 
    "-n", 
    "-t", 
    "-p", 
    "-i", 
    "-P", 
    "-r", 
    "-s", 
    "-S", 
    "-d"
};
static char fixed_paramValue[NUM_ITERATED_PARAMS][32];

/* "bang" animation variables */
static Widget bangLabel;
static Pixmap bangMaps[NUM_BANGS];
static int bangWidth, bangHeight;
static Pixmap theBangMap;
static XtIntervalId bangTimerID = 0;
static int bangCount = 0;
static int bangInc = 1;

/* Private prototypes */
static int setup_gui(int *argc,  char *argv[]);
static int LoadMgenIcon(char **theIcon, Pixmap *theMap, Widget widget, 
			int *width, int *height);
static void Do_Start();
static void Do_Stop();
static void child_died();
static void Do_Mode_Change(Widget widget, int which, XmToggleButtonCallbackStruct *state);
static void Do_Param(Widget w, XtPointer client_data, XmAnyCallbackStruct *cbs);
static void Do_Pattern_Menu(Widget w, XtPointer client_data, XmAnyCallbackStruct *cbs);
static int CheckParam(int param, char *theText);
static int UpdateParams();
static void Do_Specify_Script(Widget widget, XtPointer client_data, XtPointer call_data);
static void Script_Callback(Widget dialog, XtPointer client_data, 
			    XmFileSelectionBoxCallbackStruct *cbs);
static int ScanScript(char *file);
static void Do_Quit();
static void readPipe(XtPointer client, int *fd, XtInputId *Id);
static void Bang_Timer(XtPointer client_data,  XtIntervalId *Id);
static void redrawBangLabel();
static void Alert(char *text);
static void UpdateLastAddress();

void startGUI(int *argc,  char *argv[], int animate)
{
    UseAnimation = animate;
   
    /* Allocate and init text output buffer */
    outputBuffer = (char *) calloc(BUFFER_SIZE, sizeof(char));
    if (!outputBuffer)
    {
	perror("MGEN: Error allocating memory for GUI output text");
	exit(0);
    }
   
    /* Set launch command path */
    strcpy(cmdPath, argv[0]);
   
    /* Build graphical interface window and display */
    if(!setup_gui(argc, argv))
    {
	printf("MGEN: Error setting up graphical user interface!\n");
	free(outputBuffer);
	exit(0);
    }
      
   /* Loop, checking for X-Windows events */
   XtAppMainLoop(appContext);
   exit(0);
}  /* end startGUI() */

/* MGEN SCRIPTED parameters */
#define SCRIPT_FILE     0
#define SCRIPT_TTL	1  /* Where does traffic go */

#define SCRIPT_SRC_PORT	2  /* Where does it come from */
#define SCRIPT_IFACE	3

#define SCRIPT_START	4  /* When does it start */

/* MGEN ITERATED parameters */
#define BASE_ADDRESS	 0
#define DEST_PORT	 1  /* Where does traffic go */
#define NUM_GROUPS	 2
#define TTL		 3

#define SRC_PORT	 4  /* Where does it come from */
#define INTERFACE	 5

#define PATTERN          6 
#define RATE		 7  /* What does it look like */
#define SIZE		 8

#define START_TIME	 9  /* When does it start (and end) */
#define DURATION	10

static int setup_gui(int *argc,  char *argv[])
{
    int i, width, height;
    char temp_text[64], hostName[64];
    Widget mainWindow, mainPanel, topFrame;
    Widget tempForm, tempLabel, tempWidget;
    Widget nrlLabel, inputPanel, modeFrame, outFrame;
    Widget paramLabel, otherParams;
    XmString str, str2, str3;
    char **IconList[NUM_BANGS] = 
    {
	m_bang1, m_bang2, m_bang3, m_bang4, m_bang5
    };
    
    /* Init paramValues */
    
    /* Script mode parameters */
    strcpy(script_paramValue[SCRIPT_FILE], ScriptFile);
    sprintf(script_paramValue[SCRIPT_TTL], "%d", (int) ttl);
    sprintf(script_paramValue[SCRIPT_SRC_PORT], "%hu", srcPort);
    strcpy(script_paramValue[SCRIPT_IFACE], DEFAULT_INTERFACE);
    strcpy(script_paramValue[SCRIPT_START], "NOW");
    
    /* Fixed mode parameters */
    strcpy(fixed_paramValue[BASE_ADDRESS], inet_ntoa(baseAddress));
    sprintf(fixed_paramValue[NUM_GROUPS], "%d", numGroups);
    sprintf(fixed_paramValue[DEST_PORT], "%d", destPort);
    sprintf(fixed_paramValue[TTL], "%d", (int) ttl);
    sprintf(fixed_paramValue[SRC_PORT], "%hu", srcPort);   
    strcpy(fixed_paramValue[INTERFACE], DEFAULT_INTERFACE);
    strcpy(fixed_paramValue[PATTERN], "XXXX");    
    sprintf(fixed_paramValue[RATE], "%f", pktRate); 
    sprintf(fixed_paramValue[SIZE], "%d", pktSize);
    strcpy(fixed_paramValue[START_TIME], "NOW");
    sprintf(fixed_paramValue[DURATION], "%d", Duration);
    
    
    /* Create Xt application instance */
    topLevel = XtVaAppInitialize(&appContext,  "mgen", NULL, 0, 
				   argc, argv, Fallbacks, NULL);
    
    /* Set app name for window manager */			   
    strcpy(temp_text, "mgen-");
    gethostname(hostName, 32);
    strcat(temp_text, hostName);
    XtVaSetValues(topLevel, 
		    XmNtitle, temp_text, 
		    XmNiconName, temp_text, 
		    XmNallowShellResize, TRUE,
		    NULL);
    
    /* Load fonts */
    font = XLoadQueryFont(XtDisplay(topLevel), "-*-courier-bold-r-*--10-*");
    if (font == NULL) printf("MGEN: font 1 does not exist");
    fontlist = XmFontListCreate(font, "charset1");
    
    /* Create a MainWindow for application */    
    mainWindow = XtVaCreateManagedWidget("mainWindow", 
		    xmMainWindowWidgetClass, topLevel,
		    NULL);
		    
    /* Create main form widget for user interface layout */	
    mainPanel = XtVaCreateManagedWidget("mainPanel", xmFormWidgetClass, 
		    mainWindow,
		    NULL);
		    
    /* Load our icons */
    if(!LoadMgenIcon(nrl, &nrlMap, topLevel, &width, &height))
    {
	fprintf(stderr, "MGEN: Error loading GO icon\n");
	XtDestroyWidget(topLevel);
	return FALSE;
    }
    if(!LoadMgenIcon(mgenIcon1, &mgenMap1, topLevel, &width, &height))
    {
	fprintf(stderr, "MGEN: Error loading GO icon\n");
	XtDestroyWidget(topLevel);
	return FALSE;
    }
    if(!LoadMgenIcon(mgenIcon2, &mgenMap2, topLevel, &width, &height))
    {
	fprintf(stderr, "MGEN: Error loading GO icon\n");
	XtDestroyWidget(topLevel);
	return FALSE;
    }
    if(!LoadMgenIcon(go, &goMap, topLevel, &width, &height))
    {
	fprintf(stderr, "MGEN: Error loading GO icon\n");
	XtDestroyWidget(topLevel);
	return FALSE;
    }
    if(!LoadMgenIcon(stop, &stopMap, topLevel, &width, &height))
    {
	fprintf(stderr, "MGEN: Error loading GO icon\n");
	XtDestroyWidget(topLevel);
	return FALSE;
    }
    /* Load "bang" animation pixmaps */
    for(i=0; i < NUM_BANGS; i++)
    {
	if(!LoadMgenIcon(IconList[i], &bangMaps[i], topLevel, &bangWidth, &bangHeight))
	{
	    fprintf(stderr, "MGEN: Error loading GO icon\n");
	    XtDestroyWidget(topLevel);
	    return FALSE;
	}
    }
    
    /* Use mgenIcon1 pixmap for defaut application icon */		   
    XtVaSetValues(topLevel, XmNiconPixmap, mgenMap1, NULL);
    
    /* Now build the user interface */
    
    /* Create frame -  the top portion of the screen including the NRL logo,
     *                  NRL Multicast Traffic Generator label, bangLabel drawing
     *		        area, startButton, and stopButton
     */
    topFrame = XtVaCreateManagedWidget("controlFrame", 
		    xmFrameWidgetClass, mainPanel,
		    XmNleftAttachment, XmATTACH_FORM,
		    XmNleftOffset,       5,  
		    XmNtopAttachment,  XmATTACH_FORM, 
		    XmNtopOffset,	10, 
		    XmNrightAttachment, XmATTACH_FORM, 
		    XmNrightOffset,      5, 
		    NULL);
    
    /* Create tempForm - the form widget which manages the objects inside 
     *                   frame widget (managed objects include: NRL logo,
     *	         	 NRL Multicast Traffic Generator label, bangLabel 
     *			 drawing area, startButton, and stopButton)
     */
    tempForm = XtVaCreateManagedWidget("form", 
		    xmFormWidgetClass, topFrame, 
		    NULL);
	
    nrlLabel = XtVaCreateManagedWidget("logo", 
			  xmLabelWidgetClass, tempForm, 
			  XmNlabelType,	      XmPIXMAP, 
			  XmNlabelPixmap,     nrlMap,
			  XmNleftAttachment,  XmATTACH_FORM, 
			  XmNtopAttachment,   XmATTACH_FORM,
			  NULL);	

    strcpy(temp_text, "NRL Multi-Generator\n Version ");
    strcat(temp_text, VERSION);
    str = XmStringCreateLtoR(temp_text, XmSTRING_DEFAULT_CHARSET);
    tempLabel = XtVaCreateManagedWidget("label", 
			  xmLabelWidgetClass,	tempForm, 
			  XmNlabelString,	str,
			  XmNleftAttachment,	XmATTACH_WIDGET,
			  XmNleftWidget,	nrlLabel, 
			  XmNleftOffset,	5, 
			  XmNtopAttachment,	XmATTACH_FORM,
			  NULL);
    XmStringFree(str);
    
    bangLabel = (Widget) XtVaCreateManagedWidget("bang",
			xmDrawingAreaWidgetClass,   tempForm,
			/* XmNbackground,		    bg, */
			XmNleftAttachment,	    XmATTACH_WIDGET,
			XmNleftWidget,		    tempLabel, 
			XmNleftOffset,		    -5, 
			XmNtopAttachment,	    XmATTACH_FORM,
			XmNtopOffset,		    10, 
			XmNwidth,		    bangWidth, 
			XmNheight,		    bangHeight, 
			NULL);
    
    theBangMap = mgenMap1;    
    gc = XCreateGC(XtDisplay(topLevel), 
		    RootWindowOfScreen(XtScreen(topLevel)), 
		    (unsigned long) NULL,  
		    NULL);
    XtAddCallback(bangLabel, XmNexposeCallback, 
	    (XtCallbackProc) redrawBangLabel, (XtPointer) gc);
	    
    str = XmStringCreateSimple("Start");    			  
    startButton = (Widget) XtVaCreateManagedWidget("Start",
			xmDrawnButtonWidgetClass,   tempForm,
			XmNlabelType,		    XmPIXMAP,
			XmNlabelPixmap,		    goMap,
			XmNlabelInsensitivePixmap,  goMap,
			XmNrightAttachment,	    XmATTACH_FORM,
			XmNtopAttachment,	    XmATTACH_FORM,
			XmNtopOffset,		    10, 
			XmNrightOffset,		    10,
			XmNpushButtonEnabled,	    TRUE, 
			NULL);	
    XmStringFree(str);
    XtAddCallback(startButton, XmNactivateCallback, (XtCallbackProc)Do_Start, NULL);		
    
    
    str = XmStringCreateSimple("Stop ");    			  
    stopButton = (Widget) XtVaCreateManagedWidget("Stop",
			xmDrawnButtonWidgetClass,   tempForm,
			XmNlabelType,		    XmPIXMAP,
			XmNlabelPixmap,		    stopMap,
			XmNlabelInsensitivePixmap,  stopMap,
			XmNrightAttachment,	    XmATTACH_FORM,
			XmNtopAttachment,	    XmATTACH_WIDGET,
			XmNtopWidget,		    startButton, 
			XmNtopOffset,		    10, 
			XmNrightOffset,		    10, 
			XmNsensitive,		    FALSE, 
			NULL);	
    XmStringFree(str);
    XtAddCallback(stopButton, XmNactivateCallback, (XtCallbackProc)Do_Stop, NULL);		
    
    /* Input Panel */
    inputPanel = XtVaCreateWidget("inputPanel", 
		    xmFormWidgetClass,	mainPanel, 
		    XmNtopAttachment,   XmATTACH_WIDGET,
		    XmNtopOffset,	10,
		    XmNtopAttachment,   XmATTACH_WIDGET,
		    XmNtopWidget,       topFrame, 
		    NULL);    

    tempLabel = XtVaCreateManagedWidget("Input Mode", 
		    xmLabelGadgetClass,  inputPanel, 
		    XmNleftAttachment,   XmATTACH_FORM,
		    XmNtopAttachment,    XmATTACH_FORM,
		    NULL);
    
    modeFrame = XtVaCreateManagedWidget("modeFrame", 
		    xmFrameWidgetClass,	inputPanel,
		    XmNleftAttachment,	XmATTACH_FORM,
		    XmNleftOffset,	5,  
		    XmNrightAttachment, XmATTACH_FORM,
		    XmNrightOffset,	5,  
		    XmNtopAttachment,	XmATTACH_WIDGET, 
		    XmNtopWidget,	tempLabel, 
		    XmNtopOffset,	5, 
		    XmNshadowType,	XmSHADOW_IN,  
		    NULL);

    str = XmStringCreateSimple("Script File");
    str2 = XmStringCreateSimple("Fixed Parameters");
    
    tempWidget = XmVaCreateSimpleRadioBox(modeFrame, "modeRadioBox", 
		      SCRIPTED,		(XtCallbackProc) Do_Mode_Change, 
		      XmVaRADIOBUTTON,  str, NULL, NULL, NULL,
		      XmVaRADIOBUTTON,  str2, NULL, NULL, NULL,
		      NULL);
    
    XtManageChild(tempWidget);

    XmStringFree(str);
    XmStringFree(str2);
    
    
    paramLabel = XtVaCreateManagedWidget("Test Parameters", 
		    xmLabelGadgetClass,	    inputPanel, 
		    XmNleftAttachment,	    XmATTACH_FORM,
		    XmNtopAttachment,	    XmATTACH_WIDGET, 
		    XmNtopWidget,	    modeFrame, 
		    XmNtopOffset,	    20,
		    NULL);
    
    /*****************************************************************
     *  Creates paramFrame[SCRIPTED] - the frame which holds the paramPanel 
     *	for the Script Mode row-column widget 
     */    
     
    paramFrame[SCRIPTED] = XtVaCreateWidget("sessionFrame[SCRIPTED]", 
		    xmFrameWidgetClass,	    inputPanel,
		    XmNleftAttachment,	    XmATTACH_FORM,
		    XmNleftOffset,	    5,  
		    XmNtopAttachment,	    XmATTACH_WIDGET, 
		    XmNtopWidget,	    paramLabel, 
		    XmNtopOffset,	    5, 
		    XmNbottomAttachment,    XmATTACH_FORM, 
		    XmNshadowType,	    XmSHADOW_IN,  
		    XmNmappedWhenManaged,   TRUE,
		    NULL);
    
    paramPanel[SCRIPTED] = XtVaCreateWidget("paramPanel[SCRIPTED]",
                    xmFormWidgetClass, paramFrame[SCRIPTED], 
		    NULL);    

    tempLabel = XtVaCreateManagedWidget("Script File:", 
		    xmLabelGadgetClass,	    paramPanel[SCRIPTED], 
		    XmNleftAttachment,	    XmATTACH_FORM,
		    XmNtopAttachment,	    XmATTACH_FORM, 
		    NULL);
    
    str = XmStringCreateSimple("Select");
    tempWidget = (Widget) XtVaCreateManagedWidget("Select",
			xmPushButtonWidgetClass,    paramPanel[SCRIPTED],
			XmNlabelString,		    str,
			XmNrightAttachment,	    XmATTACH_FORM, 
			XmNtopAttachment,	    XmATTACH_WIDGET, 
			XmNtopWidget,		    tempLabel,
			XmNrightOffset,		    2,
			NULL);	
    XmStringFree(str);    
    XtAddCallback(tempWidget, XmNactivateCallback, 
		  (XtCallbackProc) Do_Specify_Script, NULL);
		  
    script_paramWidget[SCRIPT_FILE] = XtVaCreateManagedWidget("scriptText", 
		    xmTextFieldWidgetClass, paramPanel[SCRIPTED], 
		    XmNtraversalOn,	    TRUE, 
		    XmNleftAttachment,	    XmATTACH_FORM, 
		    XmNrightAttachment,     XmATTACH_WIDGET, 
		    XmNrightWidget,	    tempWidget, 
		    XmNbottomAttachment,    XmATTACH_OPPOSITE_WIDGET,
		    XmNbottomWidget,	    tempWidget, 
		    XmNfontList,	    fontlist, 
		    XmNvalue,		    ScriptFile, 
		    NULL);
    
    XtAddCallback(script_paramWidget[SCRIPT_FILE], XmNactivateCallback, 
		  (XtCallbackProc) Do_Param,  
		  (XtPointer) NULL);
		    	    	    
    XtAddCallback(script_paramWidget[SCRIPT_FILE], XmNactivateCallback, 
		  (XtCallbackProc) XmProcessTraversal,  
		  (XtPointer) XmTRAVERSE_NEXT_TAB_GROUP);

    
    
    tempLabel = XtVaCreateManagedWidget("Other Parameters:", 
		    xmLabelGadgetClass,	    paramPanel[SCRIPTED], 
		    XmNleftAttachment,	    XmATTACH_FORM,
		    XmNtopAttachment,	    XmATTACH_WIDGET,
		    XmNtopWidget,	    script_paramWidget[SCRIPT_FILE],
		    XmNtopOffset,	    10,
		    NULL);

    otherParams = XtVaCreateWidget("otherParamsRowCol", 
		    xmRowColumnWidgetClass, paramPanel[SCRIPTED], 
		    XmNtopAttachment,	    XmATTACH_WIDGET,
		    XmNtopWidget,	    tempLabel,
		    XmNtopOffset,	    5,
		    XmNrightAttachment,	    XmATTACH_FORM,
		    XmNleftAttachment,	    XmATTACH_FORM,
		    NULL);
    
    for (i=1; i<NUM_SCRIPT_PARAMS; i++)
    {
	tempWidget = XtVaCreateWidget("form", 
		    xmFormWidgetClass,	otherParams, 
		    NULL);
				  
	script_paramWidget[i] = XtVaCreateManagedWidget("paramText", 
		    xmTextFieldWidgetClass, tempWidget, 
		    XmNtraversalOn,	    TRUE, 
		    XmNmaxLength,	    16, 
		    XmNrightAttachment,	    XmATTACH_FORM, 
		    XmNfontList,	    fontlist, 
		    XmNvalue,		    script_paramValue[i], 
		    NULL);
	
	tempLabel = XtVaCreateManagedWidget(script_paramLabel[i], 
		    xmLabelGadgetClass,	    tempWidget, 
		    XmNrightAttachment,	    XmATTACH_WIDGET,
		    XmNrightWidget,	    script_paramWidget[i], 
		    NULL);
		    
	XtAddCallback(script_paramWidget[i], XmNactivateCallback, 
		    (XtCallbackProc) Do_Param,  
		    (XtPointer) i);
		    	    	    
	XtAddCallback(script_paramWidget[i], XmNactivateCallback, 
		    (XtCallbackProc) XmProcessTraversal,  
		    (XtPointer) XmTRAVERSE_NEXT_TAB_GROUP);
		    
	XtManageChild(tempWidget);	    
    }			   
    XtManageChild(otherParams);
    XtManageChild(paramPanel[SCRIPTED]);
    
    
    /*****************************************************************
     *  Creates paramFrame[ITERATED] - the frame which holds the paramPanel 
     *	for the Fixed Mode row-column widget 
     */    					 
    paramFrame[ITERATED] = XtVaCreateWidget("sessionFrame[ITERATED]", 
		    xmFrameWidgetClass,	    inputPanel,
		    XmNleftAttachment,	    XmATTACH_FORM,
		    XmNleftOffset,	    5,  
		    XmNtopAttachment,	    XmATTACH_WIDGET, 
		    XmNtopWidget,	    paramLabel, 
		    XmNtopOffset,	    5, 
		   
		    XmNshadowType,	    XmSHADOW_IN,  
		    XmNmappedWhenManaged,   TRUE,
		    NULL);
    
    paramPanel[ITERATED] = XtVaCreateWidget("paramPanel[ITERATED]",
                    xmRowColumnWidgetClass, paramFrame[ITERATED], 
		    NULL); 				 
    
    for (i=0; i<NUM_ITERATED_PARAMS; i++)
    {
	tempWidget = XtVaCreateManagedWidget("form", 
			    xmFormWidgetClass,	paramPanel[ITERATED], 
			    NULL);
					  
	switch(i)
	{
	    case PATTERN:
		str = XmStringCreateLtoR("pattern:", "charset1");
		str2 = XmStringCreateLtoR("PERIODIC", "charset1");
		str3 = XmStringCreateLtoR("POISSON", "charset1");
		fixed_paramWidget[i] = XmVaCreateSimpleOptionMenu(tempWidget, 
					"option_menu", 
					str, 'P', pktPattern, (XtCallbackProc) Do_Pattern_Menu,
					XmVaPUSHBUTTON, str2, 'E', NULL, NULL, 
					XmVaPUSHBUTTON, str3, 'O', NULL, NULL, 
					NULL);
		XmStringFree(str);
		XmStringFree(str2);
		XmStringFree(str3);
		XtVaSetValues(fixed_paramWidget[i], 
				XmNrightAttachment, XmATTACH_FORM,
				XmNtraversalOn,	    TRUE, 
				NULL);
		XtManageChild(fixed_paramWidget[i]);
		break;
	
	    default:
		fixed_paramWidget[i] = XtVaCreateManagedWidget("paramText", 
			    xmTextFieldWidgetClass, tempWidget, 
			    XmNtraversalOn,	    TRUE, 
			    XmNmaxLength,	    16, 
			    XmNrightAttachment,	    XmATTACH_FORM, 
			    XmNfontList,	    fontlist, 
			    XmNvalue,		    fixed_paramValue[i], 
			    NULL);
		
		tempLabel = XtVaCreateManagedWidget(fixed_paramLabel[i], 
			    xmLabelGadgetClass,	    tempWidget, 
			    XmNrightAttachment,	    XmATTACH_WIDGET,
			    XmNrightWidget,	    fixed_paramWidget[i], 
			    NULL);
			    
		XtAddCallback(fixed_paramWidget[i], XmNactivateCallback, 
			    (XtCallbackProc) Do_Param,  
			    (XtPointer) i);
					    
		XtAddCallback(fixed_paramWidget[i], XmNactivateCallback, 
			    (XtCallbackProc) XmProcessTraversal,  
			    (XtPointer) XmTRAVERSE_NEXT_TAB_GROUP);
		break;
	}
	if (NUM_GROUPS == i)  /* Add LastAddressText widget */
	{
	    tempWidget = XtVaCreateManagedWidget("form", 
			    xmFormWidgetClass,	paramPanel[ITERATED], 
			    NULL);
			    
	    str = XmStringCreateLtoR("(lastAddress: )", "charset1");
	    LastAddressText = 
		XtVaCreateManagedWidget("lastAddress", 
			  xmLabelWidgetClass,	tempWidget, 
			  XmNlabelString,	str,
			  XmNfontList,		fontlist, 
			  XmNrightAttachment,	XmATTACH_FORM, 
			  NULL);
	    XmStringFree(str);
	}
    }		    
    XtManageChild(paramPanel[ITERATED]);
    
    
    /* Turn on appropriate input mode display & display input panel */   
    XtManageChild(paramFrame[Mode]);
    XtManageChild(inputPanel);
    
    /*************************************************************************
     * Create outFrame - The frame which contains the outText text widget 
     *                    which is responsible for communicating with the
     *			  child process.
     */
    
    tempLabel = XtVaCreateManagedWidget("MGEN Output", 
		    xmLabelGadgetClass,	mainPanel, 
		    XmNleftAttachment,	XmATTACH_WIDGET,
		    XmNleftWidget,	inputPanel, 
		    XmNleftOffset,	5, 
		    XmNtopAttachment,	XmATTACH_WIDGET, 
		    XmNtopWidget,	topFrame, 
		    XmNtopOffset,	10, 
		    NULL);
    
    
    outFrame = XtVaCreateManagedWidget("outFrame", 
		    xmFrameWidgetClass,	mainPanel,
		    XmNrightAttachment, XmATTACH_FORM,
		    XmNrightOffset,	5, 
		    XmNleftAttachment,	XmATTACH_WIDGET, 
		    XmNleftWidget,	paramFrame[ITERATED], 
		    XmNleftOffset,	5, 
		    XmNtopAttachment,	XmATTACH_WIDGET, 
		    XmNtopWidget,	tempLabel, 
		    XmNbottomAttachment,  XmATTACH_OPPOSITE_WIDGET, 
		    XmNbottomWidget,	paramFrame[ITERATED],
		    XmNshadowType,	XmSHADOW_IN, 
		    NULL);
		    
    outText = XtVaCreateManagedWidget("outText",  
		    xmTextWidgetClass, outFrame, 
		    XmNfontList, fontlist,
		    XmNeditable, FALSE, 
		    XmNcolumns, 48, 
		    NULL);
    XmTextSetString(outText, " ");
    
    /* Create QUIT button */
    str = XmStringCreateSimple("Quit");
    quitButton = (Widget) XtVaCreateManagedWidget("Quit",
			xmPushButtonWidgetClass, mainPanel,
			XmNlabelString,		str,
			XmNrightAttachment,	XmATTACH_FORM, 
			/* XmNbottomAttachment,	XmATTACH_FORM, */
			XmNrightOffset,		10,
			XmNbottomOffset,	10,   
			XmNtopAttachment,	XmATTACH_WIDGET, 
			XmNtopWidget,		paramFrame[ITERATED], 
			XmNtopOffset,		10, 
			NULL);	
    XmStringFree(str);    
    XtAddCallback(quitButton, XmNactivateCallback, (XtCallbackProc)Do_Quit, NULL);		

    UpdateLastAddress();
    XtRealizeWidget(topLevel);    
    return TRUE;
    
}  /* end setup_gui() */

static void Do_Start()
{
    char cmd[8];
    char *mgenArgs[2*NUM_ITERATED_PARAMS + 2];
    char **argPtr = mgenArgs;
    char addrPortString[32];
    int i, writePipeFd;
    
    int pipe_fd[2];
    
    /* Get latest param values and check */
    if (!UpdateParams()) return;
  
    /* Build exec command string using argument values */
    strcpy(cmd, "mgen");
    *argPtr++ = cmd;
    *argPtr++ = "-G";
    switch(Mode)
    {
	case SCRIPTED:
	/* mgen -t ttl -p srcPort -i interface -S startTime scriptFile */
	    for(i = 1; i < NUM_SCRIPT_PARAMS; i++)
	    {
		*argPtr++ = script_arg[i];
		*argPtr++ = script_paramValue[i];
	    }
	    *argPtr++ = script_paramValue[SCRIPT_FILE];  /* param zero */
	    *argPtr = NULL;	    
	    break;
	    
	case ITERATED:
	/* mgen -b baseAddress:port -n numGroups -t ttl -p srcPort
	 *      -i interface -P -r pktRate -s pktSize -d Duration
	 */
	    *argPtr++ = fixed_arg[BASE_ADDRESS];
	    sprintf(addrPortString, "%s:%hu", inet_ntoa(baseAddress), destPort);
	    *argPtr++ = addrPortString;
	    for(i=2; i< NUM_ITERATED_PARAMS; i++)
	    {
		if (i != PATTERN)
		{
		    *argPtr++ = fixed_arg[i];
		    *argPtr++ = fixed_paramValue[i];
		}
		else
		{
		    if (POISSON == pktPattern)
			*argPtr++ = fixed_arg[i];
		}
	    }
	    *argPtr = NULL;
	    break;
    }
    
    /* Uncomment to print resulting cmd syntax 
    argPtr = mgenArgs;
    printf("Cmd: ");
    while(*argPtr) printf("%s ", *argPtr++);
    printf("\n"); */
    
     /* Create pipe to get output from MGEN child */
    if(pipe(pipe_fd) < 0)
    {
	perror("MGEN: pipe() error");
	Alert("MGEN: pipe() error!");
	return;
    }
    readPipeFd = pipe_fd[0];
    writePipeFd = pipe_fd[1];
    
    switch(mgenID = fork())
    {
	case -1:
	    perror("MGEN: fork() error");
	    Alert("MGEN: fork() error!");
	    return;
	    break;
	    
	case 0:		/* child */
	    XtDestroyWidget(topLevel);
	    for (i = 0; i < NSIG; i++) 
		signal(i, SIG_DFL);  /* defeat any existing signal handling */
	    close(readPipeFd);
	    if (writePipeFd != STDOUT_FILENO)
	    {
		if (dup2(writePipeFd, STDOUT_FILENO) != STDOUT_FILENO)
		    perror("MGEN dup2(stdout) error");
		if (dup2(writePipeFd, STDERR_FILENO) != STDERR_FILENO)
		    perror("MGEN dup2(stderr) error");
		close(writePipeFd);   
	    }
	    fflush(stdout);
	    if (execvp(cmdPath, mgenArgs) < 0)
	    {
		perror("MGEN: execv() error"); 
		fflush(stdout);
		exit(-1);
	    }
	    fflush(stdout);
	    exit(0);
	    break;
	    
	default:
	    close(writePipeFd);
	    break;	      
    }
    
    liveChild = TRUE;
    killPipe = FALSE;
    mgenInputID = XtAppAddInput(appContext, readPipeFd, 
		       (XtPointer) XtInputReadMask, 
		       (XtInputCallbackProc) readPipe , 
		       NULL);
    signal(SIGCHLD, child_died);      /* Called when mgen dies */
    
    /* Everything OK, update display */    
    outIndex = 0;
    strcpy(outputBuffer, "MGEN: Starting ...\n");
    XmTextSetString(outText, outputBuffer);
      
    XtVaSetValues(startButton, XmNsensitive, FALSE, 
		    XmNpushButtonEnabled, FALSE, 
		    NULL);
    XtVaSetValues(stopButton, XmNsensitive,  TRUE, 
		    XmNpushButtonEnabled, TRUE, 
		    NULL);   	       
    if (UseAnimation)
    {
	bangCount = 0;
	bangInc = 1;
	theBangMap = bangMaps[bangCount];
	bangTimerID = XtAppAddTimeOut(appContext, BANG_INTERVAL, 
			(XtTimerCallbackProc) Bang_Timer, 
			NULL);
    }
    else
    {
	theBangMap = mgenMap2;
	redrawBangLabel();
    }
    XtVaSetValues(topLevel, XmNiconPixmap, mgenMap2, NULL);
    
}  /* end Do_Start() */

static void Do_Stop()
{
    int status;  
    
    if (liveChild) 
    {
	signal(SIGCHLD, SIG_DFL); 	
	while(kill(mgenID, SIGINT) !=0) 
	    perror("MGEN: kill() error");
	liveChild = FALSE;
    } 
    
    if (mgenID)
    {
	while(waitpid(mgenID, &status, 0) != mgenID) 
	    perror("MGEN: wait() error");
	mgenID = 0;
    }
    
    if (mgenInputID)
    {
	killPipe = TRUE;
	readPipe(NULL, &readPipeFd, NULL);
	close(readPipeFd);
	mgenInputID = 0;
    }  
    
    /* Reset Display */
    if (bangTimerID)
    {
	XtRemoveTimeOut(bangTimerID);
	bangTimerID = 0;	
    }    
    theBangMap = mgenMap1;
    redrawBangLabel();      
    XtVaSetValues(topLevel, XmNiconPixmap, mgenMap1, NULL);
    XtVaSetValues(startButton, XmNsensitive, TRUE, 
		    XmNpushButtonEnabled, TRUE, 
		    NULL);  
    XtVaSetValues(stopButton, XmNsensitive,  FALSE, 
		    XmNpushButtonEnabled, FALSE, 
		    NULL); 
}  /* end Do_Stop() */

static void child_died()
 {
    liveChild = FALSE;
    XtAppAddTimeOut(appContext, 0, (XtTimerCallbackProc) Do_Stop, NULL);
 }  /* end child_died */

#define MAXLINES 128
static void readPipe(XtPointer client, int *fd, XtInputId *Id)
{
    static char buffer[MAXLINES]; 
    struct stat stat_buffer;
    int navail, nread, got;
  
    fstat(*fd, &stat_buffer);    
    navail = stat_buffer.st_size;  
    while(navail)
    {
	if (navail>MAXLINES)
	    nread = MAXLINES;
	else
	    nread = navail;
	got = read(*fd, buffer, nread);
	navail -= got;
	if ( (outIndex+got) > BUFFER_SIZE-1)
	{
	    printf("MGEN: Output text buffer overflow!\n");
	    got = BUFFER_SIZE - outIndex - 1;
	}
	memcpy(&outputBuffer[outIndex], buffer, got);
	outIndex += got;
	outputBuffer[outIndex] = '\0';
	XmTextSetString(outText, outputBuffer);	
    }  
    if (killPipe)
    {
	XtRemoveInput(mgenInputID);
	close(readPipeFd);
	mgenInputID = 0;
    }  
}  /* end readPipe() */



static void Bang_Timer(XtPointer client_data,  XtIntervalId *Id)
{ 
    bangTimerID = XtAppAddTimeOut(appContext, BANG_INTERVAL, 
		    (XtTimerCallbackProc) Bang_Timer, 
		    NULL);
    bangCount += bangInc;
    if ((bangCount == 0) || (bangCount == NUM_BANGS-1)) bangInc *= -1; 
    theBangMap = bangMaps[bangCount]; 
    redrawBangLabel(); 
}  /* end Bang_Timer() */



static void Do_Mode_Change(Widget widget, int which, 
			   XmToggleButtonCallbackStruct *state)
{
    switch (which) 
    {
	case SCRIPTED:        /* Script file selected */
	    if (state->set) {
		Mode = SCRIPTED;
		XtManageChild(paramFrame[SCRIPTED]);
	    }
	    else 
	    {
		XtUnmanageChild(paramFrame[SCRIPTED]);
	    }
	    break;
	case ITERATED:        /* Fixed Input selected */
	    if (state->set) 
	    {
		Mode = ITERATED;
		XtManageChild(paramFrame[ITERATED]);
	    }
	    else 
	    {
		XtUnmanageChild(paramFrame[ITERATED]);
	    }
	    break;
    }
}  /* end Do_Mode_Change() */


static void Do_Pattern_Menu(Widget w, XtPointer client_data, 
		     XmAnyCallbackStruct *cbs)
{
    pktPattern = (MgenPattern) client_data;
}  /* end Do_Pattern_Menu() */

/* Handle Text based parameters */
static void Do_Param(Widget w, XtPointer client_data, 
		     XmAnyCallbackStruct *cbs)
{
    int param = (int) client_data;
    char *textPtr;
    
    XtVaGetValues(w,  XmNvalue, &textPtr,  NULL);
    CheckParam(param, textPtr);
    if (SCRIPT_FILE == param) ScanScript(textPtr);
    
}  /* end Do_Param() */

static void UpdateLastAddress()
{
    char text[32];
    XmString str;
    struct in_addr theAddr;
    
    theAddr.s_addr = htonl(ntohl(baseAddress.s_addr) + numGroups -1);   
    sprintf(text, "(lastAddress: %s)", inet_ntoa(theAddr));
    str = XmStringCreateLtoR(text, "charset1");
    XtVaSetValues(LastAddressText, XmNlabelString, str, NULL);
    XmStringFree(str);
}

static void Do_Specify_Script(Widget widget, XtPointer client_data, XtPointer call_data)
{
  static Widget dialog = NULL;

  if (!dialog) {
    dialog = XmCreateFileSelectionDialog(paramPanel[SCRIPTED], 
                     "Script_Selection", NULL, 0);
    XtAddCallback(dialog, XmNokCallback, (XtCallbackProc) Script_Callback, NULL);
    XtAddCallback(dialog, XmNhelpCallback, (XtCallbackProc) Script_Callback, NULL);
    XtAddCallback(dialog, XmNcancelCallback, (XtCallbackProc) XtUnmanageChild, NULL);
  }
 
  XtManageChild(dialog);
  XtPopup(XtParent(dialog), XtGrabNone);
}  /* end Do_Specify_Script() */

static void Script_Callback(Widget dialog, XtPointer client_data, 
			    XmFileSelectionBoxCallbackStruct *cbs)
{
    char *file = NULL;
    if (cbs) 
    {
	switch(cbs->reason) 
	{
	    case XmCR_OK:
		if (!XmStringGetLtoR(cbs->value, XmSTRING_DEFAULT_CHARSET, &file))
		    return; /* internal error */
		if (CheckParam(SCRIPT_FILE, file))
		    XmTextSetString(script_paramWidget[SCRIPT_FILE], file);
		if (!ScanScript(file)) Alert("Error parsing script!");
		XtUnmanageChild(dialog);
		XtFree(file);
		break;
      
	    case XmCR_HELP:
		Alert("You must choose a script file or run MGEN in fixed mode.  See the README file for more details.");
		break;
	}
    }
}  /* end Script_Callback() */

static int ScanScript(char *file)
{
    if(PreLoadMgenScript(file,  
		  script_paramValue[SCRIPT_SRC_PORT], 
		  script_paramValue[SCRIPT_IFACE], 
		  script_paramValue[SCRIPT_START], 
		  script_paramValue[SCRIPT_TTL]))
    {
	XmTextSetString(script_paramWidget[SCRIPT_SRC_PORT], 
		script_paramValue[SCRIPT_SRC_PORT]);
	XmTextSetString(script_paramWidget[SCRIPT_IFACE], 
		script_paramValue[SCRIPT_IFACE]);
	XmTextSetString(script_paramWidget[SCRIPT_START], 
		script_paramValue[SCRIPT_START]);
	XmTextSetString(script_paramWidget[SCRIPT_TTL], 
		script_paramValue[SCRIPT_TTL]);
	return TRUE;
    }
    else
    {
	Alert("Error parsing script!");
	return FALSE;
    }
}  /* end ScanScript() */

static void Do_Quit()
{
    Do_Stop();  /* Stop any packet generation */    
    XtDestroyWidget(topLevel);  /* shut down display */
    exit(0);          
}  /* end Do_Quit() */



/* MGEN ITERATED parameters */
#define BASE_ADDRESS	 0
#define DEST_PORT	 1  /* Where does traffic go */
#define NUM_GROUPS	 2
#define TTL		 3

#define SRC_PORT	 4  /* Where does it come from */
#define INTERFACE	 5

#define PATTERN          6 
#define RATE		 7  /* What does it look like */
#define SIZE		 8

#define START_TIME	 9  /* When does it start (and end) */
#define DURATION	10


static int UpdateParams()
{
    int i;
    char *textPtr;
    
    switch (Mode)
    {
	case SCRIPTED:
	    for(i=0; i< NUM_SCRIPT_PARAMS; i++)
	    {
		XtVaGetValues(script_paramWidget[i],  
		    XmNvalue, &textPtr,  
		    NULL);
		if (!CheckParam(i, textPtr)) return FALSE;
	    }
	    break;
	    
	case ITERATED:
	     for(i=0; i< NUM_ITERATED_PARAMS; i++)
	    {
		if (PATTERN != i)
		{
		    XtVaGetValues(fixed_paramWidget[i],  
			    XmNvalue, &textPtr,  
			    NULL);
		    if (!CheckParam(i, textPtr)) return FALSE;
		}
	    }
	    break;
    }
    return TRUE;
}  /* end UpdateParams() */

static int CheckParam(int param, char *theText)
{
    extern int errno;
    int tempint;
    float tempfloat;
    struct stat script_file;
    
    switch (Mode)
    {
	case (SCRIPTED):
	    switch(param) 
	    {
		case SCRIPT_FILE:
		    if (stat(theText, &script_file) < 0)
		    {
			Alert("Invalid Scriptfile!");
			return FALSE;
		    }
		    if (!(S_ISREG(script_file.st_mode)))
		    {
			Alert("Invalid Scriptfile!");
			return FALSE;
		    }
		    strcpy(ScriptFile, theText);
		    strcpy(script_paramValue[SCRIPT_FILE], theText);
		    break;
		
		case SCRIPT_TTL:
		    tempint = strtol(theText,(char **)NULL, 10);
		    if ((tempint<0) || (tempint>255))
		    {
			Alert("Invalid ttl value!");
			return FALSE;
		    }
		    ttl = (unsigned char) tempint;
		    sprintf(script_paramValue[SCRIPT_TTL], "%d", ttl);
		    XmTextSetString(script_paramWidget[SCRIPT_TTL], 
				    script_paramValue[SCRIPT_TTL]);
		    break;
		    
		case SCRIPT_SRC_PORT:
		    tempint = strtol(theText,(char **)NULL, 10);
		    if ((tempint<0) || errno)
		    {
			Alert("Invalid port value!");
			return FALSE;
		    }
		    srcPort = (unsigned short) tempint;
		    sprintf(script_paramValue[SCRIPT_SRC_PORT], "%d", srcPort);
		    XmTextSetString(script_paramWidget[SCRIPT_SRC_PORT], 
				    script_paramValue[SCRIPT_SRC_PORT]);
		    break;
		    
		case SCRIPT_IFACE:
		    strcpy(interfaceName, theText);
		    strcpy(script_paramValue[SCRIPT_IFACE], theText);
		    break;
		       
		case SCRIPT_START:
		    strcpy(StartTime, theText);
		    strcpy(script_paramValue[SCRIPT_START], theText);
		    break;
	    
		default:
		    Alert("Unimplemented field!");
		    return FALSE;
		    break;
	    }
	    break;
	
	case (ITERATED):
	    switch(param)
	    {
		case BASE_ADDRESS:
		    baseAddress.s_addr = inet_addr(theText);
		    if (baseAddress.s_addr == INADDR_NONE) 
		    {						
			Alert("Invalid baseAddress!");
			return FALSE;
		    }
		    sprintf(fixed_paramValue[BASE_ADDRESS], "%s", 
			    inet_ntoa(baseAddress));
		    XmTextSetString(fixed_paramWidget[BASE_ADDRESS], 
				    fixed_paramValue[BASE_ADDRESS]);
		    UpdateLastAddress();
		    break;
		
		case NUM_GROUPS:
		    tempint = strtol(theText,(char **)NULL, 10);
		    if (tempint <= 0)
		    {
			Alert("Invalid numGroups!");
			return FALSE;
		    }
		    numGroups = tempint;
		    sprintf(fixed_paramValue[NUM_GROUPS], "%d", numGroups);
		    XmTextSetString(fixed_paramWidget[NUM_GROUPS], 
				    fixed_paramValue[NUM_GROUPS]);
		    UpdateLastAddress();
		    break;
		
		case DEST_PORT:
		    tempint = strtol(theText,(char **)NULL, 10);
		    if ((tempint<=0) || errno)
		    {
			Alert("Invalid port value!");
			return FALSE;
		    }
		    destPort = (unsigned short) tempint;
		    sprintf(fixed_paramValue[DEST_PORT], "%d", destPort);
		    XmTextSetString(fixed_paramWidget[DEST_PORT], 
				    fixed_paramValue[DEST_PORT]);
		    break;
		
		case TTL:
		    tempint = strtol(theText,(char **)NULL, 10);
		    if ((tempint<0) || (tempint>255))
		    {
			Alert("Invalid ttl value!");
			return FALSE;
		    }
		    ttl = (unsigned char) tempint;
		    sprintf(fixed_paramValue[TTL], "%d", ttl);
		    XmTextSetString(fixed_paramWidget[TTL], 
				    fixed_paramValue[TTL]);
		    break;
		
		
		case SRC_PORT:
		    tempint = strtol(theText,(char **)NULL, 10);
		    if ((tempint<0) || errno)
		    {
			Alert("Invalid port value!");
			return FALSE;
		    }
		    srcPort = (unsigned short) tempint;
		    sprintf(fixed_paramValue[SRC_PORT], "%d", srcPort);
		    XmTextSetString(fixed_paramWidget[SRC_PORT], 
				    fixed_paramValue[SRC_PORT]);
		    break;
		    
		case RATE:
		    tempint = sscanf(theText, "%f", &tempfloat);
		    if ((tempint != 1) || (tempfloat <= 0.0))
		    {
			Alert("Invalid Packet Rate!");
			return FALSE;
		    }
		    pktRate = tempfloat;
		    sprintf(fixed_paramValue[RATE], "%f", pktRate);
		    XmTextSetString(fixed_paramWidget[RATE], 
				    fixed_paramValue[RATE]);
		    break;
		
		case SIZE:
		    tempint = strtol(theText,(char **)NULL, 10);
		    if ((tempint < 32) || errno)
		    {
			Alert("Minimum packet size = 32!");
			return FALSE;
		    }
		    pktSize = tempint;
		    sprintf(fixed_paramValue[SIZE], "%d", pktSize);
		    XmTextSetString(fixed_paramWidget[SIZE], 
				    fixed_paramValue[SIZE]);
		    break;
		    
		case DURATION:
		    tempint = strtol(theText,(char **)NULL, 10);
		    if ((tempint < 0) || errno)
		    {
			Alert("Invalid Duration!");
			return FALSE;
		    }
		    Duration = tempint;
		    sprintf(fixed_paramValue[DURATION], "%d", Duration);
		    XmTextSetString(fixed_paramWidget[DURATION], 
				    fixed_paramValue[DURATION]);
		    break;
		
		case INTERFACE:
		    strcpy(interfaceName, theText);
		    strcpy(fixed_paramValue[INTERFACE], theText);
		    break;
		
		case START_TIME:
		    strcpy(StartTime, theText);
		    strcpy(fixed_paramValue[START_TIME], theText);
		    break;
		
		case PATTERN:
		    break;
	    
		default:
		    Alert("Unimplemented field!");
		    return FALSE;
		    break;
	    }
	    break;
    }
    return TRUE;
}  /* end CheckParam() */



static void redrawBangLabel()
{
    Display *dpy = XtDisplay(topLevel);   
    XSetFunction(dpy, gc, GXcopy);   
    XCopyArea(dpy, theBangMap, XtWindow(bangLabel), 
		  gc, 0, 0, 
		  bangWidth, bangHeight, 
		  0, 0);    
}  /* end redrawBangLabel() */


static void Alert(char *text)
{
    Widget dialog;
    Arg arg[1];
    XmString str;
    
    str = XmStringCreateSimple(text);
    XtSetArg(arg[0], XmNmessageString, str);
    dialog = (Widget) XmCreateMessageDialog(topLevel, "MGEN", arg, 1);
    XmStringFree(str);
    XtManageChild(dialog);
    XtVaSetValues(dialog, 
		    XmNdeleteResponse, XmDESTROY,
		    XmNdialogStyle, XmDIALOG_PRIMARY_APPLICATION_MODAL,
		    NULL);
    XtUnmanageChild(XmMessageBoxGetChild(dialog, XmDIALOG_CANCEL_BUTTON));
    XtUnmanageChild(XmMessageBoxGetChild(dialog, XmDIALOG_HELP_BUTTON));
    
}  /* end Alert() */


static int LoadMgenIcon(char **theIcon, Pixmap *theMap, Widget widget, 
			int *width, int *height)
{
    XpmAttributes *xpm_attr;
    XpmColorSymbol *csymbol;
    Colormap cmap;
    Pixel bg;
    int status;
    
    XtVaGetValues(widget, XmNbackground, &bg, NULL);
    XtVaGetValues(widget, XmNcolormap, &cmap, NULL);
    
    if(!(xpm_attr = (XpmAttributes *)calloc(1, sizeof(XpmAttributes))))
    {
	perror("MGEN: calloc(XpmAttributes error)");
	return FALSE;
    }
    if(!(csymbol = (XpmColorSymbol *)calloc(1, sizeof(XpmColorSymbol))))
    {
	perror("MGEN: calloc(XpmAttributes error)");
	return FALSE;
    }
    
    /* Create pixmap */    
    csymbol->name = "Background";
    csymbol->pixel = bg;
    xpm_attr->colorsymbols = csymbol;
    xpm_attr->numsymbols = 1;
    xpm_attr->valuemask = (XpmCloseness | XpmColormap | XpmColorSymbols);
    xpm_attr->closeness = 40000;
    xpm_attr->colormap = cmap;
    status = XpmCreatePixmapFromData(XtDisplay(widget),
				 XRootWindowOfScreen(XtScreen(widget)),
				 theIcon, theMap, NULL, xpm_attr);
    if (status != XpmSuccess) 
    {
	fprintf(stderr, "MGEN: XpmError: %s\n", XpmGetErrorString(status));
	return FALSE;
    }
    
    *width = xpm_attr->width;
    *height = xpm_attr->height;   
    free(xpm_attr);
    free(csymbol);
    return TRUE;
}  /* end LoadMgenIcon() */

/* This is required for IRIX 5.3 */
#ifdef _SGI
char *XpmGetErrorString(int errcode)
{
    switch (errcode) 
    {
	case XpmColorError:
	    return ("XpmColorError");
	case XpmSuccess:
	    return ("XpmSuccess");
	case XpmOpenFailed:
	    return ("XpmOpenFailed");
	case XpmFileInvalid:
	    return ("XpmFileInvalid");
	case XpmNoMemory:
	    return ("XpmNoMemory");
	case XpmColorFailed:
	    return ("XpmColorFailed");
	default:
	    return ("Invalid XpmError");
    }
}
#endif // _SGI

#endif // _GUI
