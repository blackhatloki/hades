#ifndef _DREC
#define _DREC

typedef enum DrecMode
{
    SCRIPTED, 
    ITERATED, 
} DrecMode;

typedef struct RecvPort
{
    unsigned short  port;
    struct RecvPort *next;
} RecvPort;

/* DREC Globals used by GUI when "-g" option is invoked */
extern DrecMode Mode;
extern char ScriptFile[];
extern char LogFile[];
extern struct in_addr baseAddress;
extern int numGroups;
extern unsigned short defaultPort;
extern char interfaceName[];
extern char StartTime[32];
extern int Duration;
extern int Offset;

static inline int IsMulticast(struct in_addr theAddress)
{
    return ((htonl(0xf0000000) & theAddress.s_addr) == 
            htonl(0xe0000000));
}  /* end IsMulticast() */

/* Public function prototypes */
RecvPort *BuildPortList(char *portText);
void DestroyPortList(RecvPort **theList);
int PreLoadDrecScript(char *scriptFile, 
		      char *portString, 
		      char *interfaceString, 
		      char *startString);

#endif //  // _DREC
