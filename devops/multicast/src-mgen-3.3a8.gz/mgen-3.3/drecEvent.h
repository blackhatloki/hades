
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>

#ifdef _RSVP
#include "mgenRsvp.h"

typedef struct
    {
        int                     style;    /* WILDCARD, FIXED, or SE */
        int                     nfilts;   /* Number of FilterSpecs */
        rapi_filter_t           *filts;   /* Pointer the filterspec list */
        int                     nflows;   /* Number of FlowSpecs */
        rapi_flowspec_t         *flows;   /* Pointer to the flowspec list */
    } rsvp_params;
#endif // _RSVP


/* DREC script commands */
typedef enum DrecCmd 
{ 
    NULL_CMD,	/* Invalid command */
    START,      /* Test start time (GMT or local time) */
    PORT, 
    INTERFACE, 
    JOIN,	/* Join given multicast group */
    LEAVE,	/* Leave given multicast group  */
    EXIT,   /* Exit Drec */
#ifdef _RSVP
    RESV,	/* Start attempting RSVP reservation with given parameters */
    UNRESV,     /* Stop attempting RSVP reservation for given session */
#endif // _RSVP
} DrecCmd;




typedef struct DrecEvent
{
    DrecCmd		cmd;	/* DREC script command */
    unsigned long	time;	/* event execution time (msec) */
    struct sockaddr_in	addr; /* group IP address (for join/leave cmd) */

#ifdef _RSVP
    rsvp_params		rsvp;
#endif // _RSVP 

    struct DrecEvent	*parent;
    struct DrecEvent	*child;
} DrecEvent;


typedef struct
{
    DrecEvent *head;
    DrecEvent *tail;
} DrecEventList;

/* Public function prototypes */
void DestroyDrecEventList(DrecEventList *theList);
void InsertDrecEvent(DrecEvent *theEvent, DrecEventList *theList);
void AppendDrecEvent(DrecEvent *theEvent, DrecEventList *theList);
DrecEvent *DiscardDrecEvent(DrecEvent *theEvent, DrecEventList *theList, 
			    DrecEventList *theTrash);

