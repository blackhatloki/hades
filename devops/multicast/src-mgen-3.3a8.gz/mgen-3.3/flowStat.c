
#include <stdlib.h>

#include "flowStat.h"

#ifndef NULL
#define NULL 0
#endif

void PrependFlowStat(FlowStat *theFlow, FlowStat **theList)
{       
    theFlow->child = *theList;
    *theList = theFlow;
}  /* end PrependFlowStat() */

void DestroyFlowStatList(FlowStat **theList)
{
    FlowStat *nextFlow;
    while((nextFlow = *theList))
    {
	*theList = (*theList)->child;
	free(nextFlow);
    }
}  /* end DestroyFlowStatList() */

FlowStat *FindFlowStat(FlowAddress *theAddr, FlowStat *nextFlow)
{
    while(nextFlow)
    {
	if(!(memcmp(theAddr, &nextFlow->flow_addr, sizeof(FlowAddress))))
	    return nextFlow;
	nextFlow = nextFlow->child;
    }
    return NULL;    
} /* end FindFlowStat() */

void PrependGroupInfo(GroupInfo *theGroup, GroupInfo **theList)
{
    theGroup->child = *theList;
    *theList = theGroup;
}  /* end PrependGroupInfo() */

void DestroyGroupInfoList(GroupInfo **theList)
{
    GroupInfo *nextGroup;
    while((nextGroup = *theList))
    {
	*theList = (*theList)->child;
	free(nextGroup);
    }
}  /* end DestroyGroupInfoList() */

GroupInfo *FindGroupInfo(struct in_addr theAddr, GroupInfo *nextGroup)
{
    while(nextGroup)
    {
	if(theAddr.s_addr == nextGroup->addr.s_addr)
	    return nextGroup;
	nextGroup = nextGroup->child;
    }
    return NULL;    
} /* end FindFlowStat() */
