/*********************************************************************
 *
 * AUTHORIZATION TO USE AND DISTRIBUTE
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that: 
 *
 * (1) source code distributions retain this paragraph in its entirety, 
 *  
 * (2) distributions including binary code include this paragraph in
 *     its entirety in the documentation or other materials provided 
 *     with the distribution, and 
 *
 * (3) all advertising materials mentioning features or use of this 
 *     software display the following acknowledgment:
 * 
 *      "This product includes software written and developed 
 *       by Brian Adamson and Joe Macker of the Naval Research 
 *       Laboratory (NRL)." 
 *         
 *  The name of NRL, the name(s) of NRL  employee(s), or any entity
 *  of the United States Government may not be used to endorse or
 *  promote  products derived from this software, nor does the 
 *  inclusion of the NRL written and developed software  directly or
 *  indirectly suggest NRL or United States  Government endorsement
 *  of this product.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 ********************************************************************/
 

#include "eventDispatcher.h"

#include <stdio.h>
#include <sys/time.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>


EventDispatcher::Item::Item()
 : flags(NONE), file_descriptor(-1), data(NULL), callback(NULL)
{
}


EventDispatcher::Item::Item(int fd, EventDispatcher::Callback func,
                            const void* userData)
 : type(GENERIC), file_descriptor(fd), data(userData), callback(func)
{
}

EventDispatcher::Item::Item(UdpSocket* theSocket)
 : type(SOCKET), file_descriptor(theSocket->Handle()), data(theSocket) 
{
}

EventDispatcher::Item::~Item()
{
    // (TBD) If open, dispatch "DETACH" event ???
}


void EventDispatcher::Item::OnInputEvent()
{
    switch (type)
    {
        case GENERIC:
            if (callback) callback(data, file_descriptor, EVENT_INPUT);
            break;
        case SOCKET:            
            // Only support UdpSocket class for now
            ((UdpSocket*)data)->OnReceive();
            break;
        default:
            break;
    }   
}

// Function pointer for user supplied timer "installer"
bool EventDispatcher::TimerInstaller(ProtocolTimerInstallCmd   cmd, 
                                     double                    theDelay,
                                     ProtocolTimerMgr*       /*timerMgr*/,
                                     const void*               installData)
{
    switch (cmd)
    {
        case PROTOCOL_TIMER_INSTALL:
        case PROTOCOL_TIMER_MODIFY:
            ((EventDispatcher*)installData)->SetTimeout(theDelay);
            break;
        case PROTOCOL_TIMER_REMOVE:
            ((EventDispatcher*)installData)->SetTimeout(-1);
            break;
    }
    return true;
}  // end EventDispatcher::TimerInstaller()

// If the installer is used, the socket's user_data is used
bool EventDispatcher::SocketInstaller(UdpSocketCmd  cmd,
                                      UdpSocket*    theSocket,
                                      const void*   installData)
{
    switch (cmd)
    {
        case UDP_SOCKET_INSTALL:
        {             
            const Item* item = 
                ((EventDispatcher*)installData)->AddSocketInput(theSocket);
            if (item)
                theSocket->SetUserData(item);
            else
                return false;
            break;
        }

        case UDP_SOCKET_REMOVE:
        {
            const Item* item = (Item*)theSocket->GetUserData();
            if (item)
                ((EventDispatcher*)installData)->RemoveItem((Item*)item);
            else
                return false;
            break;
        }
    }
    return true;  
}  // end EventDispatcher::SocketInstaller()

EventDispatcher::EventDispatcher()
	: delay(-1.0), top_item(NULL), max_fd(-1), run(false)
{
    timer_mgr.SetInstaller(EventDispatcher::TimerInstaller, this);
}

EventDispatcher::~EventDispatcher()
{
    Destroy();
}

void EventDispatcher::Destroy()
{
    Item* next;
    while ((next = top_item))
    {
        top_item = next->next;
        delete next;
    }
    delay = -1;
    max_fd = -1;
    run = false;
}  // end EventDispatcher::Destroy()

const EventDispatcher::Item* EventDispatcher::AddGenericInput(int fd, 
                                                              Callback func,
                                                              const void* userData)
{
    Item* item = new Item(fd, func, userData);   
    if (!item) return (Item*)NULL;
    // Prepend item to beginning of item list
    item->prev = NULL;
    if ((item->next = top_item)) top_item->prev = item;
    top_item = item;
	if (fd > max_fd) max_fd = fd;
    item->SetFlag(Item::INPUT);
    return item;
}  // end EventDispatcher::AddGenericInput()


const EventDispatcher::Item* EventDispatcher::AddSocketInput(UdpSocket* theSocket)
{
    Item* item = new Item(theSocket);   
    if (!item) return (Item*)NULL;
    // Prepend item to beginning of item list
    item->prev = NULL;
    if ((item->next = top_item)) top_item->prev = item;
    top_item = item;
	if (theSocket->Handle() > max_fd) max_fd = theSocket->Handle();
    item->SetFlag(Item::INPUT);
    return item;
}  // end EventDispatcher::AddSocketInput()


void EventDispatcher::RemoveItem(EventDispatcher::Item* item)
{
    if (item->prev)
		item->prev->next = item->next;
	else
		top_item = item->next;	
	if (item->next)
		item->next->prev = item->prev;	
    if (item->file_descriptor == max_fd) max_fd = FindMaxFd();
    delete item;	
}  // end void EventDispatcher::RemoveInput()


int EventDispatcher::FindMaxFd()
{
	Item* next = top_item;
	int max = -1;
	while (next)
	{
		if (next->file_descriptor > max) max = next->file_descriptor;
		next = next->next;
	}
	return max;
}  // end EventDispatcher::FindMaxFd()

EventDispatcher::Item* EventDispatcher::FindItemByFd(int fd)
{
	Item *next = top_item;
	while (next)
	{
		if (next->file_descriptor == fd) return next;
		next = next->next;
	}
	return NULL;
}  // end EventDispatcher::FindInputByFd()

void EventDispatcher::Run()
{
	run = true;
	struct timeval timeout;
    struct timeval *timeout_ptr;			
	while (run)
	{		
		if (delay >= (double)0.0)
		{
			timeout.tv_sec = (unsigned long) delay;
	    	timeout.tv_usec = 
				(unsigned long)(1000000.0 * (delay - timeout.tv_sec));

			// If it's less than 10 msec, make it poll
        	if(!timeout.tv_sec && (timeout.tv_usec < 10000))
            	timeout.tv_usec = 0;

	    	timeout_ptr = &timeout;
    	}
		else
		{
			timeout_ptr = NULL;
		}
		
		fd_set inputs;
		FD_ZERO(&inputs);
		Item* next = top_item;
		while (next)
		{
			FD_SET(next->file_descriptor, &inputs);
			next = next->next;
		}		
		if (!timeout_ptr && (!top_item))
	    {
	        fprintf(stderr, "EventDispatcher::Run() stuck with infinite timeout & no inputs!\n");
	        run = false;
	        break;
	    }	
        
        int status = select(max_fd+1, (fd_set*)&inputs, 
			    			(fd_set*) NULL, (fd_set*) NULL, 
							timeout_ptr);
		switch (status)
		{
			case -1:
				if (EINTR != errno)
					fprintf(stderr, "EventDispatcher::Run() select() error: %s\n", 
							strerror(errno));
				break;
				
			case 0:
				// timeout
				break;
				
			default:
				next = top_item;
				while(next)
				{
					if (FD_ISSET(next->file_descriptor, &inputs)) next->OnInputEvent();
					next = next->next;
				}
				break;
		}
        timer_mgr.DoTimers();	
	}  // end while(run)
}  // end EventDispatcher::Run()




		
		
