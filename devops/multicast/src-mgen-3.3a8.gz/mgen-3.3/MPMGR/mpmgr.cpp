#include "protoLib.h"
#include "gpsPub.h"

#include <stdio.h>
#include <signal.h>

static const char* KEYFILE = "/tmp/mgenPayloadKey";
static unsigned int PAYLOAD_MAX = 61; 

class MgenPayloadMgr 
#ifdef USE_INHERITANCE
    : public UdpSocketOwner
#endif // USE_INHERITANCE
{
    public:
        MgenPayloadMgr();
    
        bool Init(int argc, char* argv[]);
        void Run() {dispatcher.Run();}
        void Stop() {dispatcher.Stop();}
        void Shutdown();  
            
    private:
        bool OnSocketRecv(UdpSocket* theSocket);
        static void SignalHandler(int sigNum);
        
        EventDispatcher dispatcher;
        UdpSocket       socket;
        ProtocolTimer   tx_timer;
        GPSHandle       payload_handle;
        unsigned char   payload_size;
    
}; // end class MgenPayloadMgr

MgenPayloadMgr::MgenPayloadMgr()
 : payload_handle(NULL), payload_size(0)
{
    socket.Init((UdpSocketOwner*)this, (UdpSocketRecvHandler)&MgenPayloadMgr::OnSocketRecv, 
                EventDispatcher::SocketInstaller, &dispatcher); 
}

bool MgenPayloadMgr::Init(int /*argc*/, char** /*argv*/)
{
    if (!(payload_handle = GPSMemoryInit(KEYFILE, PAYLOAD_MAX+1)))
    {
        fprintf(stderr, "mpmgr: Error creating shared memory for payload!\n");
        return false;   
    }
    char buffer[PAYLOAD_MAX+1];
    memset(buffer, 0, (PAYLOAD_MAX+1));
    if ((PAYLOAD_MAX+1) != GPSSetMemory(payload_handle, 0, buffer, (PAYLOAD_MAX+1)))
        fprintf(stderr, "mpmgr: Error initing shared payload memory!\n"); 
    payload_size = 0;
        
    if (UDP_SOCKET_ERROR_NONE != socket.Open(5523))
    {
        fprintf(stderr, "mpmgr: Error opening UDP socket!\n");
        return false;
    }    
    signal(SIGINT, SignalHandler);
    signal(SIGTERM, SignalHandler);
    return true;
}  // end MgenPayloadMgr::Init()

void MgenPayloadMgr::Shutdown()
{
    socket.Close();
    if (payload_handle)
        GPSPublishShutdown(payload_handle, KEYFILE);
}  // end MgenPayloadMgr::Shutdown()


bool MgenPayloadMgr::OnSocketRecv(UdpSocket* /*theSocket*/)
{
    char buffer[512];
    unsigned int len = 512;
    NetworkAddress addr;
    if (UDP_SOCKET_ERROR_NONE == socket.RecvFrom(buffer, &len, &addr))
    {    
        unsigned int offset = (unsigned int) buffer[0];
        len -= 1;
        if ((offset+len) > PAYLOAD_MAX)
        {
            fprintf(stderr, "mpmgr: Received invalid message from \"%s\" ...\n",
                            addr.HostAddressString());
        }
        else
        {
            // Update shared memory "payload size" byte (offset ZERO) if needed
            if ((unsigned char)(offset+len) > payload_size)
            {
                payload_size = (unsigned char)(offset+len);
                if (1 != GPSSetMemory(payload_handle, 0, (char*)&payload_size, 1))
                    fprintf(stderr, "mpmgr: Error setting shared payload size memory!\n");   
            } 
            if (len != GPSSetMemory(payload_handle, offset+1, &buffer[1], len))
                fprintf(stderr, "mpmgr: Error setting shared payload memory!\n");       
        }
        fprintf(stderr, "mpmgr: Received \"%s\" from \"%s\"\n",
                &buffer[1], addr.HostAddressString());
    }
    return true;
}  // end MgenPayloadMgr::OnSocketRecv()


MgenPayloadMgr theApp;  // global for signal handling
           
        
int main(int argc, char* argv[])
{
    if (theApp.Init(argc, argv))
    {
        theApp.Run();
        theApp.Shutdown();
        fprintf(stderr, "mpmgr: Done.\n");
        exit(0);
    }
    else
    {
         fprintf(stderr, "mpmgr: Error initializing application!\n");
         exit(-1);  
    }        
}  // end main()


void MgenPayloadMgr::SignalHandler(int sigNum)
{
    switch(sigNum)
    {
        case SIGTERM:
        case SIGINT:
            theApp.Stop();
            break;
            
        default:
            fprintf(stderr, "gpsLogger: Unexpected signal: %d\n", sigNum);
            break; 
    }  
}  // end MgenPayloadMgr::SignalHandler()
