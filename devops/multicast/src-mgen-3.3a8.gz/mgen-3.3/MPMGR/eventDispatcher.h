/*********************************************************************
 *
 * AUTHORIZATION TO USE AND DISTRIBUTE
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that: 
 *
 * (1) source code distributions retain this paragraph in its entirety, 
 *  
 * (2) distributions including binary code include this paragraph in
 *     its entirety in the documentation or other materials provided 
 *     with the distribution, and 
 *
 * (3) all advertising materials mentioning features or use of this 
 *     software display the following acknowledgment:
 * 
 *      "This product includes software written and developed 
 *       by Brian Adamson and Joe Macker of the Naval Research 
 *       Laboratory (NRL)." 
 *         
 *  The name of NRL, the name(s) of NRL  employee(s), or any entity
 *  of the United States Government may not be used to endorse or
 *  promote  products derived from this software, nor does the 
 *  inclusion of the NRL written and developed software  directly or
 *  indirectly suggest NRL or United States  Government endorsement
 *  of this product.
 * 
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 ********************************************************************/

#ifndef _EVENT_DISPATCHER
#define _EVENT_DISPATCHER

#include "protocolTimer.h"
#include "udpSocket.h"

// Asynchronous event dispatcher class

class EventDispatcher
{
    public:
    
        // Asynchronous event types
        enum Event {EVENT_NULL, EVENT_INPUT, EVENT_DETACH};
    
        // For arbitrary asynchronous file descriptor monitoring
        typedef void (*Callback)(const void* userData, int fd, Event theEvent);

        class Item
        {
            friend class EventDispatcher;
            
            public:
                Item(int fd, Callback func, const void* userData);
                Item(UdpSocket* theSocket);
                ~Item();
                int Descriptor() {return file_descriptor;}
                
            private:
                Item();
                void OnInputEvent();
            
                enum Type {GENERIC, SOCKET};
                enum Flag {NONE = 0x00, INPUT = 0x01, OUTPUT = 0x02, EXCEPTION = 0x04};
                
                void SetFlag(Flag f) {flags |= f;}
                
                Type        type;
                int         flags;
                int         file_descriptor;
                const void* data;
                Callback    callback;
                
                Item*      prev;
                Item*      next;
        };  // end class EventDispatcher::Item
            
     
    // Construction
	    EventDispatcher();
        ~EventDispatcher();
        void Destroy();
        
    // Methods
        const EventDispatcher::Item* AddGenericInput(int fd, 
                                                     EventDispatcher::Callback inputCallback, 
                                                     const void* clientData);
        
        const EventDispatcher::Item* AddSocketInput(UdpSocket* theSocket);
        
        void RemoveItem(EventDispatcher::Item* theItem);
        
        void InstallTimer(ProtocolTimer* theTimer)
        {
            timer_mgr.InstallTimer(theTimer);
        }
        
        void Run();
	    void Stop() {run = false;}
        
        // If this optional socket installer is used instead of
        // explicit calls to "AddSocketInput()", the UdpSocket "install_data"
        // should be inited to a pointer to the EventDispatcher instance and
        // the EventDispatcher will used the UdpSocket "user_data" for its
        // own purpose.
        static bool EventDispatcher::SocketInstaller(UdpSocketCmd  cmd,
                                                     UdpSocket*    theSocket,
                                                     const void*   installData);
        
	private:
    // Methods
        int FindMaxFd();
		Item *FindItemByFd(int theFd);
        void SetTimeout(double value) {delay = value;}
        static bool EventDispatcher::TimerInstaller(ProtocolTimerInstallCmd   cmd, 
                                                     double                    theDelay,
                                                     ProtocolTimerMgr*         timerMgr,
                                                     const void*               installData);
    // Members
        ProtocolTimerMgr    timer_mgr;
	    double              delay;
	    Item*               top_item;
		int                 max_fd;
	    bool                run;
};  // end class EventDispatcher

#endif // _EVENT_DISPATCHER
