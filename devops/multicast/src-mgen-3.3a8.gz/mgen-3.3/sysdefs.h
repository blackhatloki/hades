
/*
 * sysdefs.h - some "system definitions" that MGEN uses
 */

#ifdef _SGI
#define DEFAULT_INTERFACE "ec0"
#define NETSTAT_CMD "/usr/etc/netstat -nI "
#define _LIMIT_GROUPS 1
#endif  // _SGI

#ifdef _SUNOS
#define DEFAULT_INTERFACE "le0"
#define NETSTAT_CMD "/usr/ucb/netstat -nI "
#define _LIMIT_GROUPS 1
#endif  // _SUNOS

#ifdef _SOLARIS
#define NETSTAT_CMD "/usr/bin/netstat -nI "
#ifdef _i386
#define DEFAULT_INTERFACE "elx0"
#else
#define DEFAULT_INTERFACE "le0"
#endif  // _i386
#endif  // _SOLARIS

#ifdef _NETBSD
#define DEFAULT_INTERFACE "de0"
#define NETSTAT_CMD "/usr/bin/netstat -nI "
#define _LIMIT_GROUPS 1
#endif  // _NETBSD

#ifdef _LINUX
#define DEFAULT_INTERFACE "eth0"
#define NETSTAT_CMD "/sbin/ifconfig "
#define _LIMIT_GROUPS 1
#endif  // _LINUX

#ifdef _FREEBSD
/*  For freebsd versions earlier than 3.1 interface should be xl0  */
#define DEFAULT_INTERFACE "de0"
#define NETSTAT_CMD "/usr/bin/netstat -nI "
#define _LIMIT_GROUPS 1
#endif  // _FREEBSD



