
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

typedef struct
{
  struct sockaddr_in dest;
  struct sockaddr_in src;
} FlowAddress;

typedef struct FlowStat
{
    unsigned long   id;
    FlowAddress	    flow_addr;
    float	    join_time;
    float	    first_pkt_time;
    float	    last_pkt_time;
    unsigned long   low_seq;
    unsigned long   high_seq;
    unsigned long   pkt_count;
    unsigned long   byte_count;
    double	    delay_total;
    double	    delay_max;
    double	    delay_min;
    unsigned long   prev_seq;
    unsigned long   drop_count;
    struct FlowStat *child;
}  FlowStat;

typedef struct GroupInfo
{
    struct in_addr  addr;       /* Group IP address */
    double	    join_time;  /* time (sec) group was joined */
    double	    leave_time; /* time (sec) group was left */
    struct GroupInfo *child;
} GroupInfo;

/* Public function prototypes */
void PrependFlowStat(FlowStat *theFlow, FlowStat **theList);
void DestroyFlowStatList(FlowStat **theList);
FlowStat *FindFlowStat(FlowAddress *theAddr, FlowStat *nextFlow);

void PrependGroupInfo(GroupInfo *theGroup, GroupInfo **theList);
void DestroyGroupInfoList(GroupInfo **theList);
GroupInfo *FindGroupInfo(struct in_addr theAddr, GroupInfo *nextGroup);
