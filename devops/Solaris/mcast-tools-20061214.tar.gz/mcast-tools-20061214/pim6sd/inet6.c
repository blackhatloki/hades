/*	$KAME: inet6.c,v 1.17 2004/11/17 02:16:23 itojun Exp $	*/

/*
 * Copyright (C) 1998 WIDE Project.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the project nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE PROJECT AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE PROJECT OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
/*
 *  Questions concerning this software should be directed to
 *  Mickael Hoerdt (hoerdt@clarinet.u-strasbg.fr) LSIIT Strasbourg.
 *
 */
/*
 * This program has been derived from pim6dd.        
 * The pim6dd program is covered by the license in the accompanying file
 * named "LICENSE.pim6dd".
 */
/*
 * This program has been derived from pimd.        
 * The pimd program is covered by the license in the accompanying file
 * named "LICENSE.pimd".
 *
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/param.h>
#include <net/if.h>
#include <net/route.h>
#include <netinet/in.h>
#ifdef __linux__
#include <linux/mroute6.h>
#else
#include <netinet6/ip6_mroute.h>
#endif
#include <stdio.h>
#include <netdb.h>
#include <string.h>
#include "defs.h"
#include "vif.h"
#include "inet6.h"
#include <arpa/inet.h>

/* flag if address to hostname resolution should be perfomed */
int numerichost = TRUE;

int
inet6_uvif2scopeid(struct sockaddr_in6 * sa, struct uvif * v)
{
    if (IN6_IS_ADDR_MULTICAST(&sa->sin6_addr))
    {
	if (IN6_IS_ADDR_MC_LINKLOCAL(&sa->sin6_addr))
	    return (v->uv_ifindex);
    }
    else
    {
	if (IN6_IS_ADDR_LINKLOCAL(&sa->sin6_addr))
	    return (v->uv_ifindex);
    }

    return (0);
}

int
inet6_localif_address(struct sockaddr_in6 * sa, struct uvif * v)
{
    struct phaddr  *pa;

    for (pa = v->uv_addrs; pa; pa = pa->pa_next)
	if (inet6_equal(sa, &pa->pa_addr))
	    return (TRUE);

    return (FALSE);
}

int
inet6_valid_host(struct sockaddr_in6 * addr)
{
    if (IN6_IS_ADDR_MULTICAST(&addr->sin6_addr))
	return (FALSE);

    return (TRUE);
}

int
inet6_equal(struct sockaddr_in6 * sa1, struct sockaddr_in6 * sa2)
{
    if (sa1->sin6_scope_id == sa2->sin6_scope_id &&
	IN6_ARE_ADDR_EQUAL(&sa1->sin6_addr, &sa2->sin6_addr))
	return (1);

    return (0);
}

int
inet6_lessthan(struct sockaddr_in6 * sa1, struct sockaddr_in6 * sa2)
{
    u_int32_t       s32_1,
                    s32_2;
    int             i;

    if (sa1->sin6_scope_id < sa2->sin6_scope_id)
	return (1);
    if (sa1->sin6_scope_id == sa2->sin6_scope_id)
    {
	for (i = 0; i < 4; i++)
	{
	    s32_1 = ntohl(*(u_int32_t *)&sa1->sin6_addr.s6_addr[i * 4]);
	    s32_2 = ntohl(*(u_int32_t *)&sa2->sin6_addr.s6_addr[i * 4]);

	    if (s32_1 > s32_2)
		return (0);
	    if (s32_1 < s32_2)
		return (1);

	    /* otherwide, continue to compare */
	}
    }

    return (0);
}

int
inet6_greaterthan(struct sockaddr_in6 * sa1, struct sockaddr_in6 * sa2)
{
    u_int32_t       s32_1,
                    s32_2;
    int             i;

    if (sa1->sin6_scope_id > sa2->sin6_scope_id)
	return (1);
    if (sa1->sin6_scope_id == sa2->sin6_scope_id)
    {
	for (i = 0; i < 4; i++)
	{
	    s32_1 = ntohl(*(u_int32_t *)&sa1->sin6_addr.s6_addr[i * 4]);
	    s32_2 = ntohl(*(u_int32_t *)&sa2->sin6_addr.s6_addr[i * 4]);

	    if (s32_1 < s32_2)
		return (0);
	    if (s32_1 > s32_2)
		return (1);

	    /* otherwide, continue to compare */
	}
    }

    return (0);
}

int
inet6_match_prefix(sa1, sa2, mask)
    struct sockaddr_in6 *sa1,
                   *sa2;
    struct in6_addr *mask;
{
    int             i;

    if (sa1->sin6_scope_id != sa2->sin6_scope_id)
	return (0);

    for (i = 0; i < 16; i++)
    {
	if ((sa1->sin6_addr.s6_addr[i] ^ sa2->sin6_addr.s6_addr[i]) &
	    mask->s6_addr[i])
	    return (0);
    }

    return (1);
}

int 
inet6_same_prefix(sa1,sa2,mask)
    struct sockaddr_in6 *sa1,*sa2;
    struct in6_addr *mask;
{
    int i;

    for (i = 0; i < 16; i++)
    {

        if ((sa1->sin6_addr.s6_addr[i] ^ sa2->sin6_addr.s6_addr[i]) &
             mask->s6_addr[i])
             return (0);
    }
    return 1;
}

char *
sa6_fmt(struct sockaddr_in6 *sa6)
{
    static char     ip6buf[8][MAXHOSTNAMELEN];
    static int      ip6round = 0;
    int flags = 0;
    char           *cp;
    struct sockaddr_in6 sa6_tmp; /* local copy for overriding */

    sa6_tmp = *sa6;
    sa6 = &sa6_tmp;

    /*
     * construct sin6_scope_id for link-scope addresses from  embedded link
     * IDs.
     * XXX: this should be hidden from applications.
     */
    if (IN6_IS_ADDR_LINKLOCAL(&sa6->sin6_addr) ||
	IN6_IS_ADDR_MC_LINKLOCAL(&sa6->sin6_addr)) {
	    sa6->sin6_scope_id = sa6->sin6_addr.s6_addr[2] << 8 |
		sa6->sin6_addr.s6_addr[3];
	    sa6->sin6_addr.s6_addr[2] = sa6->sin6_addr.s6_addr[3] = 0;
    }

    ip6round = (ip6round + 1) & 7;
    cp = ip6buf[ip6round];

    if (numerichost)
	    flags |= NI_NUMERICHOST;
    getnameinfo((struct sockaddr *)sa6, sizeof(*sa6), cp, MAXHOSTNAMELEN,
		NULL, 0, flags);

    return(cp);
}

/*
 * convert a 128bit IPv6 address into a text string.
 * please DO NOT use this function only when a corresponding sockaddr_in6 is
 * available.  use sa6_fmt instead.
 */
char *
inet6_fmt(struct in6_addr * addr)
{
    struct sockaddr_in6 sa6;

    init_sin6(&sa6);
    sa6.sin6_addr = *addr;

    return(sa6_fmt(&sa6));
}

char           *
ifindex2str(int ifindex)
{
    static char     ifname[IFNAMSIZ];

    return (if_indextoname(ifindex, ifname));
}

int
inet6_mask2plen(struct in6_addr * mask)
{
    int             masklen;
    u_char         *p = (u_char *) mask;
    u_char         *lim = p + 16;

    for (masklen = 0; p < lim; p++)
    {
	switch (*p)
	{
	case 0xff:
	    masklen += 8;
	    break;
	case 0xfe:
	    masklen += 7;
	    break;
	case 0xfc:
	    masklen += 6;
	    break;
	case 0xf8:
	    masklen += 5;
	    break;
	case 0xf0:
	    masklen += 4;
	    break;
	case 0xe0:
	    masklen += 3;
	    break;
	case 0xc0:
	    masklen += 2;
	    break;
	case 0x80:
	    masklen += 1;
	    break;
	case 0x00:
	    break;
	}
    }

    return (masklen);
}

char *
net6name(struct in6_addr *prefix, struct in6_addr *mask)
{
	static char ip6buf[8][NI_MAXHOST + 4]; /* length of addr/plen */
	static int ip6round = 0;
	char *cp, *ep, *p;
	
	ip6round = (ip6round + 1) & 7;
	cp = ip6buf[ip6round];
	ep = &ip6buf[ip6round][sizeof(ip6buf[ip6round])];

	p = inet6_fmt(prefix);
	if (!p)
		return NULL;
#ifdef HAVE_STRLCPY
	strlcpy(cp, p, sizeof(ip6buf[ip6round]));
#elif HAVE_STRNCPY
	strncpy(cp, p, sizeof(ip6buf[ip6round]));
#else
	strcpy(cp, p);
#endif
	cp += strlen(cp);
	snprintf(cp, ep - cp, "/%d", inet6_mask2plen(mask));

	return(ip6buf[ip6round]);
}

void
init_sin6(struct sockaddr_in6 *sin6)
{
	memset(sin6, 0, sizeof(*sin6));
	sin6->sin6_family = AF_INET6;
#ifdef HAVE_SA_LEN
	sin6->sin6_len = sizeof(*sin6);
#endif
}

socklen_t
get_sa_len(struct sockaddr *addr)
{
#ifdef HAVE_SA_LEN
	return addr->sa_len;
#else
	switch (addr->sa_family) {
	case AF_INET:
		return sizeof(struct sockaddr_in);
	case AF_INET6:
		return sizeof(struct sockaddr_in6);
	default:
		return sizeof(struct sockaddr);
	}
#endif
}
