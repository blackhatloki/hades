/*	$KAME: vers.c,v 1.2 2000/12/04 06:45:32 itojun Exp $	*/

char todaysversion[]="2.1.0-alpha23";
