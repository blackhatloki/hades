/*	$KAME: vers.c,v 1.2 2000/12/04 06:33:11 itojun Exp $	*/

char todaysversion[]="0.2.1.0-alpha15";
