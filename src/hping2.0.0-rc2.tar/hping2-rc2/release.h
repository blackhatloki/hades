/* 
 * $smu-mark$ 
 * $name: release.h$
 * $author: Salvatore Sanfilippo <antirez@invece.org>$
 * $copyright: Copyright (C) 1999 by Salvatore Sanfilippo$
 * $license: This software is under GPL version 2 of license$
 * $date: Fri Nov  16 11:55:49 MET 1999$
 * $rev: 17$
 */ 

#ifndef _RELEASE_H
#define _RELEASE_H

#define RELEASE_VERSION "2.0.0 release candidate 2"
#define RELEASE_DATE "Wed Aug 15 02:59:30 CEST 2001"
#define CONTACTS "<antirez@invece.org>"

#endif /* _RELEASE_H */
