/** @file tlv_0012bb.c

License: See LICENSE file for more info.

Authors: Terry Simons (terry.simons@gmail.com)
 */
