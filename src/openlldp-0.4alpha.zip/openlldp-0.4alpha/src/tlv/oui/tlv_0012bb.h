/** @file 0012bb.h

License: See LICENSE file for more info.

Authors: Terry Simons (terry.simons@gmail.com)
*/

#ifndef LLDP_TLV_0012BB_H
#define LLDP_TLV_0012BB_H

#endif /* LLDP_TLV_0012BB_H */
