This directory tree contains the development files for the SmokeTrace
Tool. Its content is not required to run SMokeping OR SmokeTrace.
 
