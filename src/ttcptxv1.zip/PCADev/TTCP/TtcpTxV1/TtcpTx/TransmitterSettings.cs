using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace PcaUsa.Ttcp
{
    public class TransmitterSettings
    {
		#region Private Fields
		private int _applicationBufferSize = 8192;
		private int _socketOptionBufferSize = 8192;
		private bool _socketOptionNoDelay = false;
		private int _numberOfBuffers = 2048;
		private string _receiverHostName = "Unknown";
		private int _tTcpPort = 5001;
		#endregion

		#region Public Properties
		public int ApplicationBufferSize
		{
			get
			{
				return this._applicationBufferSize;
			}
		}
		public int SocketOptionBufferSize
		{
			get
			{
				return this._socketOptionBufferSize;
			}
		}
		public bool SocketOptionNoDelay
		{
			get
			{
				return this._socketOptionNoDelay;
			}
		}
		public int NumberOfBuffers
		{
			get
			{
				return this._numberOfBuffers;
			}
		}
		public string ReceiverHostName
		{
			get
			{
				return this._receiverHostName;
			}
		}
		public int TtcpPort
		{
			get
			{
				return this._tTcpPort;
			}
		}
		#endregion

		#region Constructor
        public TransmitterSettings(string receiverHostName, int tTcpPort, int applicationBufferSize, int socketOptionBufferSize, int numberOfBuffers, bool socketOptionNoDelay)
        {
            this._receiverHostName = receiverHostName;
            this._tTcpPort = tTcpPort;
            this._applicationBufferSize = applicationBufferSize;
            this._socketOptionBufferSize = socketOptionBufferSize;
            this._numberOfBuffers = numberOfBuffers;
            this._socketOptionNoDelay= socketOptionNoDelay;
        }
		#endregion
    }
}