PCAUSA .NET Framework TTCP Transmitter
November 8, 2004

I have been working occasionally on making improvements to the PCATTCP application. My goal
is to provide a distributed and flexible benchmarking suite. The desired architecture would
include "TTCP Agents" that implement the TTCP Transmitter and TTCP Receiver function under the
control of a remote "TTCP Console" management application.

As time permits I have bread boarded many of the pieces under the .NET Framework V1.1. Unfortunately
I haven't been able to glue them all together yet.

Nevertheless, for some perverse reason I wanted to put out at least one small improvement in the
form of a TTCP Transmitter built under the .NET Framework. So, here it is...

The TtcpTx application is a forms-based TTCP Transmitter. It allows easy entry of the basic TTCP
test parameters and then performs the transmit operation using an instance the .NET TcpClient class.
It's not perfect by a long shot, but it is functional and may be useful to a few of you.

TTCP test paremeters can be saved to a file and then opened later if desired.

At this time there is no .NET version of the TTCP receiver. I would suggest that you just run the
existing PCATTCP application in the continuous receiver mode as the "other end" of TtcpTx.

  PCATTCP -c -r
  
The ZIP file contains sources to the current PCATTCP application modified for build under Visual
Studio .NET 2003 as well as sources for TtcpTx .NET Framework version.
  
I would appreciate feedback about improvements, bugs, etc.

Thomas F. Divine
tdivine@pcausa.com

Known Deficiencies/To-Do List
=============================
1.) Need to use ErrorProvider to give feedback on validation errors.
2.) Need to validate .TtcpTx files when they are opened.
3.) Need to support dirty bit when saving .TtcpTx file.
4.) Need to make application more responsive during transmission phase. Run TtcpClient in separate
    thread. Provide feedback (progress bar or animation) during transmission.
5.) Provide way to save test results in format compatible with spreadsheet.
6.) Make improvements to canned data sent in transmit buffer.
7.) Add comments!!!
8.) Fix FxCop complaints (primarily naming...).


