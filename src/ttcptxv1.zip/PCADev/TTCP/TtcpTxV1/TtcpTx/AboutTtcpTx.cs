using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace PcaUsa.Ttcp
{
	public class AboutTtcpTx : System.Windows.Forms.Form
	{
		#region Private Fields
        private System.Windows.Forms.LinkLabel linkLabelPcaUsaTtcp;
        private System.Windows.Forms.Label labelVersion;
        private System.Windows.Forms.Button buttonOK;
		private System.ComponentModel.Container components = null;
		#endregion

		#region Constructor
		public AboutTtcpTx()
		{
			this.InitializeComponent();
            this.labelVersion.Text = "PCAUSA TTCP Transmitter Version 1.0.0.1";
        }
		#endregion

		#region Private Event Handlers
		private void buttonOK_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
		private void OnClickLinkLabel(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			System.Diagnostics.Process.Start("http://www.pcausa.com/Utilities/pcattcp.htm");
		}
		#endregion

		#region Protected Methods
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (this.components != null)
				{
					this.components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		#endregion

		#region Private Methods
		private void InitializeComponent()
		{
            this.linkLabelPcaUsaTtcp = new System.Windows.Forms.LinkLabel();
            this.labelVersion = new System.Windows.Forms.Label();
            this.buttonOK = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // linkLabelPcaUsaTtcp
            // 
            this.linkLabelPcaUsaTtcp.Location = new System.Drawing.Point(16, 40);
            this.linkLabelPcaUsaTtcp.Name = "linkLabelPcaUsaTtcp";
            this.linkLabelPcaUsaTtcp.Size = new System.Drawing.Size(240, 23);
            this.linkLabelPcaUsaTtcp.TabIndex = 5;
            this.linkLabelPcaUsaTtcp.TabStop = true;
            this.linkLabelPcaUsaTtcp.Text = "http://www.pcausa.com/Utilities/pcattcp.htm";
            this.linkLabelPcaUsaTtcp.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.OnClickLinkLabel);
            // 
            // labelVersion
            // 
            this.labelVersion.Location = new System.Drawing.Point(16, 16);
            this.labelVersion.Name = "labelVersion";
            this.labelVersion.Size = new System.Drawing.Size(248, 16);
            this.labelVersion.TabIndex = 4;
            this.labelVersion.Text = "PCAUSA TTCP Transmitter Version 1.0.0.3";
            // 
            // buttonOK
            // 
            this.buttonOK.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonOK.Location = new System.Drawing.Point(288, 16);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.TabIndex = 3;
            this.buttonOK.Text = "OK";
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // AboutTtcpTx
            // 
            this.AcceptButton = this.buttonOK;
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.CancelButton = this.buttonOK;
            this.ClientSize = new System.Drawing.Size(376, 78);
            this.Controls.Add(this.linkLabelPcaUsaTtcp);
            this.Controls.Add(this.labelVersion);
            this.Controls.Add(this.buttonOK);
            this.Name = "AboutTtcpTx";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "About TTCP Transmitter";
            this.ResumeLayout(false);

        }
		#endregion
	}
}