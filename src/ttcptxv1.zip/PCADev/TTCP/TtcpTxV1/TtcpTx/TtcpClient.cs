using System;
using System.Net;

namespace PcaUsa.Ttcp
{
	public class TtcpClient : IDisposable
	{
		#region Private Fields
		private bool _disposed = false;
		private System.Net.Sockets.Socket _clientSocket;
		private bool _socketActive = false;
		private int _numberOfCalls = 0;
		private int _bytesTransmitted = 0;
		private int _startTickCount = 0;
		private int _endTickCount = 0;
		#endregion

		#region Public Properties
		public int NumberOfCalls
		{
			get
			{
				return this._numberOfCalls;
			}
		}
		public int BytesTransmitted
		{
			get
			{
				return this._bytesTransmitted;
			}
		}
		public int StartTickCount
		{
			get
			{
				return this._startTickCount;
			}
		}
		public int EndTickCount
		{
			get
			{
				return this._endTickCount;
			}
		}
		public int ElapsedTickCount
		{
			get
			{
				return (this._endTickCount - this._startTickCount);
			}
		}
		public System.Net.EndPoint LocalEndPoint
		{
			get
			{
				return this._clientSocket.LocalEndPoint;
			}
		}
		public System.Net.EndPoint RemoteEndPoint
		{
			get
			{
				return this._clientSocket.RemoteEndPoint;
			}
		}
		public int SendBufferSize
		{
			get 
			{
				return (int) this._clientSocket.GetSocketOption(System.Net.Sockets.SocketOptionLevel.Socket, System.Net.Sockets.SocketOptionName.SendBuffer);
			}

			set 
			{
				this._clientSocket.SetSocketOption(System.Net.Sockets.SocketOptionLevel.Socket, System.Net.Sockets.SocketOptionName.SendBuffer, value);
			}
		}
		public bool NoDelay
		{
			get 
			{
				return (int) this._clientSocket.GetSocketOption(System.Net.Sockets.SocketOptionLevel.Tcp, System.Net.Sockets.SocketOptionName.NoDelay) != 0 ? true : false;
			}
			set 
			{
				this._clientSocket.SetSocketOption(System.Net.Sockets.SocketOptionLevel.Tcp, System.Net.Sockets.SocketOptionName.NoDelay, value ? 1 : 0);
			}
		}
		#endregion

		#region Constructor / Destructor
		public TtcpClient()
		{
			this.InitSocket();
		}
		~TtcpClient()
		{
			if (!this._disposed)
			{
				this.Dispose();
			}
		}
		#endregion

		#region Private Methods
		private void InitSocket() 
		{
			this._clientSocket = new System.Net.Sockets.Socket(System.Net.Sockets.AddressFamily.InterNetwork, System.Net.Sockets.SocketType.Stream, System.Net.Sockets.ProtocolType.Tcp);
			this._socketActive = false;
		}
		private void Connect(System.Net.IPEndPoint remoteEndPoint) 
		{
			if (remoteEndPoint != null) 
			{
				this._clientSocket.Connect(remoteEndPoint);
				this._socketActive = true;
			}
			else
			{
				throw new ArgumentNullException("remoteEP");
			}
		}
		private void Shutdown()
		{
			this._clientSocket.Shutdown(System.Net.Sockets.SocketShutdown.Both);
			this._endTickCount = System.Environment.TickCount;
		}
		#endregion

		#region Public Methods
		public void Connect(string hostname, int port) 
		{
			if (hostname != null)
			{
				// Validate TCP Port Number
				if ((port > System.Net.IPEndPoint.MinPort) & (port <= System.Net.IPEndPoint.MaxPort))
				{
					bool isIPAddress = false;
					System.Net.IPAddress address = null;
					try
					{
						address = System.Net.IPAddress.Parse(hostname);
						isIPAddress = true;
					}
					catch (FormatException)
					{
						isIPAddress = false;
					}
					if (!isIPAddress)
					{
						// Get host related information.
						System.Net.IPHostEntry ipHostEntry = System.Net.Dns.Resolve(hostname);
						// Loop through the AddressList to obtain the supported AddressFamily. This is to avoid
						// an exception to be thrown if the host IP Address is not compatible with the address family
						// (typical in the IPv6 case).
						foreach (System.Net.IPAddress ipAddress in ipHostEntry.AddressList)
						{
							switch (ipAddress.AddressFamily)
							{
								case System.Net.Sockets.AddressFamily.InterNetwork:
								{
									address = ipAddress;
									break;
								}
								case System.Net.Sockets.AddressFamily.InterNetworkV6:
								{
									address = ipAddress;
									break;
								}
							}
							// If the address is set then break from the loop.
							if (address != null)
							{
								break;
							}
						}
					}
					this.Connect(new System.Net.IPEndPoint(address, port));
				}
				else
				{
					throw new ArgumentOutOfRangeException("port");
				}
			}
			else
			{
				throw new ArgumentNullException("hostname");
			}
		}
		public System.IAsyncResult BeginSend(byte[] buffer, int offset, int size, System.Net.Sockets.SocketFlags socketFlags, System.AsyncCallback callback, object state)
		{
			++this._numberOfCalls;
			if (this._bytesTransmitted == 0)
			{
				this._startTickCount = System.Environment.TickCount;
			}
			return this._clientSocket.BeginSend(buffer, offset, size, socketFlags, callback, state);
		}
		public int EndSend(System.IAsyncResult asyncResult)
		{
			return this._clientSocket.EndSend(asyncResult);
		}
		public int Send(byte[] buffer)
		{
			++this._numberOfCalls;
			if (this._bytesTransmitted == 0)
			{
				this._startTickCount = System.Environment.TickCount;
			}
			this._bytesTransmitted += buffer.Length;
			return this._clientSocket.Send(buffer);
		}
		public void Close()
		{
			this.Shutdown();
			this._clientSocket.Close();
			this._clientSocket = null;
			this._socketActive = false;
		}
		public void Dispose()
		{
			if (this._socketActive)
			{
				this.Close();
			}
		}
		#endregion
	}
}