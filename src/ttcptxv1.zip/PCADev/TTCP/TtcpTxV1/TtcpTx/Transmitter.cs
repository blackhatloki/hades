using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace PcaUsa.Ttcp
{
    public class TransmitterSettings
    {
        public TransmitterSettings(
            string ReceiverHostName,
            int TtcpPort,
            int ApplicationBufferSize,
            int SocketOptionBufferSize,
            int NumberOfBuffers,
            bool SocketOptionNoDelay
            )
        {
            this.ReceiverHostName = ReceiverHostName;
            this.TtcpPort = TtcpPort;
            this.ApplicationBufferSize = ApplicationBufferSize;
            this.SocketOptionBufferSize = SocketOptionBufferSize;
            this.NumberOfBuffers = NumberOfBuffers;
            this.SocketOptionNoDelay= SocketOptionNoDelay;
        }

        public int ApplicationBufferSize = 8192;

        public int SocketOptionBufferSize = 8192;

        public bool SocketOptionNoDelay = false;

        public int NumberOfBuffers = 2048;

        public string ReceiverHostName = "Unknown";

        public int TtcpPort = 5001;
        }
    }

public class TtcpClient : IDisposable
{
    private Socket clientSocket;
    private bool socketActive = false;

    private int numberOfCalls = 0;

    public int NumberOfCalls
    {
        get
        {
            return numberOfCalls;
        }
    }

    private int bytesTransmitted = 0;

    public int BytesTransmitted
    {
        get
        {
            return bytesTransmitted;
        }
    }

    private int startTickCount = 0;

    public int StartTickCount
    {
        get
        {
            return startTickCount;
        }
    }

    private int endTickCount = 0;

    public int EndTickCount
    {
        get
        {
            return endTickCount;
        }
    }

    public int ElapsedTickCount
    {
        get
        {
            return endTickCount - startTickCount;
        }
    }

    private void initSocket() 
    {
        clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        socketActive = false;
    }

    public TtcpClient()
    {
        initSocket();
    }

    public System.Net.EndPoint LocalEndPoint
    {
        get
        {
            return clientSocket.LocalEndPoint;
        }
    }

    public System.Net.EndPoint RemoteEndPoint
    {
        get
        {
            return clientSocket.RemoteEndPoint;
        }
    }

    public int SendBufferSize
    {
        get 
        {
            return (int)clientSocket.GetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendBuffer);
        }

        set 
        {
            clientSocket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendBuffer, value);
        }
    }

    public bool NoDelay
    {
        get 
        {
            return (int)clientSocket.GetSocketOption(SocketOptionLevel.Tcp, SocketOptionName.NoDelay) != 0 ? true : false;
        }
        set 
        {
            clientSocket.SetSocketOption(SocketOptionLevel.Tcp, SocketOptionName.NoDelay, value ? 1 : 0);
        }
    }

    public void Connect(string hostname, int port) 
    {
        if (hostname==null) 
        {
            throw new ArgumentNullException("hostname");
        }

        // Validate TCP Port Number
        if( port < 1 || port > 65535 )
        {
            throw new ArgumentOutOfRangeException("port");
        }

        bool isIPAddress = false;
        IPAddress address = null;

        try
        {
            address = IPAddress.Parse( hostname );
            isIPAddress = true;
        }
        catch( FormatException )
        {
            isIPAddress = false;
        }

        if( isIPAddress == false )
        {
            address = Dns.Resolve(hostname).AddressList[0];
        }

        Connect(address, port);
    }

    public void Connect(IPAddress address, int port) 
    {
        if (address==null) 
        {
            throw new ArgumentNullException("address");
        }

        // Validate TCP Port Number
        if( port < 1 || port > 65535 )
        {
            throw new ArgumentOutOfRangeException("port");
        }

        IPEndPoint remoteEP = new IPEndPoint(address, port);
        Connect(remoteEP);
    }

    public void Connect(IPEndPoint remoteEP) 
    {
        if (remoteEP==null) 
        {
            throw new ArgumentNullException("remoteEP");
        }

        clientSocket.Connect(remoteEP);
        socketActive = true;
    }

    public IAsyncResult BeginSend(
        byte[] buffer,
        int offset,
        int size,
        SocketFlags socketFlags,
        AsyncCallback callback,
        object state
        )
    {
        ++numberOfCalls;

        if( bytesTransmitted == 0 )
        {
            startTickCount = Environment.TickCount;
        }

        return clientSocket.BeginSend(
            buffer,
            offset,
            size,
            socketFlags,
            callback,
            state
            );
    }

    public int EndSend( IAsyncResult asyncResult )
    {
        return clientSocket.EndSend( asyncResult );
    }

    public int Send( byte[] buffer )
    {
        ++numberOfCalls;

        if( bytesTransmitted == 0 )
        {
            startTickCount = Environment.TickCount;
        }

        bytesTransmitted += buffer.Length;

        return clientSocket.Send( buffer );
    }

    public void Shutdown()
    {
        clientSocket.Shutdown( SocketShutdown.Both );

        endTickCount = Environment.TickCount;
    }

    public void Close()
    {
        Shutdown();

        clientSocket.Close();
    }

    #region IDisposable Members

    public void Dispose()
    {
        // TODO:  Add TtcpClient.Dispose implementation
    }

    #endregion
}