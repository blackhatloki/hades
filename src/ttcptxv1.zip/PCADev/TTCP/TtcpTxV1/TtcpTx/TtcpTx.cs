using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Text;
using System.Xml;

namespace PcaUsa.Ttcp
{
	public class TtcpTx : System.Windows.Forms.Form
	{
		#region Private Constants
		private const string TtcpTransmitProject	= "TtcpTransmitProject";
		private const string TransmitterSettings	= "TransmitterSettings";
		private const string ApplicationBufferSize	= "ApplicationBufferSize";
		private const string SocketOptionBufferSize = "SocketOptionBufferSize";
		private const string NumberOfBuffers		= "NumberOfBuffers";
		private const string ReceiverHostName		= "ReceiverHostName";
		private const string TtcpPort				= "TtcpPort";
		private const string SocketOptionNoDelay	= "SocketOptionNoDelay";
		#endregion

		#region Private Fields
        private System.Windows.Forms.MainMenu mainMenu;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.MenuItem menuItemFile;
        private System.Windows.Forms.MenuItem menuItemHelp;
        private System.Windows.Forms.MenuItem menuItemFileNew;
        private System.Windows.Forms.MenuItem menuItemFileOpen;
        private System.Windows.Forms.MenuItem menuItemFileSave;
        private System.Windows.Forms.MenuItem menuItemFileSaveAs;
        private System.Windows.Forms.MenuItem menuItemHelpAbout;
        private System.Windows.Forms.MenuItem menuItem1;
        private System.Windows.Forms.MenuItem menuItemFileExit;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Panel panelTestControls;
        private System.Windows.Forms.TextBox textBoxReceiverHostName;
        private System.Windows.Forms.Button buttonStartTransmit;
        private System.Windows.Forms.TextBox textBoxSocketOptionBufferSize;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.CheckBox checkBoxSocketOptionNoDelay;
        private System.Windows.Forms.TextBox textBoxApplicationBufferSize;
        private System.Windows.Forms.TextBox textBoxNumberOfBuffers;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxTtcpPort;
        private System.Windows.Forms.TextBox textBoxLogMessages;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Button buttonClearMessageLog;
        private System.ComponentModel.IContainer components;
		private string _tTcpTxPathName = null;
		#endregion

		#region Constructor
		public TtcpTx()
		{
			this.InitializeComponent();
		}
		#endregion

		#region Private Event Handlers
		private void OnStartTransmit(object sender, System.EventArgs e)
		{
			this.buttonStartTransmit.Enabled = false;
			PcaUsa.Ttcp.TransmitterSettings settings = this.GetTransmitterSettings();
			PcaUsa.Ttcp.TtcpClient client = new PcaUsa.Ttcp.TtcpClient();
			System.Text.StringBuilder logText = new System.Text.StringBuilder();
			try
			{
				logText.AppendFormat( "{0} {1} connecting to {2}:{3}...",
					System.DateTime.UtcNow.ToString(),
					System.Environment.MachineName, settings.ReceiverHostName, settings.TtcpPort );
				this.textBoxLogMessages.Text += logText.ToString();
				this.textBoxLogMessages.Update();
				client.Connect(settings.ReceiverHostName, settings.TtcpPort);
				logText.Length = 0;
				logText.AppendFormat("Connected");
				logText.Append(System.Environment.NewLine);
				this.textBoxLogMessages.Text += logText.ToString();
				this.textBoxLogMessages.Update();
			}
			catch (System.Net.Sockets.SocketException)
			{
				logText.Length = 0;
				logText.AppendFormat("Connect Failed");
				logText.Append(System.Environment.NewLine);
				this.textBoxLogMessages.Text += logText.ToString();
				this.textBoxLogMessages.Update();
				this.buttonStartTransmit.Enabled = true;
				return;
			}
			try
			{
				byte[] txBuffer = new byte[settings.ApplicationBufferSize];
				int count = settings.ApplicationBufferSize;
				int offset = 0;
				if (count >= 22)
				{
					System.Text.Encoding.ASCII.GetBytes("PCAUSA PCATTCP Pattern", 0, 22, txBuffer, 0); 
					count -= 22;
					offset += 22;
				}
				while (count-- > 0)
				{
					txBuffer[offset++] = (byte) offset;
				}
				client.SendBufferSize = settings.SocketOptionBufferSize;
				client.NoDelay = settings.SocketOptionNoDelay;
				for (int i = 0; i < settings.NumberOfBuffers; ++i)
				{
					client.Send(txBuffer);
				}
				logText.Length = 0;
				logText.AppendFormat("{0}->{1}", client.LocalEndPoint.ToString(), client.RemoteEndPoint.ToString());
                client.Close();
                logText.Append(System.Environment.NewLine);
				this.textBoxLogMessages.Text += logText.ToString();
				logText.Length = 0;
				logText.AppendFormat("Application Buffer Size: {0}; Network Buffer Size: {1}", settings.ApplicationBufferSize, settings.SocketOptionBufferSize);
				logText.AppendFormat("; NoDelay: {0}", settings.SocketOptionNoDelay == true ? "true" : "false");
				logText.Append(System.Environment.NewLine);
				this.textBoxLogMessages.Text += logText.ToString();
				// Elapsed Real Time in Milliseconds
				float RealTime = (float) client.ElapsedTickCount;
				logText.Length = 0;
				logText.AppendFormat("{0} bytes in {1:F} real seconds = {2:F} KB/sec ({3:F} bytes/sec)",
					client.BytesTransmitted, RealTime/1000, (float )(client.BytesTransmitted/1024)/(RealTime/1000), (float )client.BytesTransmitted/(RealTime/1000));
				logText.Append(System.Environment.NewLine);
				this.textBoxLogMessages.Text += logText.ToString();
				logText.Length = 0;
				logText.AppendFormat("{0} calls in {1:F} real seconds = {2:F} calls/sec; {3:F} msec/call",
					client.NumberOfCalls, RealTime/1000, (float )client.NumberOfCalls/(RealTime/1000), (float )RealTime/client.NumberOfCalls);
				logText.Append(System.Environment.NewLine);
				this.textBoxLogMessages.Text += logText.ToString();
			}
			catch( System.Net.Sockets.SocketException )
			{
				logText.Length = 0;
				logText.AppendFormat("Send Failed");
				logText.Append(System.Environment.NewLine);
				this.textBoxLogMessages.Text += logText.ToString();
			}
			this.textBoxLogMessages.Text += "****************";
			this.textBoxLogMessages.Text += System.Environment.NewLine;
			this.textBoxLogMessages.Update();
			this.buttonStartTransmit.Enabled = true;
		}
		private void OnFileNew(object sender, System.EventArgs e)
		{
			this.Text = "Untitled - TTCP Transmitter";
			this._tTcpTxPathName = null;
			this.textBoxApplicationBufferSize.Text = "8192";
			this.textBoxSocketOptionBufferSize.Text = "8192";
			this.checkBoxSocketOptionNoDelay.Checked = false;
			this.textBoxNumberOfBuffers.Text = "2048";
			this.textBoxReceiverHostName.Text = "Unknown";
			this.textBoxTtcpPort.Text = "5001";
		}
		private void OnFileOpen(object sender, System.EventArgs e)
		{
			this.openFileDialog.ShowDialog();
		}
		private void OnFileSave(object sender, System.EventArgs e)
		{
			this.saveFileDialog.FileName = this._tTcpTxPathName;
			if (this._tTcpTxPathName != null)
			{
				this.OnFileSaveFileOk(this, null);
			}
			else
			{
				this.saveFileDialog.ShowDialog();
			}
		}
		private void OnFileSaveAs(object sender, System.EventArgs e)
		{
			this.saveFileDialog.ShowDialog();
		}
		private void OnFileExit(object sender, System.EventArgs e)
		{
			this.Close();
		}
		private void OnHelpAbout(object sender, System.EventArgs e)
		{
			PcaUsa.Ttcp.AboutTtcpTx aboutTtcpTx = new PcaUsa.Ttcp.AboutTtcpTx();
			aboutTtcpTx.ShowDialog(this);
		}
		private void OnFileOpenFileOk(object sender, System.ComponentModel.CancelEventArgs e)
		{
			System.Xml.XmlTextReader reader = null;
			this._tTcpTxPathName = this.openFileDialog.FileName;
			this.Text = System.IO.Path.GetFileName(this._tTcpTxPathName) + " - TTCP Transmitter";
			// Load the reader with the data file and ignore all white space nodes.         
			reader = new System.Xml.XmlTextReader(this._tTcpTxPathName);
			reader.WhitespaceHandling = WhitespaceHandling.None;
			// Parse the file and display each of the nodes.
			while (reader.Read()) 
			{
				switch (reader.NodeType) 
				{
					case System.Xml.XmlNodeType.Element:
					{
						switch (reader.Name)
						{
							case PcaUsa.Ttcp.TtcpTx.ApplicationBufferSize:
							{
								reader.Read();
								if (reader.NodeType.Equals(System.Xml.XmlNodeType.Text))
								{
									this.textBoxApplicationBufferSize.Text = reader.Value;
								}
								break;
							}
							case PcaUsa.Ttcp.TtcpTx.SocketOptionBufferSize:
							{
								reader.Read();
								if (reader.NodeType.Equals(System.Xml.XmlNodeType.Text))
								{
									this.textBoxSocketOptionBufferSize.Text = reader.Value;
								}
								break;
							}
							case PcaUsa.Ttcp.TtcpTx.NumberOfBuffers:
							{
								reader.Read();
								if (reader.NodeType.Equals(System.Xml.XmlNodeType.Text))
								{
									this.textBoxNumberOfBuffers.Text = reader.Value;
								}
								break;
							}
							case PcaUsa.Ttcp.TtcpTx.ReceiverHostName:
							{
								reader.Read();
								if( reader.NodeType == XmlNodeType.Text )
								{
									textBoxReceiverHostName.Text = reader.Value;
								}
								break;
							}
							case PcaUsa.Ttcp.TtcpTx.TtcpPort:
							{
								reader.Read();
								if (reader.NodeType.Equals(System.Xml.XmlNodeType.Text))
								{
									this.textBoxTtcpPort.Text = reader.Value;
								}
								break;
							}
							case PcaUsa.Ttcp.TtcpTx.SocketOptionNoDelay:
							{
								reader.Read();
								if (reader.NodeType.Equals(System.Xml.XmlNodeType.Text))
								{
									if (reader.Value.Equals("true"))
									{
										this.checkBoxSocketOptionNoDelay.Checked = true;
									}
									else
									{
										this.checkBoxSocketOptionNoDelay.Checked = false;
									}
								}
								break;
							}
						}
						break;
					}
				}       
			}
			reader.Close();
		}
		private void OnCancel(object sender, System.EventArgs e)
		{
			this.OnFileExit(this, null);
		}
		private void OnFileSaveFileOk(object sender, System.ComponentModel.CancelEventArgs e)
		{
			this._tTcpTxPathName = this.saveFileDialog.FileName;
			this.Text = System.IO.Path.GetFileName(this._tTcpTxPathName) + " - TTCP Transmitter";
			System.Xml.XmlTextWriter writer = null;
			writer = new XmlTextWriter(this._tTcpTxPathName, null );
			writer.Formatting = System.Xml.Formatting.Indented;
			writer.WriteStartDocument();
			writer.WriteStartElement(PcaUsa.Ttcp.TtcpTx.TtcpTransmitProject);
			writer.WriteStartElement(PcaUsa.Ttcp.TtcpTx.TransmitterSettings);
			writer.WriteElementString(PcaUsa.Ttcp.TtcpTx.ApplicationBufferSize, textBoxApplicationBufferSize.Text);
			writer.WriteElementString(PcaUsa.Ttcp.TtcpTx.SocketOptionBufferSize, textBoxSocketOptionBufferSize.Text);
			writer.WriteElementString(PcaUsa.Ttcp.TtcpTx.SocketOptionNoDelay, this.checkBoxSocketOptionNoDelay.Checked.ToString());
			writer.WriteElementString(PcaUsa.Ttcp.TtcpTx.NumberOfBuffers, this.textBoxNumberOfBuffers.Text);
			writer.WriteElementString(PcaUsa.Ttcp.TtcpTx.TtcpPort, this.textBoxTtcpPort.Text);
			writer.WriteElementString(PcaUsa.Ttcp.TtcpTx.ReceiverHostName, this.textBoxReceiverHostName.Text);
			writer.WriteEndElement();
			writer.WriteEndElement();
			writer.WriteEndDocument();
			writer.Close();
		}
		private void OnValidatePortNumber(object sender, System.ComponentModel.CancelEventArgs e)
		{
			try
			{
				int port = System.Convert.ToInt32(this.textBoxTtcpPort.Text);
				if (!(port > System.Net.IPEndPoint.MinPort) & !(port <= System.Net.IPEndPoint.MaxPort))
				{
					e.Cancel = true;
				}
			}
			catch (System.Exception)
			{
				e.Cancel = true;
			}
		}
		private void OnValidateApplicationBufferSize(object sender, System.ComponentModel.CancelEventArgs e)
		{
			try
			{
				if (System.Convert.ToInt32(this.textBoxApplicationBufferSize.Text) <= 0)
				{
					e.Cancel = true;
				}
				else
				{
					this.textBoxSocketOptionBufferSize.Text = this.textBoxApplicationBufferSize.Text;
				}
			}
			catch (System.Exception)
			{
				e.Cancel = true;
			}
		}
		private void OnValidateNumberOfBuffers(object sender, System.ComponentModel.CancelEventArgs e)
		{
			try
			{
				if (Convert.ToInt32(this.textBoxNumberOfBuffers.Text) <= 0)
				{
					e.Cancel = true;
				}
			}
			catch (System.Exception)
			{
				e.Cancel = true;
			}
		}
		private void OnValidateSocketOptionBufferSize(object sender, System.ComponentModel.CancelEventArgs e)
		{
			try
			{
				if (System.Convert.ToInt32(this.textBoxSocketOptionBufferSize.Text) <= 0)
				{
					e.Cancel = true;
				}
			}
			catch (System.Exception)
			{
				e.Cancel = true;
			}
		}
		private void buttonClearMessageLog_Click(object sender, System.EventArgs e)
		{
			this.textBoxLogMessages.Clear();
		}
		#endregion

		#region Protected Methods
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (this.components != null) 
				{
					this.components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		#endregion

		#region Private Methods
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.menuItemFile = new System.Windows.Forms.MenuItem();
			this.menuItemFileNew = new System.Windows.Forms.MenuItem();
			this.menuItemFileOpen = new System.Windows.Forms.MenuItem();
			this.menuItemFileSave = new System.Windows.Forms.MenuItem();
			this.menuItemFileSaveAs = new System.Windows.Forms.MenuItem();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItemFileExit = new System.Windows.Forms.MenuItem();
			this.menuItemHelp = new System.Windows.Forms.MenuItem();
			this.menuItemHelpAbout = new System.Windows.Forms.MenuItem();
			this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
			this.toolTip = new System.Windows.Forms.ToolTip(this.components);
			this.textBoxReceiverHostName = new System.Windows.Forms.TextBox();
			this.textBoxSocketOptionBufferSize = new System.Windows.Forms.TextBox();
			this.checkBoxSocketOptionNoDelay = new System.Windows.Forms.CheckBox();
			this.textBoxApplicationBufferSize = new System.Windows.Forms.TextBox();
			this.textBoxNumberOfBuffers = new System.Windows.Forms.TextBox();
			this.textBoxTtcpPort = new System.Windows.Forms.TextBox();
			this.textBoxLogMessages = new System.Windows.Forms.TextBox();
			this.panelTestControls = new System.Windows.Forms.Panel();
			this.label1 = new System.Windows.Forms.Label();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.buttonStartTransmit = new System.Windows.Forms.Button();
			this.label7 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.groupBox7 = new System.Windows.Forms.GroupBox();
			this.buttonClearMessageLog = new System.Windows.Forms.Button();
			this.panelTestControls.SuspendLayout();
			this.groupBox7.SuspendLayout();
			this.SuspendLayout();
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuItemFile,
																					 this.menuItemHelp});
			// 
			// menuItemFile
			// 
			this.menuItemFile.Index = 0;
			this.menuItemFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItemFileNew,
																						 this.menuItemFileOpen,
																						 this.menuItemFileSave,
																						 this.menuItemFileSaveAs,
																						 this.menuItem1,
																						 this.menuItemFileExit});
			this.menuItemFile.Text = "File";
			// 
			// menuItemFileNew
			// 
			this.menuItemFileNew.Index = 0;
			this.menuItemFileNew.Text = "New";
			this.menuItemFileNew.Click += new System.EventHandler(this.OnFileNew);
			// 
			// menuItemFileOpen
			// 
			this.menuItemFileOpen.Index = 1;
			this.menuItemFileOpen.Text = "Open...";
			this.menuItemFileOpen.Click += new System.EventHandler(this.OnFileOpen);
			// 
			// menuItemFileSave
			// 
			this.menuItemFileSave.Index = 2;
			this.menuItemFileSave.Text = "Save";
			this.menuItemFileSave.Click += new System.EventHandler(this.OnFileSave);
			// 
			// menuItemFileSaveAs
			// 
			this.menuItemFileSaveAs.Index = 3;
			this.menuItemFileSaveAs.Text = "Save As...";
			this.menuItemFileSaveAs.Click += new System.EventHandler(this.OnFileSaveAs);
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 4;
			this.menuItem1.Text = "-";
			// 
			// menuItemFileExit
			// 
			this.menuItemFileExit.Index = 5;
			this.menuItemFileExit.Text = "Exit";
			this.menuItemFileExit.Click += new System.EventHandler(this.OnFileExit);
			// 
			// menuItemHelp
			// 
			this.menuItemHelp.Index = 1;
			this.menuItemHelp.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItemHelpAbout});
			this.menuItemHelp.Text = "Help";
			// 
			// menuItemHelpAbout
			// 
			this.menuItemHelpAbout.Index = 0;
			this.menuItemHelpAbout.Text = "About TTCP Transmitter...";
			this.menuItemHelpAbout.Click += new System.EventHandler(this.OnHelpAbout);
			// 
			// openFileDialog
			// 
			this.openFileDialog.DefaultExt = "TtcpTx";
			this.openFileDialog.Filter = "TtcpTx documents (*.TtcpTx)|*.TtcpTx";
			this.openFileDialog.Title = "Open a TTCP Transmit Settings File";
			this.openFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.OnFileOpenFileOk);
			// 
			// saveFileDialog
			// 
			this.saveFileDialog.DefaultExt = "TtcpTx";
			this.saveFileDialog.Filter = "TtcpTx documents (*.TtcpTx)|*.TtcpTx";
			this.saveFileDialog.Title = "Save a TTCP Transmit Settings File";
			this.saveFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.OnFileSaveFileOk);
			// 
			// textBoxReceiverHostName
			// 
			this.textBoxReceiverHostName.Location = new System.Drawing.Point(16, 24);
			this.textBoxReceiverHostName.Name = "textBoxReceiverHostName";
			this.textBoxReceiverHostName.Size = new System.Drawing.Size(208, 20);
			this.textBoxReceiverHostName.TabIndex = 79;
			this.textBoxReceiverHostName.Text = "localhost";
			this.toolTip.SetToolTip(this.textBoxReceiverHostName, "TTCP receiver host name or IP address.");
			// 
			// textBoxSocketOptionBufferSize
			// 
			this.textBoxSocketOptionBufferSize.Location = new System.Drawing.Point(544, 32);
			this.textBoxSocketOptionBufferSize.Name = "textBoxSocketOptionBufferSize";
			this.textBoxSocketOptionBufferSize.Size = new System.Drawing.Size(48, 20);
			this.textBoxSocketOptionBufferSize.TabIndex = 84;
			this.textBoxSocketOptionBufferSize.Text = "8192";
			this.toolTip.SetToolTip(this.textBoxSocketOptionBufferSize, "Specifies the total per-socket buffer space reserved for sends. Passed to SO_SNDB" +
				"UF.");
			this.textBoxSocketOptionBufferSize.Validating += new System.ComponentModel.CancelEventHandler(this.OnValidateSocketOptionBufferSize);
			// 
			// checkBoxSocketOptionNoDelay
			// 
			this.checkBoxSocketOptionNoDelay.Location = new System.Drawing.Point(24, 56);
			this.checkBoxSocketOptionNoDelay.Name = "checkBoxSocketOptionNoDelay";
			this.checkBoxSocketOptionNoDelay.Size = new System.Drawing.Size(112, 24);
			this.checkBoxSocketOptionNoDelay.TabIndex = 0;
			this.checkBoxSocketOptionNoDelay.Text = "TCP_NODELAY";
			this.toolTip.SetToolTip(this.checkBoxSocketOptionNoDelay, "Disables the Nagle algorithm for send coalescing.");
			// 
			// textBoxApplicationBufferSize
			// 
			this.textBoxApplicationBufferSize.Location = new System.Drawing.Point(360, 32);
			this.textBoxApplicationBufferSize.Name = "textBoxApplicationBufferSize";
			this.textBoxApplicationBufferSize.Size = new System.Drawing.Size(48, 20);
			this.textBoxApplicationBufferSize.TabIndex = 81;
			this.textBoxApplicationBufferSize.Text = "8192";
			this.toolTip.SetToolTip(this.textBoxApplicationBufferSize, "Size of application buffer used for each call to send on the connection.");
			this.textBoxApplicationBufferSize.Validating += new System.ComponentModel.CancelEventHandler(this.OnValidateApplicationBufferSize);
			// 
			// textBoxNumberOfBuffers
			// 
			this.textBoxNumberOfBuffers.Location = new System.Drawing.Point(360, 64);
			this.textBoxNumberOfBuffers.Name = "textBoxNumberOfBuffers";
			this.textBoxNumberOfBuffers.Size = new System.Drawing.Size(48, 20);
			this.textBoxNumberOfBuffers.TabIndex = 82;
			this.textBoxNumberOfBuffers.Text = "2048";
			this.toolTip.SetToolTip(this.textBoxNumberOfBuffers, "Number of buffers to send.");
			this.textBoxNumberOfBuffers.Validating += new System.ComponentModel.CancelEventHandler(this.OnValidateNumberOfBuffers);
			// 
			// textBoxTtcpPort
			// 
			this.textBoxTtcpPort.Location = new System.Drawing.Point(88, 56);
			this.textBoxTtcpPort.Name = "textBoxTtcpPort";
			this.textBoxTtcpPort.Size = new System.Drawing.Size(48, 20);
			this.textBoxTtcpPort.TabIndex = 80;
			this.textBoxTtcpPort.Text = "5001";
			this.toolTip.SetToolTip(this.textBoxTtcpPort, "Receiver TTCP port number.");
			this.textBoxTtcpPort.Validating += new System.ComponentModel.CancelEventHandler(this.OnValidatePortNumber);
			// 
			// textBoxLogMessages
			// 
			this.textBoxLogMessages.Dock = System.Windows.Forms.DockStyle.Top;
			this.textBoxLogMessages.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.textBoxLogMessages.Location = new System.Drawing.Point(0, 128);
			this.textBoxLogMessages.Multiline = true;
			this.textBoxLogMessages.Name = "textBoxLogMessages";
			this.textBoxLogMessages.ReadOnly = true;
			this.textBoxLogMessages.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBoxLogMessages.Size = new System.Drawing.Size(728, 200);
			this.textBoxLogMessages.TabIndex = 1;
			this.textBoxLogMessages.Text = "";
			// 
			// panelTestControls
			// 
			this.panelTestControls.Controls.Add(this.label1);
			this.panelTestControls.Controls.Add(this.buttonCancel);
			this.panelTestControls.Controls.Add(this.textBoxReceiverHostName);
			this.panelTestControls.Controls.Add(this.buttonStartTransmit);
			this.panelTestControls.Controls.Add(this.textBoxSocketOptionBufferSize);
			this.panelTestControls.Controls.Add(this.label7);
			this.panelTestControls.Controls.Add(this.textBoxApplicationBufferSize);
			this.panelTestControls.Controls.Add(this.textBoxNumberOfBuffers);
			this.panelTestControls.Controls.Add(this.label2);
			this.panelTestControls.Controls.Add(this.label5);
			this.panelTestControls.Controls.Add(this.label4);
			this.panelTestControls.Controls.Add(this.label3);
			this.panelTestControls.Controls.Add(this.textBoxTtcpPort);
			this.panelTestControls.Controls.Add(this.groupBox5);
			this.panelTestControls.Controls.Add(this.groupBox7);
			this.panelTestControls.Dock = System.Windows.Forms.DockStyle.Top;
			this.panelTestControls.Location = new System.Drawing.Point(0, 0);
			this.panelTestControls.Name = "panelTestControls";
			this.panelTestControls.Size = new System.Drawing.Size(728, 128);
			this.panelTestControls.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label1.Location = new System.Drawing.Point(16, 112);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(80, 16);
			this.label1.TabIndex = 93;
			this.label1.Text = "Message Log:";
			// 
			// buttonCancel
			// 
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.Location = new System.Drawing.Point(632, 48);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 92;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.Click += new System.EventHandler(this.OnCancel);
			// 
			// buttonStartTransmit
			// 
			this.buttonStartTransmit.Location = new System.Drawing.Point(632, 16);
			this.buttonStartTransmit.Name = "buttonStartTransmit";
			this.buttonStartTransmit.TabIndex = 86;
			this.buttonStartTransmit.Text = "Transmit";
			this.buttonStartTransmit.Click += new System.EventHandler(this.OnStartTransmit);
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(472, 32);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(64, 16);
			this.label7.TabIndex = 91;
			this.label7.Text = "Buffer Size:";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(288, 32);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(64, 16);
			this.label2.TabIndex = 89;
			this.label2.Text = "Buffer Size:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(248, 64);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(104, 16);
			this.label5.TabIndex = 88;
			this.label5.Text = "Number of Buffers:";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(16, 8);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(184, 16);
			this.label4.TabIndex = 85;
			this.label4.Text = "TTCP Receiver:";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 56);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(72, 16);
			this.label3.TabIndex = 87;
			this.label3.Text = "Port Number:";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// groupBox5
			// 
			this.groupBox5.Location = new System.Drawing.Point(240, 8);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new System.Drawing.Size(192, 96);
			this.groupBox5.TabIndex = 90;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "Application Buffer Settings:";
			// 
			// groupBox7
			// 
			this.groupBox7.Controls.Add(this.checkBoxSocketOptionNoDelay);
			this.groupBox7.Location = new System.Drawing.Point(448, 8);
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.Size = new System.Drawing.Size(160, 96);
			this.groupBox7.TabIndex = 83;
			this.groupBox7.TabStop = false;
			this.groupBox7.Text = "Socket Options:";
			// 
			// buttonClearMessageLog
			// 
			this.buttonClearMessageLog.Location = new System.Drawing.Point(600, 344);
			this.buttonClearMessageLog.Name = "buttonClearMessageLog";
			this.buttonClearMessageLog.Size = new System.Drawing.Size(120, 23);
			this.buttonClearMessageLog.TabIndex = 94;
			this.buttonClearMessageLog.Text = "Clear Message Log";
			this.buttonClearMessageLog.Click += new System.EventHandler(this.buttonClearMessageLog_Click);
			// 
			// Form1
			// 
			this.AcceptButton = this.buttonStartTransmit;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(728, 385);
			this.Controls.Add(this.textBoxLogMessages);
			this.Controls.Add(this.panelTestControls);
			this.Controls.Add(this.buttonClearMessageLog);
			this.Menu = this.mainMenu;
			this.Name = "Form1";
			this.Text = "Untitled - TTCP Transmitter";
			this.panelTestControls.ResumeLayout(false);
			this.groupBox7.ResumeLayout(false);
			this.ResumeLayout(false);
		}
		private PcaUsa.Ttcp.TransmitterSettings GetTransmitterSettings()
		{
			PcaUsa.Ttcp.TransmitterSettings settings = new PcaUsa.Ttcp.TransmitterSettings(
				this.textBoxReceiverHostName.Text,
				System.Convert.ToInt32(this.textBoxTtcpPort.Text),
				System.Convert.ToInt32(this.textBoxApplicationBufferSize.Text),
				System.Convert.ToInt32(this.textBoxSocketOptionBufferSize.Text),
				System.Convert.ToInt32(this.textBoxNumberOfBuffers.Text),
				this.checkBoxSocketOptionNoDelay.Checked
				);
			return settings;
		}
		#endregion

		#region Main Entry Point
		[STAThread]
		static void Main() 
		{
			Application.Run(new TtcpTx());
		}
		#endregion
	}
}