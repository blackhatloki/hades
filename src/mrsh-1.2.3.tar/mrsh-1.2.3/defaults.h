#define MAXMACHINES 100
#define TIMEOUT      10
#define SINGLELINE    0
#define PASSES      100
#define MAXPIPES     25

#define MASK        ".*"
#define MACHINELIST "/etc/hosts.equiv"
#define CMD         "uptime"
#define SHL         "ssh -qx -o 'BatchMode yes' -o 'StrictHostKeyChecking no'"
