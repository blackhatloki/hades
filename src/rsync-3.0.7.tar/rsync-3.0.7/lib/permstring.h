#define PERMSTRING_SIZE 11

void permstring(char *perms, mode_t mode);
