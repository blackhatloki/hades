#!/bin/sh

while read file
do
	echo "File: $file\n"
	cat $file
	echo "\c"
done <<EOF | mp -l >mp.ps
cpustat/cpustat_opteron.sh
cflash/oltp.f
db/oltp.f
db/seq.f
db/file.f
dtrace_proc/profile.d
dtrace_proc/random.f
dtrace_syscalls/syscalls_syswide.d
dtrace_syscalls/syscalls_pid.d
dtrace_syscalls/syscalls_whichpid.d
dtrace_syscalls/syscalls_pidstack.d
dtrace_syscalls/random.f
fs_randomio/preadwss.d
fs_randomio/randomread.f
fs_randomio/filestat.d
fs_randomio/tracesegmap2.d
fs_randomio/fsstat.d
mem_paging/random.f
mem_paging/randomread.f
mem_paging/overflowmem
mem_paging/whospaging.d
mem_paging/pagingtime.d
mem_paging/prtmem.pl
slashproc/psym.sh
disks/1thread
disks/cflash
disks/randomread.f
disks/64thread
disks/iotrace.d
proc_time/dtest.c
proc_time/inseveralfuncs.d
proc_time/cache.c
proc_time/sc.d
proc_time/prof.d
fss/64thread
fss/randomread.f
fss/1thread
fs_paging/slowio
fs_paging/fsread
fs_paging/fspaging.d
fs_paging/randomread.f
fs_paging/pagingflow.d
fs_paging/fswritesync
fs_paging/randomwritesync.f
fs_paging/filestat.d
fs_paging/fsstat.d
fs_paging/overflowmem
fs_paging/fitsinmem
fs_paging/16mb
vm_scanner/overflowmem
vm_scanner/randomread.f
vm_scanner/pagescanner.d
vm_as/brk.txt
vm_as/vm.d
vm_as/as_fault.txt
vm_as/generatevmd.sh
vm_as/gvmd.sh
vm_hat/lp.c
EOF

ps2pdf mp.ps
