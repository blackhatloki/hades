#include <sys/types.h>
#include <sys/mman.h>
#include <stdlib.h>

#define MEGABYTE ((size_t)(1024 * 1024))
#define TWO_MEGABYTE ((size_t)2 * MEGABYTE)

main(int argc, char *argv[])
	struct memcntl_mha mha;
	char *my_memory;
	/* Set pagesize to 2MB for heap */
	mha.mha_cmd = MHA_MAPSIZE_BSSBRK;
	mha.mha_flags = 0;
	mha.mha_pagesize = TWO_MEGABYTE;
	memcntl(NULL, 0, MC_HAT_ADVISE, (char *)&mha, 0, 0);
	/* Ensure user memory starts on first large page */
	my_memory = (char *)memalign(TWO_MEGABYTE, (size_t)16 * MEGABYTE);
	*my_memory = 0;
	pause();
}

