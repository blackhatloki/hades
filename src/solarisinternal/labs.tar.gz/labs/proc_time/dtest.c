#include <unistd.h>
#include <stdio.h>
#include <sys/time.h>

typedef void (*routine)(void);

typedef float (*timingfunction)(routine function, char* funcname, long long iterations);

volatile long j=0;
volatile long k=0;

#define loop(iterations,variable) \
static void loop##iterations##variable(void) \
{ \
    int i; \
    for (i=0;i<iterations;i++) { \
        variable++; \
    } \
}

loop(1,j)
loop(10,j)
loop(100,k)
loop(1000,k)

static void bigloop(void)
{
    loop1j();
    loop10j();
    loop100k();
    loop1000k();
}

float measure(routine function, char* funcname, long long iterations)
{
    float period, elapsed;
    hrtime_t duration;
    hrtime_t start, end;
    long long done = 0;

    start = gethrvtime();
    while (done++ < iterations)
    {
        function();
    }
    end = gethrvtime();

    duration = end - start;
    period = (float)duration / (float)iterations;
    elapsed = (float)duration / 1000000000;
    printf("%s period = %.2f ns , elapsed = %.2f s\n", funcname, period, elapsed);
    return period;
}

void test(timingfunction timeit, char* string)
{
    /* approximately measure relative cost of each function by running it in a loop */
    hrtime_t start, end, diff;
    long long loops ;
    float smallest, smallish, small, big, aggregate;
    long long iter1 = 1000000000, iter2 = iter1/10, iter3 = iter2/10, iter4 = iter3/10;

    printf(string);
    /* start with short loop */
    smallest = timeit(loop1j, "loop1j", iter1);

    /* start with short loop */
    smallish = timeit(loop10j, "loop10j", iter2);

    /* then longer loop */
    small = timeit(loop100k, "loop100k", iter3);

    /* then longer loop */
    big = timeit(loop1000k, "loop1000k", iter4);

    /* then aggregate loop */
    aggregate = timeit(bigloop, "bigloop", iter4);

    printf("In aggregate loop, loop1j is %.2f %%\n \
	      loop10j is %.2f %% \n  \
	      loop100k is %.2f %% \n  \
	      loop1000k is %.2f %% of CPU time\n\n", \
           (float) 100*smallest / aggregate,
           (float) 100*smallish / aggregate,
           (float) 100*small / aggregate,
           (float) 100*big / aggregate);

}

int main()
{
    test(measure, "The following measurements are made with time measured at start and end of the loop.\n\n");

    printf("Running bigloop forever....start dtrace'ing....\n");
    /* now, run the aggregate loop forever, so we can run dtrace the process */
    while (1) {
        bigloop();
    }

   exit(0);
}

