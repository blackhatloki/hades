#!/bin/sh
#
# Example script from Solaris Internals Tutorial
#
# Solaris Internals
# (c) 2005, Richard McDougall and James Mauro
#
# Display symbols in a process
#
nm /proc/$1/object/*

