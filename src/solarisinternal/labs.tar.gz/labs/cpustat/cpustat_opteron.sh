#!/bin/sh
#
# Example script from Solaris Internals Tutorial
#
# Solaris Internals
# (c) 2005, Richard McDougall and James Mauro
#
# Measure Cycles, Instructions and L2 accesses on Opteron
#
# (use this example to measure cpu cycles while moving windows 
#  to show cycles and L2 misses)
#

cpustat -c pic0=BU_cpu_clk_unhalted,pic1=FR_retired_uops,pic2=IC_refill_from_L2 1

