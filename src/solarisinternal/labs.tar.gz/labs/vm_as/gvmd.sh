#!/bin/sh

/usr/sbin/dtrace -Pfbt -l |sed 's/ [ ]*/ /g' | \
		sed 's/^ [ ]*//' | cut -d' ' -f4 >ksyms

echo "#!/usr/sbin/dtrace -s" 
echo
echo "#pragma D option flowindent"
echo
echo ":::BEGIN"
echo "{"
echo "	start = timestamp;"
echo "}"
echo
echo "syscall:::"
echo "/\$target == pid/"
echo "{"
echo "	trace((timestamp - start) / 1000);"
echo "}"

ls *.h|while read header
do	
	cat $header | \
		egrep "[ 	*][a-z_]+\(" |grep "_" | \
		egrep -v  "rw_|mutex_" | \
		sed 's/^.*[ 	*]\([a-z][_a-z]*\)(.*/\1/'
done > vmfuncs

while read segop
do
	grep "^seg" ksyms |grep "_create\$" | sed 's/_create//' | \
		grep -v page |while read segment
	do
		echo "${segment}_${segop}"
	done 
done >> vmfuncs <<EOF
dup
unmap
free
fault
faulta
setprot
checkprot
kluster
swapout
sync
incore
lockop
getprot
getoffset
gettype
getvp
advise
dump
pagelock
setpagesize
getmemid
EOF

cat vmfuncs | sort -u | grep -v "defined" | while read function
do
	if [ -n "`grep \"^$function\$\" ksyms`" ]
	then
		if [ -n "$first" ]
		then
			echo ","
		else
			echo
		fi
		echo "::$function:\c"
		first="not"
	fi
done

echo
echo "/\$target == pid/"
echo "{"
echo "	trace((timestamp - start) / 1000);"
echo "}"

