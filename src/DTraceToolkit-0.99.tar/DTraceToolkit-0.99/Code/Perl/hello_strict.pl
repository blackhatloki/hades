#!./perl -w

use strict;

print "Hello World!\n";
